@extends('layouts.admin')

@section('title')
<title>Edit Produk</title>
<link href="{{ asset('css/plugins/summernote/summernote.css') }}" rel="stylesheet">
<link href="{{ asset('css/plugins/summernote/summernote-bs3.css') }}" rel="stylesheet">
@endsection

@section('menuside')
<li>
    <a href="{{ route('admin.index') }}"><i class="fa fa-th-large"></i>
        <span class="nav-label">Dashboard</span></a>
</li>
<li>
    <a href="#"><i class="fa fa-user"></i><span class="fa arrow"></span>
        <span class="nav-label">Kelola User</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('admin.user') }}">List Customer</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('admin.admin') }}">List Admin</a></li>
    </ul>
</li>
<li class="active">
    <a href="#"><i class="fa fa-archive"></i><span class="fa arrow"></span>
        <span class="nav-label">Product</span></a>
    <ul class="nav nav-second-level collapse">
        <li class="active"><a href="{{ route('product.index') }}">List Produk</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('product.create') }}">Tambah Produk</a></li>
    </ul>
</li>
<li>
    <a href="{{ route('category.index') }}"><i class="fa fa-industry"></i> <span
            class="nav-label">Category</span></a>
</li>
<li>
    <a href="{{ route('admin.order') }}"><i class="fa fa-cart-plus"></i> <span
            class="nav-label">Order</span></a>
</li>
<li>
    <a href="{{ route('admin.indexbank') }}"><i class="fa fa-credit-card"></i> <span
            class="nav-label">Rekening Bank</span></a>
</li>
<li>
    <a href="{{ route('admin.edit') }}"><i class="fa fa-address-card"></i>
        <span class="nav-label">Profile</span></a>
</li>
<li>
    <a href=""><i class="fa fa-navicon"></i><span class="fa arrow"></span>
        <span class="nav-label">Syarat & Ketentuan</span></a>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.sk') }}">List SK</a></li>
        </ul>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.formsk') }}">Tambah SK</a></li>
        </ul>
</li>
@endsection

@section ('content')
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Produk</h2>
        <ol class="breadcrumb">
            <li>Home
            </li>
            <li>
                Produk
            </li>
            <li class="active">
                <strong>Edit Produk</strong>
            </li>
        </ol>
    </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
    <form action="{{ route('product.update', $product->id) }}" method="post" enctype="multipart/form-data" >
        @csrf
        @method('PUT')
        <div class="row">
            <div class="col-md-8">
                <div class="ibox-content">
                    <div class="card-body">
                        <div class="form-group">
                            <label for="name">Nama Produk</label>
                            <input type="text" name="name" class="form-control" value="{{ $product->name }}" required>
                            <p class="text-danger">{{ $errors->first('name') }}</p>
                        </div>
                        <div class="form-group">
                            <label for="description">Deskripsi</label>

                            <!-- TAMBAHKAN ID YANG NNTINYA DIGUNAKAN UTK MENGHUBUNGKAN DENGAN CKEDITOR -->
                            <textarea name="description" id="description" class="form-control">{{ $product->description }}</textarea>
                            <p class="text-danger">{{ $errors->first('description') }}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="ibox-content">
                    <div class="card-body">
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select name="status" class="form-control" required>
                                <option value="1" {{ $product->status == '1' ? 'selected':'' }}>Publish</option>
                                <option value="0" {{ $product->status == '0' ? 'selected':'' }}>Draft</option>
                            </select>
                            <p class="text-danger">{{ $errors->first('status') }}</p>
                        </div>
                        <div class="form-group">
                            <label for="category_id">Kategori</label>

                            <!-- DATA KATEGORI DIGUNAKAN DISINI, SEHINGGA SETIAP PRODUK USER BISA MEMILIH KATEGORINYA -->
                            <select name="category_id" class="form-control">
                                <option value="">Pilih</option>
                                @foreach ($category as $row)
                                <option value="{{ $row->id }}" {{ $product->category_id == $row->id ? 'selected':'' }}>{{ $row->name }}</option>
                                @endforeach
                            </select>
                            <p class="text-danger">{{ $errors->first('category_id') }}</p>
                        </div>
                        <div class="form-group">
                            <label for="price">Harga</label>
                            <input type="number" name="price" class="form-control" value="{{ $product->price }}" required>
                            <p class="text-danger">{{ $errors->first('price') }}</p>
                        </div>
                        <div class="form-group">
                            <label for="weight">Berat</label>
                            <input type="number" name="weight" class="form-control" value="{{ $product->weight }}" required>
                            <p class="text-danger">{{ $errors->first('weight') }}</p>
                        </div>
                        <div class="form-group">
                            <label for="image">Foto Produk</label>
                            <br>
                            <!--  TAMPILKAN GAMBAR SAAT INI -->
                            <img src="{{ asset('/storage/products/' . $product->image) }}" width="100px" height="100px" alt="{{ $product->name }}">
                            <hr>
                            <input type="file" name="image" class="form-control">
                            <p><strong>Biarkan kosong jika tidak ingin mengganti gambar</strong></p>
                            <p class="text-danger">{{ $errors->first('image') }}</p>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary btn-sm">Update</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>

</div>
    
@endsection

@section('js')
<!-- SUMMERNOTE -->

<script src="{{ asset('js/jquery.min.js') }}"></script>
<script src="{{ asset('js/bootstrap.min.js') }}"></script>

<script src="{{ asset('js/plugins/summernote/summernote.min.js') }}"></script>

<!-- 
<script>
    $('#description').summernote({
        height: 125,   //set editable area's height
        codemirror: { // codemirror options
            theme: 'monokai'
        }
    });
</script>
-->
<script type="text/javascript">
  $(document).ready(function() {
    $('#description').summernote({
      height: "150px",
      styleWithSpan: false
  });
}); 
</script>

@endsection