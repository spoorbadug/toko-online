<?php

namespace App\Http\Controllers;
use App\Order;
use App\OrderDetail;
use App\City;
use App\Province;
use App\Product;
use Auth;
use Alert;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function index()
    {
        $orders = Order::with(['profile'])->where('user_id', auth()->guard('web')->user()->id)->orderBy('created_at', 'DESC')->paginate(10);
        return view('orders.index', compact('orders'));
    }

    public function show()
    {
        //QUERY UNTUK MENGAMBIL SEMUA PESANAN DAN LOAD DATA YANG BERELASI MENGGUNAKAN EAGER LOADING
        //DAN URUTANKAN BERDASARKAN CREATED_AT
        $orders = Order::with(['user', 'profile'])
            ->orderBy('created_at', 'DESC');

        //JIKA Q UNTUK PENCARIAN TIDAK KOSONG
        if (request()->q != '') {
            //MAKA DIBUAT QUERY UNTUK MENCARI DATA BERDASARKAN NAMA, INVOICE DAN ALAMAT
            $orders = $orders->where(function($q) {
                $q->where('name', 'LIKE', '%' . request()->q . '%')
                ->orWhere('invoice', 'LIKE', '%' . request()->q . '%');
            });
        }

        //JIKA STATUS TIDAK KOSONG 
        if (request()->status != '') {
            //MAKA DATA DIFILTER BERDASARKAN STATUS
            $orders = $orders->where('status', request()->status);
        }
        $orders = $orders->paginate(10); //LOAD DATA PER 10 DATA
        return view('admin.order', compact('orders')); //LOAD VIEW INDEX DAN PASSING DATA TERSEBUT
    }

    public function view($invoice)
    {
        $order = Order::with(['city','province','status'])
            ->where('invoice', $invoice)->first();

            //$orderdetail = OrderDetail::where('order_id', $order->id)->groupBy('order_id')->first();
            
            //$subtotal = $orderdetail->qty * $orderdetail->price;

            // $subtotal = collect($orderdetail)->sum(function($q) {
            //     //dd($q);
            //     return $q->qty * $q->price;
            // });
        return view('orders.show', compact('order'));
    }

    public function orderbatal($invoice)
    {
        $order = Order::with(['details'])->where('invoice', $invoice)->first();
        $order->update([
            'status_id' => 9
        ]);

        foreach ($order->details as $row) {
            $product = Product::where('id', $row->product_id)->increment('stok',$row->qty);
        }
        
        return redirect(route('order.index'));
    }

    public function ordersukses($invoice)
    {
        $order = Order::with(['details'])->where('invoice', $invoice)->first();
        if($order->status_id == 6) {
            $order->update([
                'status_id' => 7
            ]);
            return redirect(route('order.detail', $invoice));
        }
        
        alert()->error('Maaf...','Tunggu status pesanan menjadi Proses Pengiriman');
        return redirect(route('order.detail', $invoice));
    }

    
}