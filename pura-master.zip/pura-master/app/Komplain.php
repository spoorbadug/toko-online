<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Komplain extends Model
{
    protected $fillable = ['order_id',
                        'user_id',
                        'product_id',
                        'jumlah',
                        'komplainstatus_id',
                        'image',
                        'catatan'
                    ];

    public function status()
    {
        return $this->belongsTo(KomplainStatus::class, 'komplainstatus_id');
    }

    public function product()
    {
        return $this->belongsTo(Product::class);
    }
    public function order()
    {
        return $this->belongsTo(Order::class);
    }
}
