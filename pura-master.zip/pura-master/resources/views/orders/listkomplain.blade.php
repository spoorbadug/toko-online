@extends('layouts.app')

@section('title')
    <title>Daftar Komplain</title>
@endsection

@section('content')
 <!-- Main Container  -->
 <div class="main-container container">
    <ul class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i></a></li>
        <li><a href="#">Akun</a></li>
        <li><a href="#">Komplain</a></li>
    </ul>
    
    <div class="row">
        <!--Middle Part Start-->
        <div id="content" class="col-sm-12">
            <h2 class="title">Daftar Komplain</h2>
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>InvoiceID</th>
                            <th>Produk</th>
                            <th>Jumlah</th>
                            <th>Tanggal</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($komplains as $row)
                            <tr>
                                <td>{{ $row->order->invoice }}</td>
                                <td>{{ $row->product->name }}</td>
                                <td>{{ $row->jumlah }}</td>
                                <td>{{ $row->created_at->format('d-m-Y') }}</td>
                                <td class="text-center">
                                    <div class="btn-group">
                                        
                                            <a href="{{ route('komplain.show', $row->id) }}"
                                                class="btn btn-primary btn-sm">Detail</a>
                                                <a href="{{ route('komplain.show', $row->id) }}"
                                                    class="btn btn-success btn-sm">Pesanan</a>
                                            <a href="{{ route('komplain.destroy', $row->id) }}"
                                                class="btn btn-danger btn-sm">Hapus</a>
                                        
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="text-center">Tidak ada data</td>
                            </tr>
                        @endforelse

                    </tbody>
                </table>
            </div>

        </div>
        <!--Middle Part End-->
        
    </div>
</div>
<!-- //Main Container -->
@endsection