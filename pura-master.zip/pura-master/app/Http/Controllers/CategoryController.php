<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;
use App\User;
Use Alert;


class CategoryController extends Controller
{
    public function index()
    {
        
        // $category = Category::orderBy('created_at', 'DESC')->paginate(10);
        // //$parent = Category::getParent()->orderBy('name', 'ASC')->get();
    
        // return view('admin.category', compact('category'));

        $category = Category::with(['user'])->orderBy('created_at', 'DESC')->paginate(10);
        $users = User::where('role', 'Unit')->orderBy('name', 'ASC')->get();

        return view('admin.category', compact('category', 'users'));
    }

    public function store(Request $request)
    {
        
        $this->validate($request, [
            'name' => 'required|string|max:50|unique:categories'
        ]);

        $request->request->add(['slug' => $request->name]);

        Category::create($request->except('_token'));
        Alert::success('Success Title', 'Success Message');

        return redirect(route('category.index'))->with(['success' => 'Kategori Baru Ditambahkan!']);
    }

    public function show($slug)
    {
        //dd($slug);
        //$id = User::where('slug', $slug)->first();
        //$products = Category::where('parent_id', $id->id)->first()->product()->orderBy('created_at', 'DESC')->paginate(12);
        $products = Category::where('slug', $slug)->first()->product()->orderBy('created_at', 'DESC')->paginate(12);
        
        return view('products.index', compact('products'));
    }

    public function showunit($slug)
    {
        //dd($slug);
        $iduser = User::where('slug', $slug)->first();
        $products = Category::where('user_id', $iduser->id)->first()->product()->orderBy('created_at', 'DESC')->paginate(12);
        
        
        return view('products.index', compact('products'));
    }

    public function edit($id)
    {
        $kategori = Category::find($id); //QUERY MENGAMBIL DATA BERDASARKAN ID
        $unit = User::where('role', 'Unit')->orderBy('name', 'ASC')->get();
    
        //LOAD VIEW EDIT.BLADE.PHP PADA FOLDER CATEGORIES
        //DAN PASSING VARIABLE CATEGORY & PARENT
        return view('admin.editcategory', compact('kategori', 'unit'));
    }

    public function update(Request $request, $id)
    {
       
        //VALIDASI FIELD NAME
        //YANG BERBEDA ADA TAMBAHAN PADA RULE UNIQUE
        //FORMATNYA ADALAH unique:nama_table,nama_field,id_ignore
        //JADI KITA TETAP MENGECEK UNTUK MEMASTIKAN BAHWA NAMA CATEGORYNYA UNIK
        //AKAN TETAPI KHUSUS DATA DENGAN ID YANG AKAN DIUPDATE DATANYA DIKECUALIKAN
        $this->validate($request, [
            'name' => 'required|string|max:50|unique:categories,name,' . $id
        ]);

        $category = Category::find($id); //QUERY UNTUK MENGAMBIL DATA BERDASARKAN ID
        //KEMUDMIAN PERBAHARUI DATANYA
        //POSISI KIRI ADALAH NAMA FIELD YANG ADA DITABLE CATEGORIES
        //POSISI KANAN ADALAH VALUE DARI FORM EDIT
        $category->update([
            'name' => $request->name,
            'user_id' => $request->user_id,
            'status' => $request->status
        ]);
    
        //REDIRECT KE HALAMAN LIST KATEGORI
        return redirect(route('category.index'))->with(['success' => 'Kategori Diperbaharui!']);
    }

    public function destroy($id)
    {
        //Buat query untuk mengambil category berdasarkan id menggunakan method find()
        //ADAPUN withCount() SERUPA DENGAN EAGER LOADING YANG MENGGUNAKAN with()
        //HANYA SAJA withCount() RETURNNYA ADALAH INTEGER
        //JADI NNTI HASIL QUERYNYA AKAN MENAMBAHKAN FIELD BARU BERNAMA child_count YANG BERISI JUMLAH DATA ANAK KATEGORI
        $category = Category::withCount(['product'])->find($id);
        //KEMUDIAN PADA IF STATEMENTNYA KITA CEK JUGA JIKA = 0
        if ($category->product_count == 0) {
            $category->delete();
            Alert::success('Berhasil Hapus', 'Kategori Telah Berhasil Dihapus');
            return redirect(route('category.index'));
        }

        Alert::error('Gagal Hapus', 'Kategori Memiliki Produk');

        //SELAIN ITU, MAKA REDIRECT KE LIST TAPI FLASH MESSAGENYA ERROR YANG BERARTI KATEGORI INI SEDANG DIGUNAKAN
        return redirect(route('category.index'));
    }
}
