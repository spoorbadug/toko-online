<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Basic page needs
        ============================================ -->
    @yield('title')
    <meta charset="utf-8">
    <meta name="keywords"
        content="html5 template, best html5 template, best html template, html5 basic template, multipurpose html5 template, multipurpose html template, creative html templates, creative html5 templates" />
    <meta name="description"
        content="
        is a powerful Multi-purpose HTML5 Template with clean and user friendly design. It is definite a great starter for any eCommerce web project." />
    <meta name="author" content="Magentech">
    <meta name="robots" content="index, follow" />

    <!-- Mobile specific metas
        ============================================ -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <!-- Favicon
        ============================================ -->

    <link rel="shortcut icon" type="image/png" href="{{ secure_asset('image/logo-16px.png') }}" />


    <!-- Libs CSS
        ============================================ -->
    <link rel="stylesheet" href="{{ secure_asset('css/bootstrap/css/bootstrap.min.css') }}">
    <link href="{{ secure_asset('css/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet">
    <link href="{{ secure_asset('js/datetimepicker/bootstrap-datetimepicker.min.css') }}"
        rel="stylesheet">
    <link href="{{ secure_asset('js/owl-carousel/owl.carousel.css') }}" rel="stylesheet">
    <link href="{{ secure_asset('css/themecss/lib.css') }}" rel="stylesheet">
    <link href="{{ secure_asset('js/jquery-ui/jquery-ui.min.css') }}" rel="stylesheet">
    <link href="{{ secure_asset('js/minicolors/miniColors.css') }}" rel="stylesheet">

    <link href="{{ secure_asset('js/pe-icon-7-stroke/css/pe-icon-7-stroke.css') }}" rel="stylesheet">
    <link href="{{ secure_asset('pe-icon-7-stroke/css/helper.css') }}" rel="stylesheet">

    <!-- Theme CSS
        ============================================ -->
    <link href="{{ secure_asset('css/themecss/so_searchpro.css') }}" rel="stylesheet">
    <link href="{{ secure_asset('css/themecss/so_megamenu.css') }}" rel="stylesheet">
    <link href="{{ secure_asset('css/themecss/so_advanced_search.css') }}" rel="stylesheet">
    <link href="{{ secure_asset('css/themecss/so-listing-tabs.css') }}" rel="stylesheet">
    <link href="{{ secure_asset('css/themecss/so-categories.css') }}" rel="stylesheet">
    <link href="{{ secure_asset('css/themecss/so-newletter-popup.css') }}" rel="stylesheet">
    <link href="{{ secure_asset('css/themecss/so-latest-blog.css') }}" rel="stylesheet">

    <link href="{{ secure_asset('css/footer/footer2.css') }}" rel="stylesheet">
    <link href="{{ secure_asset('css/header/header2.css') }}" rel="stylesheet">
    <link id="color_scheme" href="{{ secure_asset('css/home2.css') }}" rel="stylesheet">
    <link id="color_scheme" href="{{ secure_asset('css/theme.css') }}" rel="stylesheet">
    <link href="{{ secure_asset('css/responsive.css') }}" rel="stylesheet">

    <link href="{{ secure_asset('js/lightslider/lightslider.css') }}" rel="stylesheet">

    <!-- Google web fonts
        ============================================ -->
    <link href='https://fonts.googleapis.com/css?family=Rubik:300,400,400i,500,600,700' rel='stylesheet'
        type='text/css'>
    <style type="text/css">
        body {
            font-family: 'Rubik', sans-serif
        }
    </style>

<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">

</head>

<body>
    @include('sweetalert::alert')
    <!-- Header Container  -->
    <header id="header" class=" typeheader-2">
        <!-- Header Top -->
        <div class="header-top hidden-compact">
            <div class="container">
                <div class="row">
                    <div class="header-top-left col-lg-3 col-md-4 col-sm-5 hidden-xs">
                        <div class="telephone ">
                            <ul class="socials">
                                <li class="facebook"><a href="https://www.facebook.com/smartaddons.page"
                                        target="_blank"><i class="fa fa-facebook"></i></a></li>
                                <li class="twitter"><a href="https://twitter.com/smartaddons" target="_blank"><i
                                            class="fa fa-twitter"></i></a></li>
                                <li class="google_plus"><a href="https://plus.google.com/u/0/+Smartaddons/posts"
                                        target="_blank"><i class="fa fa-google-plus"></i></a></li>
                                <li class="pinterest"><a href="https://www.pinterest.com/smartaddons/"
                                        target="_blank"><i class="fa fa-pinterest-p"></i></a></li>
                                <li class="instagram"><a href="#" target="_blank"><i class="fa fa-instagram"></i></a>
                                </li>
                                <li class="linkedin"><a href="#" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                            </ul>
                        </div>


                    </div>
                    <div class="header-top-right col-lg-9 col-md-8 col-sm-7 col-xs-12">
                        
                        <ul class="top-log list-inline">
                            @guest
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                            </li>
                            @if (Route::has('register'))
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                                </li>
                            @endif
                        @else
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    {{ Auth::user()->name }} <span class="caret"></span>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                        @if(Auth::user()->role == 'Customer')
                                        <a href="{{ route('profile.edit') }}" class="dropdown-item">Profil</a>
                                        <div class="divider"> </div>
                                        @endif
                                        @if(Auth::user()->role == 'Admin')
                                        <a href="{{ route('admin.index') }}" class="dropdown-item">Dashboard</a>
                                        @elseif(Auth::user()->role == 'Unit')
                                        <a href="{{ route('unit.index') }}" class="dropdown-item">Dashboard</a>
                                        @elseif(Auth::user()->role == 'Keuangan')
                                        <a href="{{ route('keuangan.index') }}" class="dropdown-item">Dashboard</a>
                                        @else
                                        <a href="{{ route('order.index',['user'=>Auth::user()->id]) }}" class="dropdown-item">Pesanan</a>
                                        <div class="divider"> </div>
                                        <a href="{{ route('komplain.index',['user'=>Auth::user()->id]) }}" class="dropdown-item">Komplain</a>
                                        @endif
                                    <div class="divider"> </div>
                                    <a class="dropdown-item" href="{{ route('logout') }}"
                                        onclick="event.preventDefault();
                                                    document.getElementById('logout-form').submit();">
                                        {{ __('Logout') }}
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>
                                </div>
                            </li>
                        @endguest
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="header-middle hidden-compact">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-4 col-sm-12 col-xs-12">
                        <div class="logo">
                            <a href="{{ url('/') }}"><img
                                    src="{{ secure_asset('image/pura/logo.png') }}" title="Your Store"
                                    alt="Your Store" /></a>
                        </div>

                    </div>
                    <div class="col-lg-9 col-md-8 col-sm-12 col-xs-12 middle-right">
                        <div class="search-header-w">
                            <div class="icon-search hidden-lg hidden-md"><i class="fa fa-search"></i></div>

                            <div id="sosearchpro" class="sosearchpro-wrapper so-search ">
                                <form method="GET" action="index.html">
                                    <div id="search0" class="search input-group form-group">
                                        <div class="select_category filter_type  icon-select hidden-sm hidden-xs">
                                            <select class="no-border" name="category_id">
                                                <option value="0">Semua Kategori</option>
                                                @foreach($categories as $c)
                                                    <option value="{{ $c->id }}">{{ $c->name }}</option>
                                                @endforeach
                                            </select>
                                        </div>

                                        <input class="autosearch-input form-control" type="text" value="" size="50"
                                            autocomplete="off" placeholder="Keyword here..." name="search">

                                        <button type="submit" class="button-search btn btn-primary"
                                            name="submit_search"><i class="fa fa-search"></i></button>

                                    </div>
                                    <input type="hidden" name="route" value="product/search" />
                                </form>
                            </div>
                        </div>
                        <div class="shopping_cart">
                            <div id="cart" class="btn-shopping-cart">
                                <a href="#" data-loading-text="Loading... "
                                    class="btn-group top_cart dropdown-toggle" data-toggle="dropdown"
                                    aria-expanded="true">
                                    <div class="shopcart">
                                        <span class="icon-c">
                                            <i class="fa fa-shopping-basket"></i>
                                        </span>
                                        <div class="shopcart-inner">
                                            <p class="text-shopping-cart">Keranjang</p>
                                            <span class="total-shopping-cart cart-total-full">
                                                <span class="items_cart">{{ $ncarts }}</span><span class="items_cart2">
                                                    item(s)</span><span class="items_carts">Rp
                                                        {{ number_format($ntotal) }}</span>
                                            </span>
                                        </div>
                                    </div>
                                </a>
                                <ul class="dropdown-menu pull-right shoppingcart-box" role="menu">
                                    <li>
                                        <div>
                                            <p class="text-right"> <a class="btn view-cart"
                                                    href="{{ route('front.list_cart') }}"><i
                                                        class="fa fa-shopping-cart"></i>Lihat Keranjang</a>&nbsp;&nbsp;&nbsp;
                                                <a class="btn btn-mega checkout-cart" href="{{ route('checkout.index') }}"><i
                                                        class="fa fa-share"></i>Checkout</a>
                                            </p>
                                        </div>
                                    </li> 
                                </ul>  
                            </div>
                        </div>
                        {{-- <div class="wishlist hidden-md hidden-sm hidden-xs"><a href="#" id="wishlist-total"
                                class="top-link-wishlist" title="Wish List (0) "><i class="fa fa-heart"></i></a></div> --}}
                    </div>
                </div>
            </div>
        </div>

        <!-- Header Container  -->
        <header id="header" class=" typeheader-2">
            <div class="header-bottom hidden-compact">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="menu-vertical-w">
                                <div class="responsive so-megamenu megamenu-style-dev ">
                                    <div class="so-vertical-menu ">
                                        <nav class="navbar-default">

                                            <div class="container-megamenu vertical">
                                                <div id="menuHeading">
                                                    <div class="megamenuToogle-wrapper">
                                                        <div class="megamenuToogle-pattern">
                                                            <div class="container">
                                                                <div>
                                                                    <span></span>
                                                                    <span></span>
                                                                    <span></span>
                                                                </div>
                                                                Semua Unit
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="navbar-header">
                                                    <button type="button" id="show-verticalmenu" data-toggle="collapse"
                                                        class="navbar-toggle">
                                                        <i class="fa fa-bars"></i>
                                                        <span> Semua Unit </span>
                                                    </button>
                                                </div>
                                                <div class="vertical-wrapper">
                                                    <span id="remove-verticalmenu" class="fa fa-times"></span>
                                                    <div class="megamenu-pattern">
                                                        <div class="container-mega">
                                                            <ul class="megamenu">
                                                                @foreach ($categories as $item)
                                                                <li class="item-vertical item-style2">
                                                                    <p class='close-menu'></p>
                                                                    <a href="{{ url('/unit/' . $item->user->slug) }}"
                                                                        class="clearfix">
                                                                        <span>
                                                                            <strong>{{ $item->user->name }}</strong>
                                                                        </span>
                                                                    </a>
                                                                </li>
                                                                @endforeach
                                                                
                                                                <li class="loadmore">
                                                                    <i class="fa fa-plus-square-o"></i>
                                                                    <span class="more-view">More Categories</span>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-9 col-md-9 col-sm-6 col-xs-6">
                            <div class="main-menu-w">
                                <div class="responsive so-megamenu megamenu-style-dev">
                                    <nav class="navbar-default">
                                        <div class=" container-megamenu  horizontal open ">
                                            <div class="navbar-header">
                                                <button type="button" id="show-megamenu" data-toggle="collapse"
                                                    class="navbar-toggle">
                                                    <span class="icon-bar"></span>
                                                    <span class="icon-bar"></span>
                                                    <span class="icon-bar"></span>
                                                </button>
                                            </div>
                                            <div class="megamenu-wrapper">
                                                <span id="remove-megamenu" class="fa fa-times"></span>
                                                <div class="megamenu-pattern">
                                                    <div class="container-mega">
                                                        <ul class="megamenu" data-transition="slide"
                                                            data-animationtime="250">
                                                            <li class="home hover">
                                                                <a
                                                                    href="{{ route('home.index') }}">Home</a>
                                                            </li>
                                                            <li class="">
                                                                <p class="close-menu"></p>
                                                                <a href="{{ route('product.list') }}"
                                                                    class="clearfix">
                                                                    <strong>Produk</strong>
                                                                </a>
                                                            </li>
                                                            <li class="">
                                                                <p class="close-menu"></p>
                                                                <a href="{{ route('home.aboutus') }}" class="clearfix">
                                                                    <strong>Tentang Pura</strong>
                                                                </a>
                                                            </li>
                                                            <li class="">
                                                                <p class="close-menu"></p>
                                                                <a href="{{ route('home.contactus') }}" class="clearfix">
                                                                    <strong>Kontak Kami</strong>
                                                                </a>
                                                            </li>
                                                            <li class="">
                                                                <p class="close-menu"></p>
                                                                <a href="{{ route('home.faq') }}" class="clearfix">
                                                                    <strong>FAQ</strong>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </header>
        <!-- Header Container  -->

        {{-- bagian konten --}}
        @yield('content')

        <!-- Footer Container -->
        <footer class="footer-container typefooter-2">
            <div class="row-dark">
                <div class="row container container-top">
                    <div class="col-lg-4 col-md-5 col-sm-5 col-xs-12 col-socials">
                        <ul class="socials">
                            <li class="facebook"><a href="https://www.facebook.com/smartaddons.page" target="_blank"><i
                                        class="fa fa-facebook"></i></a></li>
                            <li class="twitter"><a href="https://twitter.com/smartaddons" target="_blank"><i
                                        class="fa fa-twitter"></i></a></li>
                            <li class="google_plus"><a href="https://plus.google.com/u/0/+Smartaddons/posts"
                                    target="_blank"><i class="fa fa-google-plus"></i></a></li>
                            <li class="pinterest"><a href="https://www.pinterest.com/smartaddons/" target="_blank"><i
                                        class="fa fa-pinterest-p"></i></a></li>
                            <li class="instagram"><a href="#" target="_blank"><i class="fa fa-instagram"></i></a></li>
                            <li class="Youtube"><a href="#" target="_blank"><i class="fa fa-youtube-play"></i></a></li>
                        </ul>
                    </div>

                </div>
            </div>
            <div class="container">
                <div class="row footer-middle">
                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-style">
                        <div class="box-footer box-infos">
                            <div class="module">
                                <img src="{{ secure_asset('image/logo.png') }}" class="img-responsive" style="width:60%">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-style">
                        <div class="row">
                            <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 col-clear">
                                <div class="box-infos box-footer">
                                    <div class="module clearfix">
                                        <h3 class="modtitle">Kontak Kami</h3>
                                <div class="modcontent">
                                    <ul class="list-icon">
                                        <li><span class="icon pe-7s-map-marker"></span>Jl. AKBP. Agil Kusumadya 203 Kudus 59346, Indonesia</li>
                                        <li><span class="icon pe-7s-call"></span> <a href="#">+62 291 444361 / 444363 (30 lines)</a></li>
                                        <li><span class="icon pe-7s-mail"></span><a href="mailto:marketing@puragroup.com">marketing@puragroup.com</a></li>
                                    </ul>
                                </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 col-style">
                                <div class="box-information box-footer">
                                    <div class="module clearfix">
                                        <h3 class="modtitle">Informasi</h3>
                                        <div class="modcontent">
                                            <ul class="menu">
                                                <li><a href="{{ route('home.aboutus') }}">Tentang Pura</a></li>
                                                <li><a href="{{ route('home.faq') }}">FAQ</a></li>
                                                <li><a href="{{ route('home.sk') }}">Syarat & Ketentuan</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 col-style">
                                <div class="box-account box-footer">
                                    <div class="module clearfix">
                                        <h3 class="modtitle">Akun</h3>
                                        <div class="modcontent">
                                            <ul class="menu">
                                                <li><a href="{{ route('profile.edit') }}">Profil</a></li>
                                                <li><a href="{{ route('order.index') }}">Daftar Pesanan</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>

            <div class="footer-bottom">
                <div class="container">
                    <div class="row">
                        <div class="copyright col-lg-8 col-md-8 col-sm-12 col-xs-12">
                            <p>Pura Group Bisnis © <?php echo date("Y")?> Store. All Rights Reserved.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!--Back To Top-->
            <div class="back-to-top"><i class="fa fa-angle-up"></i></div>
        </footer>
        <!-- //end Footer Container -->

        <!-- Include Libs & Plugins
        ============================================ -->
        <!-- Placed at the end of the document so the pages load faster -->
        <script type="text/javascript" src="{{ secure_asset('js/jquery-2.2.4.min.js') }}"></script>
        <script type="text/javascript" src="{{ secure_asset('js/bootstrap.min.js') }}"></script>
        <script type="text/javascript" src="{{ secure_asset('js/owl-carousel/owl.carousel.js') }}">
        </script>
        <script type="text/javascript" src="{{ secure_asset('js/slick-slider/slick.js') }}"></script>
        <script type="text/javascript" src="{{ secure_asset('js/themejs/libs.js') }}"></script>
        <script type="text/javascript" src="{{ secure_asset('js/unveil/jquery.unveil.js') }}"></script>
        <script type="text/javascript" src="{{ secure_asset('js/countdown/jquery.countdown.min.js') }}">
        </script>
        <script type="text/javascript"
            src="{{ secure_asset('js/dcjqaccordion/jquery.dcjqaccordion.2.8.min.js') }}"></script>
        <script type="text/javascript" src="{{ secure_asset('js/datetimepicker/moment.js') }}"></script>
        <script type="text/javascript"
            src="{{ secure_asset('js/datetimepicker/bootstrap-datetimepicker.min.js') }}"></script>
        <script type="text/javascript" src="{{ secure_asset('js/jquery-ui/jquery-ui.min.js') }}">
        </script>

        <script type="text/javascript" src="{{ secure_asset('js/lightslider/lightslider.js') }}">
        </script>
        <!-- Theme files
        ============================================ -->


        <script type="text/javascript" src="{{ secure_asset('js/themejs/application.js') }}"></script>

        <script type="text/javascript" src="{{ secure_asset('js/themejs/homepage.js') }}"></script>

        <script type="text/javascript" src="{{ secure_asset('js/themejs/toppanel.js') }}"></script>
        <script type="text/javascript" src="{{ secure_asset('js/themejs/so_megamenu.js') }}"></script>
        <script type="text/javascript" src="{{ secure_asset('js/themejs/addtocart.js') }}"></script>
        <script type="text/javascript">
            <!--
            // Check if Cookie exists
            if ($.cookie('display')) {
                view = $.cookie('display');
            } else {
                view = 'grid';
            }
            if (view) display(view);
            //

            -->
        </script>



        @yield('js')
</body>

</html>
