<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = ['invoice',
                        'user_id',
                        'profile_id',
                        'status_id',
                        'bank_id',
                        'kurir',
                        'total',
                        'catatan'
                    ];

    public function user(){
        return $this->belongsTo(User::class);
    }
    public function profile()
    {
        return $this->belongsTo(Profile::class);
    }
    public function bank()
    {
        return $this->belongsTo(DaftarBank::class);
    }
    public function status()
    {
        return $this->belongsTo(OrderStatus::class);
    }
    public function details()
    {
        return $this->hasMany(OrderDetail::class);
    }
    public function payment()
    {
        return $this->hasOne(Payment::class);
    }
    public function city()
    {
        return $this->belongsTo(City::class);
    }

    public function province()
    {
        return $this->belongsTo(Province::class);
    }
    
    
}

