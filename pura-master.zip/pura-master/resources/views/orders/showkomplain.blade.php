@extends('layouts.app')

@section('title')
<title>Detail Komplain</title>
@endsection

@section('content')
<div class="main-container container">
    <ul class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i></a></li>
        <li><a href="#">Akun</a></li>
        <li><a href="#">Komplain</a></li>
    </ul>
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox">
                <div class="ibox-content">
                    <h4 class="title">Informasi Komplain</h4>
                    <table class="table table-hover table-bordered">
                        <thead>
                            <tr>
                                <td colspan="2" class="text-left"><b>Detail Pesanan</b></td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="width: 50%;" class="text-left">
                                    <b>ID Pesanan :</b>
                                    {{ $komplain->order->invoice }}
                                    <br>
                                    <b>Tanggal Komplain :</b>
                                    {{ $komplain->created_at->format('d-m-Y') }}
                                    <br>
                                    <b>Status Pesanan Komplain :</b>
                                    {{ $komplain->order->status->name }}
                            </tr>
                        </tbody>
                    </table>
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>

                                <td style="vertical-align: top;" class="text-left"><b>Alamat</b></td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <?php
                                            $cities = \App\City::where('city_id', $komplain->order->profile->city_id)->first();
                                            $provinces = \App\Province::where('province_id', $komplain->order->profile->province_id)->first();
                                        ?>
                                <td class="text-left">{{ $komplain->order->profile->name }}
                                    <br>{{ $komplain->order->profile->address }}, {{ $cities->name }},
                                    {{ $provinces->name }}
                                    <br>Indonesia
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <td colspan="5" class="text-left"><b>Detail Barang</b></td>
                            </tr>
                        </thead>
                        <tbody>
                            {{-- @forelse ($komplain as $row) --}}
                            <tr>
                                <td>{{ $komplain->product->name }}</td>
                                <td>{{ $komplain->jumlah }} Item</td>
                                <td>{{ $komplain->status->name }}</td>
                                <td class="text-center"><img
                                        src="{{ asset('storage/komplain/'.$komplain->image) }}"
                                        width="200px" height="200px" alt="{{ $komplain->image }}"></td>

                            </tr>
                            {{-- @empty
                                    <tr>
                                        <td colspan="5" class="text-center">Tidak ada data</td>
                                    </tr>
@endforelse--}}
                                </tbody>
                            </table>
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <td colspan="5" class="text-left"><b>Catatan Komplain</b></td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>{{ $komplain->catatan }}</td>
                            </tr>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>

</div>

@endsection
