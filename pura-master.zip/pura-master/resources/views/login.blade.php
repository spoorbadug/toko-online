<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Pura Group Bisnis | Login</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

</head>

<body class="gray-bg">

    <div class="middle-box text-center loginscreen animated fadeInDown">
        <div>
            <div>
                <img class="logo-name" src="{{ ('image/logo.png') }}" width="250" height="250" alt="Pura Group">
            </div>
            <h3>Selamat datang di Pura Store</h3>
            <p>Silahkan login terlebih dahulu</p>
            <!-- KETIKA ADA SESSION ERROR  -->
            @if (session('error'))
            <!-- MAKA TAMPILKAN ALERT DANGER -->
            <div class="alert alert-danger">{{ session('error') }}</div>
            @endif
            <form action="{{ route('xdmin.postlogin') }}" method="post">
                @csrf
                <div class="form-group">

                    <!-- $errors->has('email') AKAN MENGECEK JIKA ADA ERROR DARI HASIL VALIDASI LARAVEL, SEMUA KEGAGALAN VALIDASI LARAVEL AKAN DISIMPAN KEDALAM VARIABLE $errors -->
                    <input class="form-control {{ $errors->has('email') ? ' is-invalid' : '' }}" 
                    type="text" 
                    name="email"
                    placeholder="Email Address" 
                    value="{{ old('email') }}" 
                    autofocus 
                    required>
                </div>
                <div class="form-group">
                    <input class="form-control {{ $errors->has('password') ? ' is-invalid' : '' }}" 
                    type="password" 
                    name="password"
                    placeholder="Password" 
                    required>
                </div>
                <div class="form-group {{ $errors->has('g-recaptcha-response') ? ' has-error' : '' }}">
                    <label class="control-label">Captcha</label>
                    <div class="pull-center">
                        {!! app('captcha')->display() !!}

                        @if($errors->has('g-recaptcha-response'))
                            <span class="help-block">
                                <strong>{{ $errors->first('g-recaptcha-response') }}</strong>
                            </span>
                        @endif
                    </div>
                </div>
                <div class="row">
                    @if (session('errors'))
                    <div class="col-md-12">
                        <div class="alert alert-danger" role="alert">
                            Email atau Password salah!
                            <!--{{ session('errors') }} -->
                        </div>
                    </div>
                    @endif

                    <div class="col-6">
                        <button class="btn btn-primary px-4">Login</button>
                    </div>
                    {{-- <div class="col-6">
                        <button class="btn btn-link px-0" type="button">Forgot password?</button>
                    </div> --}}
                </div>
            </form>
            <p class="m-t"> <small>PT Pura Group &copy; 2020</small> </p>
        </div>
    </div>

    <!-- Mainly scripts -->
    <script src="{{ secure_asset('js/jquery-3.1.1.min.js') }}"></script>
    <script src="{{ secure_asset('js/bootstrap.min.js') }}"></script>
    <script src='https://www.google.com/recaptcha/api.js'></script>
</body>

</html>
