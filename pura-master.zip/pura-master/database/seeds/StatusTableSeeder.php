<?php

use Illuminate\Database\Seeder;

class StatusTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('order_statuses')->insert([
            [
                'id'=>'1',
                'name'=>'Belum Dibayar',
            ],
            [
                'id'=>'2',
                'name'=>'Menunggu Pembayaran Diverifikasi',
            ],
            [
                'id'=>'3',
                'name'=>'Pembayaran Terverifikasi',
            ],
            [
                'id'=>'4',
                'name'=>'Pembayaran Ditolak',
            ],
            [
                'id'=>'5',
                'name'=>'Sedang Diproses',
            ],
            [
                'id'=>'6',
                'name'=>'Proses Pengiriman',
            ],
            [
                'id'=>'7',
                'name'=>'Pesanan Selesai',
            ],
            [
                'id'=>'8',
                'name'=>'Pesanan Ditolak',
            ],
            [
                'id'=>'9',
                'name'=>'Pesanan Dibatalkan',
            ],
            [
                'id'=>'10',
                'name'=>'Pesanan Dikomplain',
            ],
        ]);
    }
}
