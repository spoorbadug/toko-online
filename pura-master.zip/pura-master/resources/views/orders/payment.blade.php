@extends('layouts.app')

@section('title')
<title>Bayar Pesanan</title>
@endsection

@section('content')
<div class="main-container container">
    <ul class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i></a></li>
        <li><a href="#">Akun</a></li>
        <li><a href="#">Bayar Pesanan</a></li>
    </ul>
    <div class="row">
        <!--Middle Part Start-->
        <div id="content" class="col-sm-12">
            <h2 class="title">Informasi Pembayaran</h2>
            <!-- KETIKA ADA SESSION SUCCESS  -->
            @if(session('success'))
                <!-- MAKA TAMPILKAN ALERT SUCCESS -->
                <div class="alert alert-success">{{ session('success') }}</div>
            @endif

            <!-- KETIKA ADA SESSION ERROR  -->
            @if(session('error'))
                <!-- MAKA TAMPILKAN ALERT DANGER -->
                <div class="alert alert-danger">{{ session('error') }}</div>
            @endif
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <td colspan="2" class="text-left">Detail Pesanan</td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="text-left">
                            <b>ID Pesanan :</b> {{ $order->invoice }}
                            <br>
                            <b>Tanggal Pesanan :</b> {{ $order->created_at->format('d-m-Y') }}
                            <br>
                            <b>Status Pesanan :</b> {{ $order->status->name }}
                            <br>
                            <b>Bank Pembayaran :</b> {{ $order->bank->nama_bank }}
                            <br>
                            <b>Yang Harus Dibayar :</b> Rp. {{ number_format($order->total) }}</td>
                    </tr>
                </tbody>
            </table>
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <td colspan="3" class="text-left">Nomor Rekening</td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="text-left">
                                <b>{{ $order->bank->nama_bank }} : </b>
                                <br>
                        </td>
                        <td class="text-left">
                                {{ $order->bank->no_rek }}
                                <br>
                        </td>
                        <td class="text-left">
                                {{ $order->bank->nama_pemilik }}
                                <br>
                        </td>
                    </tr>
                </tbody>
            </table>
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <td style="vertical-align: top;" class="text-left">Upload Bukti Pembayaran</td>
                    </tr>
                </thead>
                <tbody>
                    @if($order->status_id == '1')
                    <form method="post" action="{{ route('order.bayar', $order->id) }}"
                        enctype="multipart/form-data">
                        @csrf
                        <tr>
                            <td class="text-left">
                                <input type="hidden" name="bank_tujuan" value="{{ $order->bank->id }}">
                                <div class="form-group">
                                    <label class="col-sm-2">Nama Pemilik Bank</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="nama_pemilik" class="form-control"
                                            value="{{ old('nama_pemilik') }}" required>
                                    </div>
                                </div>
                                {{-- <div class="form-group">
                                    <label class="col-sm-2">Bank Tujuan</label>
                                    <div class="col-sm-10">
                                        <select name="bank_tujuan" class="form-control" required>
                                            <option selected>Pilih...</option>
                                            @foreach($banks as $item)
                                                <option value="{{ $item->id }}"
                                                    {{ old('bank_tujuan') == $item->id ? 'selected':'' }}>
                                                    {{ $item->nama_bank }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div> --}}
                                <div class="form-group">
                                    <label class="col-sm-2">Unggah Bukti Bayar</label>
                                    <div class="col-sm-10">
                                        <input type="file" name="bukti_bayar"
                                            value="{{ old('bukti_bayar') }}" required>
                                        <p class="text-danger">{{ $errors->first('bukti_bayar') }}
                                        </p>
                                    </div>
                                </div>
                                <div class="form-group text-right">
                                    <button class="btn btn-primary">Konfirmasi Pembayaran</button>
                                </div>
                            </td>
                        </tr>
                    </form>
                    @else
                    <tr>
                        <td><div class="alert alert-success"><i class="fa fa-check-circle"></i>
                            Bukti pembayaran anda telah kami terima.</div></td>
                    </tr>
                    @endif
                </tbody>
                
            </table>
        </div>
        <!--Middle Part End-->
    </div>


</div>

@endsection
