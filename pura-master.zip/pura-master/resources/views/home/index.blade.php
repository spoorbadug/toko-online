@extends('layouts.app')

@section('title')
<title>Pura Bisnis</title>
@endsection

@section('content')
<main class="main">

    <body class="common-home res layout-2">
        <div id="wrapper" class="wrapper-fluid banners-effect-8">
            <!-- Main Container  -->
            <div class="main-container">
                <div id="content">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            </div>
                            <div class="col-lg-9 col-md-12 col-sm-12 col-xs-12 slideshow-full">
                                <div class="module sohomepage-slider ">
                                    <div class="yt-content-slider" data-rtl="yes" data-autoplay="no"
                                        data-autoheight="no" data-delay="4" data-speed="0.6" data-margin="0"
                                        data-items_column00="1" data-items_column0="1" data-items_column1="1"
                                        data-items_column2="1" data-items_column3="1" data-items_column4="1"
                                        data-arrows="yes" data-pagination="no" data-lazyload="yes" data-loop="no"
                                        data-hoverpause="yes">
                                        <div class="yt-content-slide">
                                            <a href="#"><img src="image/pura/home-slide1.jpg" alt="slider1"
                                                    class="img-responsive"></a>
                                        </div>
                                        <div class="yt-content-slide">
                                            <a href="#"><img src="image/pura/home-slide2.jpg" alt="slider2"
                                                    class="img-responsive"></a>
                                        </div>
                                        <div class="yt-content-slide">
                                            <a href="#"><img src="image/pura/home-slide3.jpg" alt="slider3"
                                                    class="img-responsive"></a>
                                        </div>
                                        <div class="yt-content-slide">
                                            <a href="#"><img src="image/pura/home-slide4.jpg" alt="slider3"
                                                    class="img-responsive"></a>
                                        </div>
                                        <div class="yt-content-slide">
                                            <a href="#"><img src="image/pura/home-slide5.jpg" alt="slider3"
                                                    class="img-responsive"></a>
                                        </div>
                                        <div class="yt-content-slide">
                                            <a href="#"><img src="image/pura/home-slide6.jpg" alt="slider3"
                                                    class="img-responsive"></a>
                                        </div>
                                        <div class="yt-content-slide">
                                            <a href="#"><img src="image/pura/home-slide7.jpg" alt="slider3"
                                                    class="img-responsive"></a>
                                        </div>
                                        <div class="yt-content-slide">
                                            <a href="#"><img src="image/pura/home-slide8.jpg" alt="slider3"
                                                    class="img-responsive"></a>
                                        </div>
                                        <div class="yt-content-slide">
                                            <a href="#"><img src="image/pura/home-slide9.jpg" alt="slider3"
                                                    class="img-responsive"></a>
                                        </div>
                                    </div>

                                    <div class="loadeding"></div>
                                </div>
                            </div>
                        </div>

                        
                    </div>

                    <div class="content-main-w">

                        <div class="container">
                            <!-- Extra new arrivals -->
                            <div class="module extra-layout1">
                                {{-- <div class="pre_text">
                                    Top sale in the week
                                </div> --}}
                                <h3 class="modtitle"><span>Produk Baru</span></h3>
                                <div class="modcontent">
                                    <div id="so_extra_slider_12" class="so-extraslider button-type1">
                                        <div class="products-list yt-content-slider extraslider-inner" data-rtl="yes"
                                            data-pagination="no" data-arrows="no" data-autoplay="no" data-delay="4"
                                            data-speed="0.6" data-margin="30" data-items_column00="4"
                                            data-items_column0="4" data-items_column1="3" data-items_column2="3"
                                            data-items_column3="2" data-items_column4="1" data-lazyload="yes"
                                            data-loop="no" data-buttonpage="top">
                                            @forelse($newproducts as $row)
                                                <div class="item">
                                                    <div class="product-layout product-grid">
                                                        <div class="item-inner product-layout transition product-grid">
                                                            <div class="product-item-container item--static">
                                                                <div class="left-block">
                                                                    <div class="product-image-container second_img">
                                                                        <a href="{{ url('/produk/' . $row->slug) }}" target="_self"
                                                                            title="{{ $row->name }}">
                                                                            
                                                                            <img src="{{ asset('storage/products/'.$row->image) }}"
                                                                                class="img-1 img-responsive"
                                                                                alt="{{ $row->name }}" style="height: 250px">
                                                                            
                                                                        </a>
                                                                    </div>
                                                                    <span class="label-product label-new">New</span>
                                                                    <!--quickview-->
                                                                    <div class="so-quickview">
                                                                        <a class="iframe-link btn-button quickview quickview_handler visible-lg"
                                                                            href="quickview.html" title="Quick view"
                                                                            data-fancybox-type="iframe"><i
                                                                                class="fa fa-search"></i><span>Quick
                                                                                view</span></a>
                                                                    </div>
                                                                    <!--end quickview-->
                                                                </div>
                                                                <div class="right-block">
                                                                    <div class="button-group cartinfo--static">
                                                                        <form action="{{ route('front.cart') }}" method="POST">
                                                                            @csrf
                                                                            <input type="hidden" name="qty" id="sst" maxlength="12" value="{{ $row->min_order }}"
                                                                            title="Quantity:" class="input-text qty">
                                                                            <input type="hidden" name="product_id" value="{{ $row->id }}" class="form-control">
                                                                            
                                                                            <button type="submit" class="main_btn" title="Add to cart">
                                                                                <span>Add to cart </span>
                                                                            </button>
                                                                        </form>
                                                                    </div>
                                                                    <h4><a href="product.html"
                                                                            title="{{ $row->name }}"
                                                                            target="_self">{{ $row->name }}</a></h4>
                                                                    <div class="rating"> <span class="fa fa-stack"><i
                                                                                class="fa fa-star fa-stack-2x"></i></span>
                                                                        <span class="fa fa-stack"><i
                                                                                class="fa fa-star fa-stack-2x"></i></span>
                                                                        <span class="fa fa-stack"><i
                                                                                class="fa fa-star fa-stack-2x"></i></span>
                                                                        <span class="fa fa-stack"><i
                                                                                class="fa fa-star fa-stack-2x"></i></span>
                                                                        <span class="fa fa-stack"><i
                                                                                class="fa fa-star fa-stack-2x"></i></span>
                                                                    </div>
                                                                    <div class="price">
                                                                        <span class="price">Rp
                                                                            {{ number_format($row->price) }}</span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            @empty
                                            @endforelse
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end Extra new arrivals -->
                        </div>

                        

                    </div>
                </div>
            </div>
            <!-- //Main Container -->





        </div>
    </body>
</main>
@endsection
