<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class KomplainStatus extends Model
{
    public function komplain()
    {
        return $this->hasOne(Komplain::class);
    }
}
