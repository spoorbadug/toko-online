@extends('layouts.admin')

@section('title')
<title>Order</title>
@endsection

@section('menuside')
<li>
    <a href="{{ route('admin.index') }}"><i class="fa fa-th-large"></i>
        <span class="nav-label">Dashboard</span></a>
</li>
<li>
    <a href="#"><i class="fa fa-user"></i><span class="fa arrow"></span>
        <span class="nav-label">Kelola User</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('admin.user') }}">Customer</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('admin.admin') }}">Admin</a></li>
    </ul>
</li>
<li>
    <a href="#"><i class="fa fa-archive"></i><span class="fa arrow"></span>
        <span class="nav-label">Product</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('product.index') }}">List Produk</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('product.create') }}">Tambah Produk</a></li>
    </ul>
</li>
<li>
    <a href="{{ route('category.index') }}"><i class="fa fa-industry"></i> <span
            class="nav-label">Category</span></a>
</li>
<li class="active">
    <a href="{{ route('admin.order') }}"><i class="fa fa-cart-plus"></i> <span
            class="nav-label">Order</span></a>
</li>
<li>
    <a href="{{ route('admin.indexbank') }}"><i class="fa fa-credit-card"></i> <span
            class="nav-label">Rekening Bank</span></a>
</li>
<li>
    <a href="{{ route('admin.edit') }}"><i class="fa fa-address-card"></i>
        <span class="nav-label">Profile</span></a>
</li>
<li>
    <a href=""><i class="fa fa-navicon"></i><span class="fa arrow"></span>
        <span class="nav-label">Syarat & Ketentuan</span></a>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.sk') }}">List SK</a></li>
        </ul>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.formsk') }}">Tambah SK</a></li>
        </ul>
</li>
@endsection

@section('content')
<main class="main">
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>Daftar Pesanan</h2>
            <ol class="breadcrumb">
                <li>Home
                </li>
                <li class="active">
                    <strong>Order</strong>
                </li>
            </ol>
        </div>
        <div class="col-lg-2"></div>
    </div>
    <div class="container-fluid">
        <div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox">
                        <div class="ibox-content">
                            <form action="#" method="get">
                                <div class="input-group mb-10 col-md-12 float-right">
                                    <input type="text" class="form-control" placeholder="Cari..."
                                        value="{{ request()->q }}">
                                    <span class="input-group-btn"> <button type="button" class="btn btn-default">Cari
                                        </button></span>
                                </div>
                            </form>
                            <table class="table table-hover table-bordered">
                                <thead>
                                    <tr>
                                        <th>InvoiceID</th>
                                        <th>Pelanggan</th>
                                        <th>Subtotal</th>
                                        <th>Tanggal</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($orders as $row)
                                        <tr>
                                            <td>{{ $row->invoice }}</td>
                                            <td>{{ $row->profile->name }}</td>
                                            <td>Rp {{ number_format($row->total) }}</td>
                                            <td>{{ $row->created_at->format('d-m-Y') }}</td>
                                            <td>{!! $row->status->name !!}</td>
                                            <td class="text-left">
                                                <div class="btn-group">
                                                    <form
                                                        action="{{ route('admin.destroyorder', $row->id) }}"
                                                        method="post">
                                                        @csrf
                                                        @method('DELETE')
                                                        <a href="{{ route('admin.showorder', $row->id) }}"
                                                            class="btn btn-info btn-sm">Lihat</a>
                                                        <a href="{{ route('admin.editorder', $row->id) }}"
                                                            class="btn btn-warning btn-sm">Edit</a>
                                                        <button class="btn btn-danger btn-sm">Hapus</button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="6" class="text-center">Tidak ada data</td>
                                        </tr>
                                    @endforelse

                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="7">
                                            <ul class="pagination pull-right"></ul>
                                            {!! $orders->links() !!}
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

@endsection
