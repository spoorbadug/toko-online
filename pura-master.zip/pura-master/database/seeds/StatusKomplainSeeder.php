<?php

use Illuminate\Database\Seeder;

class StatusKomplainSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('komplain_statuses')->insert([
            [
                'id'=>'1',
                'name'=>'Produk Rusak',
            ],
            [
                'id'=>'2',
                'name'=>'Jumlah Produk Kurang',
            ],
            [
                'id'=>'3',
                'name'=>'Produk Belum Sampai/Hilang',
            ],
            [
                'id'=>'4',
                'name'=>'Produk Tidak Sesuai',
            ],
        ]);
    }
}
