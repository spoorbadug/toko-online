@extends('layouts.admin')

@section('title')
<title>Kelola User</title>
<link rel="stylesheet" href="sweetalert/style.css">
	<script src="sweetalert/script.js"></script>
@endsection

@section('menuside')
<li>
    <a href="{{ route('admin.index') }}"><i class="fa fa-th-large"></i>
        <span class="nav-label">Dashboard</span></a>
</li>
<li class="active">
    <a href="#"><i class="fa fa-user"></i><span class="fa arrow"></span>
        <span class="nav-label">Kelola User</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('admin.user') }}">Customer</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li class="active"><a href="{{ route('admin.admin') }}">Admin</a></li>
    </ul>
</li>
<li>
    <a href="#"><i class="fa fa-archive"></i><span class="fa arrow"></span>
        <span class="nav-label">Product</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('product.index') }}">List Produk</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('product.create') }}">Tambah Produk</a></li>
    </ul>
</li>
<li>
    <a href="{{ route('category.index') }}"><i class="fa fa-industry"></i> <span
            class="nav-label">Category</span></a>
</li>
<li>
    <a href="{{ route('admin.order') }}"><i class="fa fa-cart-plus"></i> <span
            class="nav-label">Order</span></a>
</li>
<li>
    <a href="{{ route('admin.indexbank') }}"><i class="fa fa-credit-card"></i> <span
            class="nav-label">Rekening Bank</span></a>
</li>
<li>
    <a href="{{ route('admin.edit') }}"><i class="fa fa-address-card"></i>
        <span class="nav-label">Profile</span></a>
</li>
<li>
    <a href=""><i class="fa fa-navicon"></i><span class="fa arrow"></span>
        <span class="nav-label">Syarat & Ketentuan</span></a>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.sk') }}">List SK</a></li>
        </ul>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.formsk') }}">Tambah SK</a></li>
        </ul>
</li>
@endsection

@section('content')
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>List Admin</h2>
        <ol class="breadcrumb">
            <li>Home
            </li>
            <li>Kelola User
            </li>
            <li class="active">
                <strong>List Admin</strong>
            </li>
        </ol>
    </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <div class="col-md-8">
            <div class="ibox-content">
                <div class="card-header">
                    <h4 class="card-title">List Admin</h4>
                </div>
                <form action="{{ route('admin.admin') }}" method="get">
                    <div class="input-group">
                        <!-- KEMUDIAN NAME-NYA ADALAH Q YANG AKAN MENAMPUNG DATA PENCARIAN -->
                        <input type="text" class="form-control" placeholder="Cari..." value="{{ request()->q }}">
                        <span class="input-group-btn"> <input type="submit" value="Cari" class="btn btn-default">
                        </span>
                    </div>
                </form>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Role</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($xdmin as $no => $user)
                                <tr>
                                    <th scope="row">{{ ++$no }}</th>
                                    <td>{{ $user->name }}</td>
                                    <td>{{ $user->email }}</td>
                                    <td>{{ $user->role }}</td>
                                    <td>
                                        <!-- FORM ACTION UNTUK METHOD DELETE -->
                                        <form action="{{ route('admin.hapus', $user->id) }}" method="post">
                                            <!-- KONVERSI DARI @ CSRF & @ METHOD AKAN DIJELASKAN DIBAWAH -->
                                            @csrf
                                            @method('DELETE')
                                            <button class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus?')">Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="ibox-content">
                <div class="card-header">
                    <h4 class="card-title">Tambah Admin Baru</h4>
                </div>
                <div class="card-body">
                    <form method="POST" action="{{ route('admin.add') }}">
                        @csrf
                        <div class="form-group">
                            <label for="name">Nama</label>
                            <input type="text" name="name" class="form-control" required>
                            <p class="text-danger">{{ $errors->first('name') }}</p>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" name="email" class="form-control" required>
                            <p class="text-danger">{{ $errors->first('email') }}</p>
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" name="password" class="form-control" required>
                            <p class="text-danger">{{ $errors->first('password') }}</p>
                        </div>
                        <div class="form-group">
                            <label for="role">Role</label>
                            <select name="role" class="form-control" required>
                                <option value="">-- Pilih --</option>
                                <option value="Admin">Admin</option>
                                <option value="Unit">Unit</option>
                                <option value="Keuangan">Keuangan</option>
                                {{-- @foreach ($roles as $r)
                                    <option value="{{ $r->id }}">{{ $r->name }}</option>
                                @endforeach --}}
                            </select>
                            <p class="text-danger">{{ $errors->first('role') }}</p>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary btn-sm">Tambah</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@section('js')
<script>
	function klik(){
		swal("Yes!", "Makasih udah diklik mas", "success")
	}
</script>
@endsection