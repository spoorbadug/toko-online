@extends('layouts.app')

@section('title')
<title>Checkout</title>
<meta name="csrf-token" content="{{ csrf_token() }}">
@endsection

@section('content')
<!-- Main Container  -->
<div class="main-container container">
    <ul class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i></a></li>
        <li><a href="#">Checkout</a></li>

    </ul>

    <div class="row">
        <!--Middle Part Start-->
        <div id="content" class="col-sm-12">
            <h2 class="title">Checkout</h2>
            <div class="so-onepagecheckout row">
                <form class="row contact_form" action="{{ route('checkout') }}" method="post">
                    @csrf
                    <div class="col-right col-sm-12">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-default no-padding">
                                    <div class="col-sm-4 checkout-shipping-methods">
                                        <div class="panel-heading">
                                            <h4 class="panel-title"><i class="fa fa-book"></i> Alamat
                                            </h4>
                                        </div>
                                        <div class="panel-body">
                                            <p>Pilih alamat yang diinginkan untuk digunakan pada pesanan ini.</p>
                                            <div class="input-group required" style="width: 100%">
                                                <select class="form-control alamat" id="alamat" name="alamat">
                                                    <option value="0">--- Plih Alamat Tujuan ---</option>
                                                    @foreach($profile as $row)
                                                        <option value="{{ $row->city_id }}">{{ $row->name_address }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-4 checkout-shipping-methods">
                                        <div class="panel-heading">
                                            <h4 class="panel-title"><i class="fa fa-truck"></i> Pengiriman</h4>
                                        </div>
                                        <div class="panel-body ">
                                            <p>Pilih kurir pengiriman yang diinginkan untuk digunakan pada pesanan ini.</p>
                                            <div class="input-group">
                                                <select class="form-control kurir" name="kurir" id="kurir">
                                                    <option value="">--- Pilih Kurir ---</option>
                                                    <option value="pura shipment">Pura Shipment</option>
                                                    <option value="jne">JNE Reg</option>
                                                    <option value="pos">POS Kilat Khusus</option>
                                                    <option value="tiki">TIKI Reg</option>
                                                </select>
                                                <span class="input-group-btn"><button type="button" class="btn btn-primary tombol" name="tombol" id="tombol">Cek Ongkir</button></span>
                                            </div>
                                        </div>
                                        
                                        <div class="buttons">
                                            {{-- <div class="pull-right"> --}}
                                                    {{-- <a type="button" id="tombol">cek ongkir</a> --}}
                                                
                                            {{-- </div> --}}
                                        </div>
                                    
                                    </div>
                                    <div class="col-sm-4  checkout-payment-methods">
                                        <div class="panel-heading">
                                            <h4 class="panel-title"><i class="fa fa-credit-card"></i> Pembayaran
                                            </h4>
                                        </div>
                                        <div class="panel-body">
                                            <p>Pilih rekening bank yang diinginkan untuk digunakan pada pesanan ini.</p>
                                            <div class="input-group required" style="width: 100%">
                                                <select class="form-control" id="bank_id" name="bank_id">
                                                    <option value="">--- Plih Rekening Tujuan ---</option>
                                                    @foreach($banks as $row)
                                                        <option value="{{ $row->id }}">{{ $row->nama_bank }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title"><i class="fa fa-shopping-cart"></i> Keranjang Belanja
                                        </h4>
                                    </div>
                                    <div class="panel-body">
                                        <div class="table-responsive">
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <td class="text-center">Gambar</td>
                                                        <td class="text-left">Nama Produk</td>
                                                        <td class="text-left">Jumlah</td>
                                                        <td class="text-right">Harga Barang</td>
                                                        <td class="text-right">Total</td>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @forelse($carts as $row)
                                                        <tr>

                                                            <td class="text-center"><img
                                                                        width="60px"
                                                                        src="{{ asset('/storage/products/' . $row['product_image']) }}"
                                                                        alt="{{ $row['product_name'] }}"
                                                                        title="{{ $row['product_name'] }}"
                                                                        class="img-thumbnail"></td>
                                                            <td class="text-left">{{ $row['product_name'] }}
                                                            </td>
                                                            <td class="text-left">
                                                                {{ $row['qty'] }}</td>
                                                            <td class="text-right">Rp
                                                                {{ number_format($row['product_price']) }}
                                                            </td>
                                                            <td class="text-right">Rp
                                                                {{ number_format($row['product_price'] * $row['qty']) }}
                                                            </td>
                                                        </tr>
                                                    @empty
                                                        <tr>
                                                            <td colspan="4">Tidak ada belanjaan</td>
                                                        </tr>
                                                    @endforelse
                                                </tbody>
                                                <tfoot id="ongkir">
                                                    <tr>
                                                        <td class="text-right" colspan="4">
                                                            <strong>Sub-Total:</strong>
                                                        </td>
                                                        <td class="text-right">Rp {{ number_format($subtotal) }}
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-right" colspan="4"><strong>Ongkos
                                                                Kirim:</strong></td>

                                                        <td class="text-right" id="hasil">Rp 0</td>
                                                        


                                                    </tr>
                                                    <tr>
                                                        <td class="text-right" colspan="4"><strong>Total:</strong>
                                                        </td>
                                                        <td class="text-right" id="hasiltotal">Rp 0</td>
                                                    </tr>
                                                </tfoot>
                                            </table>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title"><i class="fa fa-pencil"></i> Tambahkan Catatan Khusus (Opsional)
                                        </h4>
                                    </div>
                                    <div class="panel-body">
                                        <textarea rows="4" class="form-control" id="catatan"
                                            name="catatan"></textarea>
                                        <br>
                                        <label class="control-label" for="confirm_agree">
                                            <input type="checkbox" checked="checked" value="1" required=""
                                                class="validate required" id="confirm_agree" name="confirm agree">
                                            <span>I have read and agree to the <a class="agree" href="#"><b>Terms &amp;
                                                        Conditions</b></a></span> </label>
                                        <div class="buttons">
                                            <div class="pull-right">
                                                <button class="btn btn-primary" id="konfirmasi"
                                                    name="konfirmasi">Konfirmasi Pesanan</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            

                        </div>
                    </div>
                </form>
                
                <div id="hasil"></div> 
            </div>
        </div>
        <!--Middle Part End -->

    </div>
</div>
<!-- //Main Container -->
@endsection

@section('js')
<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>

{{-- <script>
    $(document).ready(function () {

        //ajax select kota asal
        $('select[name="province_origin"]').on('change', function () {
            let provindeId = $(this).val();
            if (provindeId) {
                jQuery.ajax({
                    url: '/cities/' + provindeId,
                    type: "GET",
                    dataType: "json",
                    success: function (response) {
                        $('select[name="city_origin"]').empty();
                        $('select[name="city_origin"]').append(
                            '<option value="">-- pilih kota asal --</option>');
                        $.each(response, function (key, value) {
                            $('select[name="city_origin"]').append(
                                '<option value="' + key + '">' + value +
                                '</option>');
                        });
                    },
                });
            } else {
                $('select[name="city_origin"]').append(
                    '<option value="">-- pilih kota asal --</option>');
            }
        });
        //ajax select kota tujuan
        $('select[name="province_tujuan"]').on('change', function () {
            let provindeId = $(this).val();
            if (provindeId) {
                jQuery.ajax({
                    url: '/cities/' + provindeId,
                    type: "GET",
                    dataType: "json",
                    success: function (response) {
                        $('select[name="city_tujuan"]').empty();
                        $('select[name="city_tujuan"]').append(
                            '<option value="">-- pilih kota tujuan --</option>');
                        $.each(response, function (key, value) {
                            $('select[name="city_tujuan"]').append(
                                '<option value="' + key + '">' + value +
                                '</option>');
                        });
                    },
                });
            } else {
                $('select[name="city_tujuan"]').append(
                    '<option value="">-- pilih kota tujuan --</option>');
            }
        });
        
    });

</script> --}}


<script>
    $(document).ready(function(){
        $('#tombol').click(function(){
            var token            = $("meta[name='csrf-token']").attr("content");
            var alamatId      = $('select[name=alamat]').val();
            var kurirId         = $('select[name=kurir]').val();
            
            jQuery.ajax({
                url: '/user/checkout-ongkir',
                data: {
                    _token:token, 
                    alamat:alamatId, 
                    kurir:kurirId
                },
                dataType: "json",
                type: "POST",
                success: function(response) {
                    $('#hasil').empty();
                    $('#hasil').append('Rp '+parseInt(response).toLocaleString());
                    //alert(msg);
                    $.ajax({
                        url: '/user/checkout-total/'+response,
                        type: 'GET',
                        success: function(msgg) {
                            //alert(msg);
                            $('#hasiltotal').empty();
                            $('#hasiltotal').append('Rp '+parseInt(msgg).toLocaleString());

                            
                            // $('#hasil').html(msg);
                        },
                    });

                    
                    // $('#hasil').html(response);
                },
                error: function(response) {
                    alert(response);
                }
            });

            
        });
        

        
    });
</script>

{{-- <script>
    $(document).ready(function(){
        $('#konfirmasi').click(function(){
            var token            = $("meta[name='csrf-token']").attr("content");
            var alamatId      = $('select[name=alamat]').val();
            var kurirId         = $('select[name=kurir]').val();
            
            jQuery.ajax({
                url: '/checkout',
                data: {
                    _token:token, 
                    alamat:alamatId, 
                    kurir:kurirId
                },
                dataType: "json",
                type: "POST",
                
            });

            
        });
        

        
    });
</script> --}}

@endsection
