<?php

namespace App\Http\Controllers;

use App;
use App\Product;
use App\Category;
use App\Stock;
use App\Profile;
use App\Cart;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use DB;
use Session;
use Auth;
use File;
use Alert;

class ProductController extends Controller
{

    public function index() {
        
        if (Auth::user()->role == 'Admin') {
            
            $products=Product::with(['category'])->orderBy('created_at', 'DESC')->paginate(10);
            // if (request()->q !='') {
            //     //MAKA LAKUKAN FILTERING DATA BERDASARKAN NAME DAN VALUENYA SESUAI DENGAN PENCARIAN YANG DILAKUKAN USER
            //     $product=$product->where('name', 'LIKE', '%'. request()->q . '%');
            // }

            // $product=$product->paginate(10);

            return view('admin.product', compact('products'));
            
        } else {
            return view('/');
        }

    }

    public function show($slug)
    {   
        $showproduct = Product::where('slug', $slug)->orderBy('created_at', 'DESC')->first();
        $unit = Category::where('id', $showproduct->category_id)->first();
        $products = Product::take(4)->get();
        $profiles = Profile::where('id', $unit->id)->first();
        return view('products.show', compact('products','showproduct', 'unit', 'profiles'));
    }

    public function create()
    {

        if (Auth::user()->role == 'Admin') {

            $category=Category::orderBy('name', 'DESC')->get();
            return view('admin.addproduct', compact('category'));

        } else {
            return view('/');
        }
    }

    public function store(Request $request)
    {
        $this->validate(request(),[
            'name'=>'required|string',
            'description'=> 'required',
            'price'=>'required|integer',
            'weight'=> 'required|integer',
            'stock'=> 'required|integer',
            'min'=> 'required|integer',
            'category_id'=>'required|exists:categories,id'
        ]);

       

        if ($request->hasFile('image')) {
            //MAKA KITA SIMPAN SEMENTARA FILE TERSEBUT KEDALAM VARIABLE FILE
            $file = $request->file('image');
            //KEMUDIAN NAMA FILENYA KITA BUAT CUSTOMER DENGAN PERPADUAN TIME DAN SLUG DARI NAMA PRODUK. ADAPUN EXTENSIONNYA KITA GUNAKAN BAWAAN FILE TERSEBUT
            $filename = time() . Str::slug($request->name) . '.' . $file->getClientOriginalExtension();
            //SIMPAN FILENYA KEDALAM FOLDER PUBLIC/PRODUCTS, DAN PARAMETER KEDUA ADALAH NAMA CUSTOM UNTUK FILE TERSEBUT
            $file->storeAs('public/products', $filename);
    
            //SETELAH FILE TERSEBUT DISIMPAN, KITA SIMPAN INFORMASI PRODUKNYA KEDALAM DATABASE
            $product = Product::create([
                'name' => $request->name,
                'slug' => $request->name,
                'category_id' => $request->category_id,
                'description' => $request->description,
                'image' => $filename, //PASTIKAN MENGGUNAKAN VARIABLE FILENAM YANG HANYA BERISI NAMA FILE SAJA (STRING)
                'price' => $request->price,
                'weight' => $request->weight,
                'stok' => $request->stock,
                'min_order' => $request->min,
                'status' => $request->status
            ]);
            alert()->success('Berhasil','Berhasil menambahkan produk');
            //JIKA SUDAH MAKA REDIRECT KE LIST PRODUK
            return redirect(route('product.index'));
        }
    }
    
    public function edit($id) {
        
        if (Auth::user()->role == 'Admin') {

            $product=Product::find($id); //AMBIL DATA PRODUK TERKAIT BERDASARKAN ID
            $category=Category::orderBy('name', 'DESC')->get(); //AMBIL SEMUA DATA KATEGORI
            return view('admin.editproduct', compact('product', 'category'));

        } else {
            return view('/');
        }
    }

    public function update(Request $request, $id) {
        //VALIDASI DATA YANG DIKIRIM
        $this->validate($request, [ 'name'=> 'required|string|max:100',
            'description'=> 'required',
            'category_id'=> 'required|exists:categories,id',
            'price'=> 'required|integer',
            'weight'=> 'required|integer',
            'image'=> 'nullable|image|mimes:png,jpeg,jpg' //IMAGE BISA NULLABLE
            ]);

            

        $product=Product::find($id); //AMBIL DATA PRODUK YANG AKAN DIEDIT BERDASARKAN ID
        $filename=$product->image; //SIMPAN SEMENTARA NAMA FILE IMAGE SAAT INI

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $filename = time() . Str::slug($request->name) . '.' . $file->getClientOriginalExtension();
            //MAKA UPLOAD FILE TERSEBUT
            $file->storeAs('public/products', $filename);
              //DAN HAPUS FILE GAMBAR YANG LAMA
            File::delete(storage_path('app/public/products/' . $product->image));
        }
    

        //KEMUDIAN UPDATE PRODUK TERSEBUT
        $product->update([
            'name' => $request->name,
            'description' => $request->description,
            'category_id' => $request->category_id,
            'price' => $request->price,
            'weight' => $request->weight,
            'image' => $filename,
            'status' => $request->status
        ]);
        alert()->success('Berhasil','Berhasil mengubah data produk');
        return redirect(route('product.index'));
    }
    
    public function destroy($id)
    {
        Product::where('id',$id)->delete();
        Stock::where('product_id',$id)->delete();
        alert()->success('Berhasil','Berhasil menghapus produk');
        return redirect()->route('product.index')->with('success','Successfully removed the product!');
    }

    public function list()
    {

        //$categories = Category::orderBy('id', 'DESC');
        //$products = Category::where('status', 1)->first()->product()->orderBy('created_at', 'DESC')->paginate(10);
        // if($products->category->status_id == 1){
        //     return view('products.index',compact('products', 'showproduct', 'unit'));
        // }
        //dd($products);

        
        $products = Product::orderBy('created_at', 'DESC')->paginate(10);
        
        $showproduct = Product::orderBy('created_at', 'DESC')->first();
        if($showproduct == null){
            return view('products.index',compact('products', 'showproduct'));
        }
        $unit = Category::where('id', $showproduct->category_id)->first();
        
        return view('products.index',compact('products', 'showproduct', 'unit'));
    }

    
}