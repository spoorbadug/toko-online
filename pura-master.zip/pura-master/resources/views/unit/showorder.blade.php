@extends('layouts.admin')

@section('title')
<title>Order Detail</title>
@endsection

@section('menuside')
<li>
    <a href="{{ route('unit.index') }}"><i class="fa fa-th-large"></i>
        <span class="nav-label">Dashboard</span></a>
</li>
<li>
    <a href="{{ route('categoryunit.index') }}"><i class="fa fa-industry"></i>
        <span class="nav-label">Category</span></a>
</li>
<li>
    <a href="#"><i class="fa fa-archive"></i><span class="fa arrow"></span>
        <span class="nav-label">Product</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('productunit.index') }}">List Produk</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('productunit.create') }}">Tambah Produk</a></li>
    </ul>
</li>
<li class="active">
    <a href="{{ route('unit.order') }}"><i class="fa fa-cart-plus"></i>
        <span class="nav-label">Order</span></a>
</li>
<li>
    <a href="{{ route('unit.edit') }}"><i class="fa fa-address-card"></i>
        <span class="nav-label">Profile</span></a>
</li>
@endsection

@section ('content')
<main class="main">
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>Info Pesanan</h2>
            <ol class="breadcrumb">
                <li>Home
                </li>
                <li>Order
                </li>
                <li class="active">
                    <strong>Info Pesanan</strong>
                </li>
            </ol>
        </div>
        <div class="col-lg-2">

        </div>
    </div>
    <div class="container-fluid">
        <div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox">
                <div class="ibox-content">
                    <h4 class="title">Informasi Pesanan</h4>
                    <table class="table table-hover table-bordered">
                        <thead>
                            <tr>
                                <td colspan="2" class="text-left"><b>Detail Pesanan</b></td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="width: 50%;" class="text-left"> <b>ID Pesanan :</b> {{ $order->invoice }}
                                    <br>
                                    <b>Tanggal Pesanan :</b> {{ $order->created_at->format('d-m-Y') }}
                                    <br>
                                    <b>Status Pesanan :</b> {{ $order->status->name }} </td>
                                <td style="width: 50%;" class="text-left"> <b>Metode Pembayaran :</b> Transfer Bank {{ $order->bank->nama_bank }}
                                    <br>
                                    <b>Kurir Pengiriman :</b> {{ strtoupper($order->kurir) }} </td>
                            </tr>
                        </tbody>
                    </table>
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                
                                <td style="vertical-align: top;" class="text-left"><b>Alamat Tujuan</b></td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <?php
                                    $cities = \App\City::where('city_id', $order->profile->city_id)->first();
                                    $provinces = \App\Province::where('province_id', $order->profile->province_id)->first();
                                ?>
                                <td class="text-left">{{ $order->profile->name }}
                                    <br>{{ $order->profile->address }}, {{ $cities->name }}, {{ $provinces->name }}
                                    <br>Indonesia
                                </td>
                            </tr>
                        </tbody>
                    </table>
        
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <td colspan="6" class="text-left"><b>Detail Barang</b></td>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($order->details as $row)
                            <tr>
                                <td colspan="2">{{ $row->product->name }}</td>
                                <td>{{ $row->category->user->name }}</td>
                                <td>{{ $row->qty }} Item</td>
                                <td>{{ $row->weight }} Gram</td>
                                <td>Rp. {{ number_format($row->price) }}</td>
                                
                            </tr>
                            @empty
                            <tr>
                                <td colspan="5" class="text-center">Tidak ada data</td>
                            </tr>
                            @endforelse
                            <tr>
                                <td colspan="5" class="text-right"><b>Sub-Total :</b></td>
                                <td><b>Rp. {{ number_format($row->subtotal) }}</b></td>
                            </tr>
                            <tr>
                                <td colspan="5" class="text-right"><b>Ongkos Kirim :</b></td>
                                <td><b>Rp. {{ number_format($row->ongkir) }}</b></td>
                            </tr>
                            <tr>
                                <td colspan="5" class="text-right"><b>Total Belanja :</b></td>
                                <td><b>Rp. {{ number_format($order->total) }}</b></td>
                            </tr>
                        </tbody>
                    </table>
                    
                </div>
                <!--Middle Part End-->
                    </div>
                </div>
            </div>
        </div>
        
    </div>
</main>
    
@endsection