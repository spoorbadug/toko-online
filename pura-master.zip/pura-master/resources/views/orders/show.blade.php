@extends('layouts.app')

@section('title')
    <title>Informasi Pesanan</title>
@endsection

@section('content')
<!-- Main Container  -->
<div class="main-container container">
    <ul class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i></a></li>
        <li><a href="#">Akun</a></li>
        <li><a href="#">Informasi Pesanan</a></li>
    </ul>
    
    <div class="row">
        <!--Middle Part Start-->
        <div id="content" class="col-sm-12">
            <h2 class="title">Informasi Pesanan</h2>
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <td colspan="2" class="text-left">Detail Pesanan</td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td style="width: 50%;" class="text-left"> <b>ID Pesanan :</b> {{ $order->invoice }}
                            <br>
                            <b>Tanggal Pesanan :</b> {{ $order->created_at->format('d-m-Y') }}
                            <br>
                            <b>Status Pesanan :</b> {{ $order->status->name }} </td>
                        <td style="width: 50%;" class="text-left"> <b>Metode Pembayaran :</b> Transfer Bank {{ $order->bank->nama_bank }}
                            <br>
                            <b>Kurir Pengiriman :</b> {{ strtoupper($order->kurir) }} </td>
                    </tr>
                </tbody>
            </table>
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <td style="width: 50%; vertical-align: top;" class="text-left">Alamat Pengirim</td>
						<td style="width: 50%; vertical-align: top;" class="text-left">Alamat Tujuan</td>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $city = \App\City::where('city_id', $order->profile->city_id)->first();
                        $province = \App\Province::where('province_id', $order->profile->province_id)->first();
                    ?>
                    <tr>
                        <td class="text-left">Pura Group Bisnis
                            <br>Jl. AKBP Agil Kusumadya No.KM. 4, Kudus, Jawa Tengah
                            <br>Indonesia
                        </td>
                        <td class="text-left">{{ $order->user->profile->name }}
                            <br>{{ $order->user->profile->address }}, {{ $city->name }}, {{ $province->name }}
                            <br>Indonesia
                        </td>
                    </tr>
                </tbody>
            </table>

            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <td colspan="4" class="text-left">Detail Barang</td>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($order->details as $row)
                    <tr>
                        <td colspan="2">{{ $row->product->name }}</td>
                        <td>{{ $row->qty }} Item</td>
                        <td>{{ number_format($row->price) }}</td>
                        
                    </tr>
                    
                    @empty
                    <tr>
                        <td colspan="4" class="text-center">Tidak ada data</td>
                    </tr>
                    @endforelse
                    <tr>
                        <td colspan="3" class="text-right"><b>Sub-Total :</b></td>
                        <td><b>Rp. {{ number_format($row->subtotal) }}</b></td>
                    </tr>
                    <tr>
                        <td colspan="3" class="text-right"><b>Ongkos Kirim :</b></td>
                        <td><b>Rp. {{ number_format($row->ongkir) }}</b></td>
                    </tr>
                    <tr>
                        <td colspan="3" class="text-right"><b>Total Belanja :</b></td>
                        <td><b>Rp. {{ number_format($order->total) }}</b></td>
                    </tr>
                </tbody>
            </table>
            <div class="buttons">

                <div class="col-sm-10 text-right"><a href="{{ route('order.sukses', $order->invoice) }}" class="btn btn-success">Konfirmasi Pesanan Diterima</a></div>
                <div class="col-sm-2 text-right"><a href="{{ route('order.pay', $order->invoice) }}" class="btn btn-primary">Bayar Pesanan</a></div>
                
            </div>
            
            
        </div>
        <!--Middle Part End-->
    </div>
</div>
<!-- //Main Container -->
@endsection