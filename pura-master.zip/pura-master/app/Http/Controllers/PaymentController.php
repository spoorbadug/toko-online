<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Order;
use App\Payment;
use App\DaftarBank;

class PaymentController extends Controller
{
    public function index($invoice)
    {
        $order = Order::with('bank')->where('invoice', $invoice)->first();
        
        return view('orders.payment', compact('order'));
    }

    public function bank(Request $request)
    {
        $banks = DaftarBank::orderBy('created_at', 'DESC')->paginate(10);
        
        return view('keuangan.bank', compact('banks'));
    }

    public function edit($id)
    {
        $bank = DaftarBank::find($id);
        
        return view('keuangan.editbank');
    }

    

    public function store(Request $request)
    {
        $this->validate(request(),[
            'nama_pemilik'=>'required|string',
            'nama_bank'=> 'required',
            'no_rek'=>'required|integer|unique:daftar_banks'
        ]);
            //SETELAH FILE TERSEBUT DISIMPAN, KITA SIMPAN INFORMASI PRODUKNYA KEDALAM DATABASE
        DaftarBank::create([
            'nama_pemilik' => $request->nama_pemilik,
            'nama_bank' => $request->nama_bank,
            'no_rek' => $request->no_rek
        ]);
            //JIKA SUDAH MAKA REDIRECT KE LIST PRODUK
        return redirect(route('pay.bank'))->with(['success' => 'Rekening Baru Ditambahkan']);
    }

    public function buktibayar(Request $request, $id)
    {

        //dd($request);
        
        if ($request->hasFile('bukti_bayar')) {
            //MAKA KITA SIMPAN SEMENTARA FILE TERSEBUT KEDALAM VARIABLE FILE
            $file = $request->file('bukti_bayar');
            //KEMUDIAN NAMA FILENYA KITA BUAT CUSTOMER DENGAN PERPADUAN TIME DAN SLUG DARI NAMA PRODUK. ADAPUN EXTENSIONNYA KITA GUNAKAN BAWAAN FILE TERSEBUT
            $filename = time() . Str::slug($request->nama_pemilik) . '.' . $file->getClientOriginalExtension();
            //SIMPAN FILENYA KEDALAM FOLDER PUBLIC/PRODUCTS, DAN PARAMETER KEDUA ADALAH NAMA CUSTOM UNTUK FILE TERSEBUT
            $file->storeAs('public/payments', $filename);

            Payment::create([
                'order_id' => $id,
                'nama' => $request->nama_pemilik,
                'bank_id' => $request->bank_tujuan,
                'bukti_bayar' => $filename
            ]);

            $order=Order::find($id);
            $order->update([
                'status_id' => '2'
            ]);
                //JIKA SUDAH MAKA REDIRECT KE LIST PRODUK
            return redirect(route('order.index'))->with(['success' => 'Bukti Pembyaran Telah Dikirim. Silahkan Tunggu Pesanan Diproses.']);
        }
    }

}
