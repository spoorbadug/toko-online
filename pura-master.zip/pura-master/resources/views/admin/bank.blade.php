@extends('layouts.admin')

@section('title')
<title>Rekening Bank</title>
@endsection

@section('menuside')
<li>
    <a href="{{ route('admin.index') }}"><i class="fa fa-th-large"></i>
        <span class="nav-label">Dashboard</span></a>
</li>
<li>
    <a href="#"><i class="fa fa-user"></i><span class="fa arrow"></span>
        <span class="nav-label">Kelola User</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('admin.user') }}">Customer</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('admin.admin') }}">Admin</a></li>
    </ul>
</li>
<li>
    <a href="#"><i class="fa fa-archive"></i><span class="fa arrow"></span>
        <span class="nav-label">Product</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('product.index') }}">List Produk</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('product.create') }}">Tambah Produk</a></li>
    </ul>
</li>
<li>
    <a href="{{ route('category.index') }}"><i class="fa fa-industry"></i> <span
            class="nav-label">Category</span></a>
</li>
<li>
    <a href="{{ route('admin.order') }}"><i class="fa fa-cart-plus"></i> <span
            class="nav-label">Order</span></a>
</li>
<li class="active">
    <a href="{{ route('admin.indexbank') }}"><i class="fa fa-credit-card"></i> <span
            class="nav-label">Rekening Bank</span></a>
</li>
<li>
    <a href="{{ route('admin.edit') }}"><i class="fa fa-address-card"></i>
        <span class="nav-label">Profile</span></a>
</li>
<li>
    <a href=""><i class="fa fa-navicon"></i><span class="fa arrow"></span>
        <span class="nav-label">Syarat & Ketentuan</span></a>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.sk') }}">List SK</a></li>
        </ul>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.formsk') }}">Tambah SK</a></li>
        </ul>
</li>
@endsection

@section('content')
<main class="main">
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>Rekening Bank</h2>
            <ol class="breadcrumb">
                <li>Home
                </li>
                <li class="active">
                    <strong>Rekening Bank</strong>
                </li>
            </ol>
        </div>
    </div>
    <div class="wrapper wrapper-content animated fadeInRight">
        
        <div class="col-md-8">
            <div class="ibox-content">
                <div class="card-header">
                    <h4 class="card-title">Daftar Rekening Bank</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Nama Pemilik</th>
                                    <th>Nama Bank</th>
                                    <th>No. Rekening</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- LOOPING DATA KATEGORI SESUAI JUMLAH DATA YANG ADA DI VARIABLE $CATEGORY -->
                                @forelse ($banks as $row)
                                <tr>
                                    <td></td>
                                    <td>{{ $row->nama_pemilik }}</td>

                                    <!-- MENGGUNAKAN TERNARY OPERATOR, UNTUK MENGECEK, JIKA $val->parent ADA MAKA TAMPILKAN NAMA PARENTNYA, SELAIN ITU MAKA TANMPILKAN STRING - -->
                                    {{-- <td>{{ $val->parent ? $val->parent->name:'-' }}</td> --}}

                                    <!-- FORMAT TANGGAL KETIKA KATEGORI DIINPUT SESUAI FORMAT INDONESIA -->
                                    <td>{{ $row->nama_bank }}</td>
                                    <td>{{ $row->no_rek }}</td>
                                    <td>

                                        <!-- FORM ACTION UNTUK METHOD DELETE -->
                                        <form action="{{ route('admin.destroybank', $row->id) }}" method="post">
                                            @csrf
                                            @method('DELETE')
                                            <a href="{{ route('admin.editbank', $row->id) }}"
                                                class="btn btn-warning">Edit</a>
                                            <button class="btn btn-danger">Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                                <!-- JIKA DATA CATEGORY KOSONG, MAKA AKAN DIRENDER KOLOM DIBAWAH INI  -->
                                @empty
                                <tr>
                                    <td colspan="5" class="text-center">Tidak ada data</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                    <!-- FUNGSI INI AKAN SECARA OTOMATIS MEN-GENERATE TOMBOL PAGINATION  -->
                    {!! $banks->links() !!}
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="ibox-content">
                <div class="card-header">
                    <h4 class="card-title">Tambah Rekening Bank</h4>
                </div>
                <div class="card-body">
                    <form method="POST" action="{{ route('admin.storebank') }}">
                        @csrf
                        <div class="form-group">
                            <label for="nama_pemilik">Nama Pemilik</label>
                            <input type="text" name="nama_pemilik" class="form-control" required>
                            <p class="text-danger">{{ $errors->first('nama_pemilik') }}</p>
                        </div>
                        <div class="form-group">
                            <label for="nama_bank">Nama Bank</label>
                            <input type="text" name="nama_bank" class="form-control" required>
                            <p class="text-danger">{{ $errors->first('nama_bank') }}</p>
                        </div>
                        <div class="form-group">
                            <label for="no_rek">No. Rekening</label>
                            <input type="text" name="no_rek" class="form-control" required>
                            <p class="text-danger">{{ $errors->first('no_rek') }}</p>
                        </div>
                        <div class="form-group text-right">
                            <button class="btn btn-primary btn-sm">Tambah</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</main>
@endsection
