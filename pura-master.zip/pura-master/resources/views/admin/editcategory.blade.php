@extends('layouts.admin')

@section('title')
<title>List Kategori</title>
@endsection

@section('menuside')
<li>
    <a href="{{ route('admin.index') }}"><i class="fa fa-th-large"></i>
        <span class="nav-label">Dashboard</span></a>
</li>
<li>
    <a href="#"><i class="fa fa-user"></i><span class="fa arrow"></span>
        <span class="nav-label">Kelola User</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('admin.user') }}">List Customer</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('admin.admin') }}">List Admin</a></li>
    </ul>
</li>
<li>
    <a href="#"><i class="fa fa-archive"></i><span class="fa arrow"></span>
        <span class="nav-label">Product</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('product.index') }}">List Produk</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('product.create') }}">Tambah Produk</a></li>
    </ul>
</li>
<li class="active">
    <a href="{{ route('category.index') }}"><i class="fa fa-industry"></i> <span
            class="nav-label">Category</span></a>
</li>
<li>
    <a href="{{ route('admin.order') }}"><i class="fa fa-cart-plus"></i> <span
            class="nav-label">Order</span></a>
</li>
<li>
    <a href="{{ route('admin.indexbank') }}"><i class="fa fa-credit-card"></i> <span
            class="nav-label">Rekening Bank</span></a>
</li>
<li>
    <a href="{{ route('admin.edit') }}"><i class="fa fa-address-card"></i>
        <span class="nav-label">Profile</span></a>
</li>
<li>
    <a href=""><i class="fa fa-navicon"></i><span class="fa arrow"></span>
        <span class="nav-label">Syarat & Ketentuan</span></a>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.sk') }}">List SK</a></li>
        </ul>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.formsk') }}">Tambah SK</a></li>
        </ul>
</li>
@endsection

@section('content')
<main class="main">
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>Kategori</h2>
            <ol class="breadcrumb">
                <li>Home
                </li>
                <li class="active">
                    <strong>Kategori</strong>
                </li>
            </ol>
        </div>
        <div class="col-lg-2">

        </div>
    </div>
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">

            <!-- BAGIAN INI AKAN MENG-HANDLE FORM INPUT NEW CATEGORY  -->
            
            <!-- BAGIAN INI AKAN MENG-HANDLE FORM INPUT NEW CATEGORY  -->

            <!-- BAGIAN INI AKAN MENG-HANDLE TABLE LIST CATEGORY  -->
            
            
            <div class="col-md-4">
                <div class="ibox-content">
                    <div class="card-header">
                        <h4 class="card-title">Edit Unit dan Kategori</h4>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('category.update', $kategori->id) }}" method="post">
                            @csrf
                            @method('PUT')
                            <div class="form-group">
                                <label for="status">Status</label>
                                <select name="status" class="form-control" required>
                                    <option value="1"
                                        {{ old('status') == '1' ? 'selected':'' }}>
                                        Publish</option>
                                    <option value="0"
                                        {{ old('status') == '0' ? 'selected':'' }}>
                                        Draft</option>
                                </select>
                                <p class="text-danger">{{ $errors->first('status') }}</p>
                            </div>
                            <div class="form-group">
                                <label for="name">Kategori</label>
                                <input type="text" name="name" class="form-control" value="{{ $kategori->name }}" required>
                                <p class="text-danger">{{ $errors->first('name') }}</p>
                            </div>
                            <div class="form-group">
                                <label for="user_id">Unit</label>
                                <select name="user_id" class="form-control">
                                    <option value="">None</option>
                                    @foreach ($unit as $row)
                                    <option value="{{ $row->id }}" {{ $kategori->user_id == $row->id ? 'selected':'' }}>{{ $row->name }}</option>
                                    @endforeach
                                </select>
                                <p class="text-danger">{{ $errors->first('unit_id') }}</p>
                            </div>
                            <div class="form-group">
                                <button class="btn btn-primary btn-sm">Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
        </div>


        <div class="row">


        </div>
    </div>
</main>
@endsection