@extends('layouts.admin')

@section('title')
<title>Product</title>
@endsection

@section('menuside')
<li>
    <a href="{{ route('unit.index') }}"><i class="fa fa-th-large"></i>
        <span class="nav-label">Dashboard</span></a>
</li>
<li>
    <a href="{{ route('categoryunit.index') }}"><i class="fa fa-industry"></i>
        <span class="nav-label">Category</span></a>
</li>
<li class="active">
    <a href="#"><i class="fa fa-archive"></i><span class="fa arrow"></span>
        <span class="nav-label">Product</span></a>
    <ul class="nav nav-second-level collapse">
        <li class="active"><a href="{{ route('productunit.index') }}">List Produk</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('productunit.create') }}">Tambah Produk</a></li>
    </ul>
</li>
<li>
    <a href="{{ route('unit.order') }}"><i class="fa fa-cart-plus"></i>
        <span class="nav-label">Order</span></a>
</li>
<li>
    <a href="{{ route('unit.edit') }}"><i class="fa fa-address-card"></i>
        <span class="nav-label">Profile</span></a>
</li>
@endsection

@section('content')
<div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>Produk</h2>
            <ol class="breadcrumb">
                <li>
                    <a href="index.html">Home</a>
                </li>
                <li class="active">
                    <strong>Produk</strong>
                </li>
            </ol>
        </div>
        
    </div>
    <div class="container-fluid">
        <div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-md-12">
                    <div class="ibox-content">


                        <!-- JIKA TERDAPAT FLASH SESSION, MAKA TAMPILAKAN -->
                        @if (session('success'))
                        <div class="alert alert-success">{{ session('success') }}</div>
                        @endif

                        @if (session('error'))
                        <div class="alert alert-danger">{{ session('error') }}</div>
                        @endif
                        <!-- JIKA TERDAPAT FLASH SESSION, MAKA TAMPILAKAN -->

                        <!-- BUAT FORM UNTUK PENCARIAN, METHODNYA ADALAH GET -->
                        <form action="{{ route('productunit.index') }}" method="get">
                            <div class="input-group">
                                <!-- KEMUDIAN NAME-NYA ADALAH Q YANG AKAN MENAMPUNG DATA PENCARIAN -->
                                <input type="text" class="form-control" placeholder="Cari..." value="{{ request()->q }}">
                                <span class="input-group-btn"> <button type="button" class="btn btn-default">Cari
                                </button></span>
                            </div>
                        </form>

                        <div class="card-body">
                            <!-- TABLE UNTUK MENAMPILKAN DATA PRODUK -->
                            <div class="table-responsive">
                                <table class="table table-hover table-bordered">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Produk</th>
                                            <th>Harga</th>
                                            <th>Created At</th>
                                            <th>Status</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse ($products as $row)
                                        <tr>
                                            <td>
                                                <img src="{{ asset('/storage/products/'.$row->image) }}" width="100px" height="100px" alt="{{ $row->image }}">
                                            </td>
                                            <td>
                                                <strong>{{ $row->name }}</strong><br>
                                                <!-- ADAPUN NAMA KATEGORINYA DIAMBIL DARI HASIL RELASI PRODUK DAN KATEGORI -->
                                                <label>Kategori: <span class="badge badge-info">{{ $row->category->name }}</span></label><br>
                                                <label>Berat: <span class="badge badge-info">{{ $row->weight }} gr</span></label>
                                            </td>
                                            <td>Rp {{ number_format($row->price) }}</td>
                                            <td>{{ $row->created_at->format('d-m-Y') }}</td>

                                            <!-- KARENA BERISI HTML MAKA KITA GUNAKAN { !! UNTUK MENCETAK DATA -->
                                            <td>{!! $row->status_label !!}</td>
                                            <td>
                                                <!-- FORM UNTUK MENGHAPUS DATA PRODUK -->
                                                <form action="{{ route('productunit.destroy', $row->id) }}" method="post">
                                                    @csrf
                                                    @method('DELETE')
                                                    <a href="{{ route('productunit.edit', $row->id) }}" class="btn btn-warning btn-sm">Edit</a>
                                                    <button class="btn btn-danger btn-sm">Hapus</button>
                                                </form>
                                            </td>
                                        </tr>
                                        @empty
                                        <tr>
                                            <td colspan="5" class="text-center">Tidak ada data</td>
                                        </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                            <!-- MEMBUAT LINK PAGINASI JIKA ADA -->
                            {!! $products->links() !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
