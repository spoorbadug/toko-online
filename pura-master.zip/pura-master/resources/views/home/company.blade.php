@extends('layouts.app')

@section('title')
<title>Tentang Pura</title>
@endsection

@section('content')
<!-- Main Container  -->
<div class="main-container container">
    <ul class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i></a></li>
        <li><a href="#">Tentang Pura</a></li>
    </ul>
    
    <div class="row">
        <div id="content" class="col-sm-12">
        
            <div class="about-us about-demo-2">
                <div class="row">
                    <div class="col-lg-12 col-md-12 about-us-center">
                        <div class="about-image-slider">
                            <img src="image/maxresdefault.jpg" alt="About Us"> 
                        </div>
                        <div class="content-description">
                            <h2 class="about-title">SELAMAT DATANG DI PURA GROUP</h2>
                            <p>PURA berawal dari sebuah percetakan letterpress kecil yang berdiri di tahun 1908. Kemudian di tahun 1970, di bawah kepemimpinan generasi ketiga&mdash;Jacobus Busono&mdash;perusahaan berkembang pesat sampai menjadi industri modern Pura Group yang kita kenal saat ini. Filosofi Pura adalah menghasilkan produk-produk inovatif berteknologi tinggi sebagai pengganti impor di pasar domestik dan produk ekspor untuk pasar internasional. Setelah lebih dari empat dekade, Pura telah menjelma menjadi kelompok industri dengan 30 divisi produksi yang terintegrasi menempati area 100 hektar lebih dengan 13.000 tenaga kerja, mengekspor produknya ke lebih dari 90 negara. </p>
                            <p>Pura adalah perusahaan swasta nasional yang mempunyai paten terbanyak di Indonesia. Pura telah mendaftarkan lebih dari 190 paten yang akan terus bertambah di masa mendatang.</p>
                            <p>Produk-produk Pura yang beragam telah lama hadir dalam berbagai aspek kehidupan baik dalam lingkup pribadi, perusahaan, dan industri.</p>
                        </div>
                    </div>
                </div>
                
            </div>
            
        </div>
    </div>
</div>
<!-- //Main Container -->
@endsection