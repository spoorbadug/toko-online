<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Order;
use App\Komplain;
use App\OrderDetail;
use App\KomplainStatus;
use App\Province;
use App\City;

class KomplainController extends Controller
{
    public function returnorder($invoice)
    {
            $order=Order::with(['details'])->where('invoice', $invoice)->first();
            if($order->status_id == 7){
                $listproduct=OrderDetail::where('order_id', $order->id)->get();
                $listkomplain=KomplainStatus::orderBy('id', 'ASC')->get();
                    //JIKA SUDAH MAKA REDIRECT KE LIST PRODUK
                return view('orders.komplain', compact('order', 'listproduct', 'listkomplain'));
            }
            
            alert()->error('Upsss...','Silahkan konfirmasi pesanan diterima terlebih dahulu');
            return redirect(route('order.detail', $invoice));
    }

    public function store(Request $request, $id)
    {

        //dd($request->all());
        $this->validate(request(),[
            'jumlah'=> 'required|integer',
            'order_id'=>'required|exists:orders,id'
        ]);

        
            $order = Order::where('id', $id)->first();
            if($order) {
                $order->update([ 'status_id' => 10 ]);
            }
       
            if ($request->hasFile('image')) {
                //MAKA KITA SIMPAN SEMENTARA FILE TERSEBUT KEDALAM VARIABLE FILE
                $file = $request->file('image');
                //KEMUDIAN NAMA FILENYA KITA BUAT CUSTOMER DENGAN PERPADUAN TIME DAN SLUG DARI NAMA PRODUK. ADAPUN EXTENSIONNYA KITA GUNAKAN BAWAAN FILE TERSEBUT
                $filename = time() . Str::slug($request->nama_produk) . '.' . $file->getClientOriginalExtension();
                //SIMPAN FILENYA KEDALAM FOLDER PUBLIC/PRODUCTS, DAN PARAMETER KEDUA ADALAH NAMA CUSTOM UNTUK FILE TERSEBUT
                $file->storeAs('public/komplain', $filename);
        
                //SETELAH FILE TERSEBUT DISIMPAN, KITA SIMPAN INFORMASI PRODUKNYA KEDALAM DATABASE
                Komplain::create([
                    'order_id' => $request->order_id,
                    'user_id' => $request->user_id,
                    'product_id' => $request->product_id,
                    'jumlah' => $request->jumlah,
                    'komplainstatus_id' => $request->komplainstatus_id,
                    'image' => $filename,
                    'catatan' => $request->catatan
                ]);
                
                alert()->success('Berhasil','Berhasil komplain produk');
                //JIKA SUDAH MAKA REDIRECT KE LIST PRODUK
                return redirect(route('order.index'));
            }
        

        
    }

    public function listkomplain()
    {
        $komplains = Komplain::where('user_id', auth()->guard('web')->user()->id)->orderBy('created_at', 'DESC');

        // if (request()->q != '') {
        //     $orders = $orders->where(function($q) {
        //         $q->Where('invoice', 'LIKE', '%' . request()->q . '%');
        //     });
        // }

        $komplains = $komplains->paginate(10);
        return view('orders.listkomplain', compact('komplains'));
    }

    public function show_komplain($id)
    {
        $komplain = Komplain::with(['order', 'product'])->where('id', $id)->first();
       //$order = Order::where('id', $komplain->order_id)->first();
        //dd($komplain->status);
        return view('orders.showkomplain', compact('komplain', 'order'));
    }

    public function destroy_komplain($id)
    {
        $komplain = Komplain::find($id);
        $komplain->delete();
        
        Alert::success('Berhasil', 'Berhasil Menghapus Komplain');
        return redirect(route('komplain.index'));
    }

    public function proses_komplain_admin($id)
    {
        $provinces = Province::orderBy('name', 'ASC')->get();
        $cities = City::orderBy('name', 'ASC')->get();
        $komplain = Komplain::with(['order', 'product'])->where('id', $id)->first();
       //$order = Order::where('id', $komplain->order_id)->first();
        //dd($komplain->status);
        return view('admin.proseskomplain', compact('komplain', 'provinces', 'cities'));
    }

    public function komplain_admin()
    {
        $komplains = Komplain::orderBy('created_at', 'DESC');

        // if (request()->q != '') {
        //     $orders = $orders->where(function($q) {
        //         $q->Where('invoice', 'LIKE', '%' . request()->q . '%');
        //     });
        // }

        $komplains = $komplains->paginate(10);
        return view('admin.komplain', compact('komplains'));
    }

    public function show_komplain_admin($id)
    {
        $komplain = Komplain::with(['order', 'product'])->where('id', $id)->first();
       //$order = Order::where('id', $komplain->order_id)->first();
        //dd($komplain->status);
        return view('admin.showkomplain', compact('komplain', 'order'));
    }
}
