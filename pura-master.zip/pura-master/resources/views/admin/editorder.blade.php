@extends('layouts.admin')

@section('title')
<title>Order</title>
@endsection

@section('menuside')
<li>
    <a href="{{ route('admin.index') }}"><i class="fa fa-th-large"></i>
        <span class="nav-label">Dashboard</span></a>
</li>
<li>
    <a href="#"><i class="fa fa-user"></i><span class="fa arorder"></span>
        <span class="nav-label">Kelola User</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('admin.user') }}">List Customer</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('admin.admin') }}">List Admin</a></li>
    </ul>
</li>
<li>
    <a href="#"><i class="fa fa-archive"></i><span class="fa arorder"></span>
        <span class="nav-label">Product</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('product.index') }}">List Produk</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('product.create') }}">Tambah Produk</a></li>
    </ul>
</li>
<li>
    <a href="{{ route('category.index') }}"><i class="fa fa-industry"></i> <span
            class="nav-label">Category</span></a>
</li>
<li class="active">
    <a href="{{ route('admin.order') }}"><i class="fa fa-cart-plus"></i> <span
            class="nav-label">Order</span></a>
</li>
<li>
    <a href="{{ route('admin.indexbank') }}"><i class="fa fa-credit-card"></i> <span
            class="nav-label">Rekening Bank</span></a>
</li>
<li>
    <a href="{{ route('admin.edit') }}"><i class="fa fa-address-card"></i>
        <span class="nav-label">Profile</span></a>
</li>
<li>
    <a href=""><i class="fa fa-navicon"></i><span class="fa arrow"></span>
        <span class="nav-label">Syarat & Ketentuan</span></a>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.sk') }}">List SK</a></li>
        </ul>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.formsk') }}">Tambah SK</a></li>
        </ul>
</li>
@endsection

@section('content')
<main class="main">
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>Daftar Pesanan</h2>
            <ol class="breadcrumb">
                <li>
                    Home
                </li>
                <li>
                    Order
                </li>
                <li class="active">
                    <strong>Edit Pesanan</strong>
                </li>
            </ol>
        </div>
        <div class="col-lg-2"></div>
    </div>

    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <form action="{{ route('admin.updateorder', $order->id) }}" method="post" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <div class="col-md-8">
                    <div class="ibox-content">
                        <div class="card-header">
                            <h4 class="card-title">Kelola Pesanan</h4>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="" class="control-label">InvoiceID</label>
                                <input type="text" class="form-control" name="invoice" value="{{ $order->invoice }}"
                                    disabled="">
                            </div>
                            <div class="form-group">
                                <label for="" class="control-label">Pelanggan</label>
                                <input type="text" class="form-control" name="name"
                                    value="{{ $order->profile->name }}" disabled="">
                            </div>
                            <div class="form-group">
                                <label for="" class="control-label">Total</label>
                                <input type="text" class="form-control" name="total"
                                    value="Rp {{ number_format($order->total) }}" disabled="">
                            </div>
                            <div class="form-group">
                                <label for="status">Status</label>
                                <select name="status" class="form-control">
                                    @foreach($status as $item)
                                        <option value="{{ $item->id }}"
                                            {{ $order->status_id == $item->id ? 'selected':'' }}>
                                            {{ $item->name }} </option>
                                    @endforeach
                                </select>
                                <p class="text-danger">{{ $errors->first('status') }}</p>
                            </div>
                            <div class="form-group text-right">
                                <button class="btn btn-primary" id="button-confirm"
                                    value="Confirm Order">Konfirmasi</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <div class="col-md-4">
                <div class="ibox-content">
                    <div class="card-header">
                        <h4 class="card-title">Bukti Pembayaran</h4>
                    </div>
                    <div class="card-body">
                        <br>
                        <img src="{{ asset('/storage/payments/' .$order->payment['bukti_bayar']) }}"
                            width="250px" height="250px"
                            alt="{{ $order->payment->nama ?? '' }}">
                    </div>
                </div>
            </div>
        </div>


    </div>
</main>

@endsection
