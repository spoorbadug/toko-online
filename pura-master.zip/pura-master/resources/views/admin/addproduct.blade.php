@extends('layouts.admin')

@section('title')
<title>Tambah Produk</title>

<link href="{{ asset('css/plugins/summernote/summernote.css') }}" rel="stylesheet">
<link href="{{ asset('css/plugins/summernote/summernote-bs3.css') }}" rel="stylesheet">
@endsection

@section('menuside')
<li>
    <a href="{{ route('admin.index') }}"><i class="fa fa-th-large"></i>
        <span class="nav-label">Dashboard</span></a>
</li>
<li>
    <a href="#"><i class="fa fa-user"></i><span class="fa arrow"></span>
        <span class="nav-label">Kelola User</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('admin.user') }}">Customer</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('admin.admin') }}">Admin</a></li>
    </ul>
</li>
<li class="active">
    <a href="#"><i class="fa fa-archive"></i><span class="fa arrow"></span>
        <span class="nav-label">Product</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('product.index') }}">List Produk</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li class="active"><a href="{{ route('product.create') }}">Tambah Produk</a></li>
    </ul>
</li>
<li>
    <a href="{{ route('category.index') }}"><i class="fa fa-industry"></i> <span
            class="nav-label">Category</span></a>
</li>
<li>
    <a href="{{ route('admin.order') }}"><i class="fa fa-cart-plus"></i> <span
            class="nav-label">Order</span></a>
</li>
<li>
    <a href="{{ route('admin.indexbank') }}"><i class="fa fa-credit-card"></i> <span
            class="nav-label">Rekening Bank</span></a>
</li>
<li>
    <a href="{{ route('admin.edit') }}"><i class="fa fa-address-card"></i>
        <span class="nav-label">Profile</span></a>
</li>
<li>
    <a href=""><i class="fa fa-navicon"></i><span class="fa arrow"></span>
        <span class="nav-label">Syarat & Ketentuan</span></a>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.sk') }}">List SK</a></li>
        </ul>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.formsk') }}">Tambah SK</a></li>
        </ul>
</li>
@endsection


@section('content')
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Tambah Produk</h2>
        <ol class="breadcrumb">
            <li>Home
            </li>
            <li>Produk
            </li>
            <li class="active">
                <strong>Tambah Produk</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">

    <!-- TAMBAHKAN ENCTYPE="" KETIKA MENGIRIMKAN FILE PADA FORM -->
    <form action="{{ route('product.store') }}" method="post" enctype="multipart/form-data">

        @csrf
        <div class="row">
            <div class="col-md-8">
                <div class="ibox-content">
                    <div class="card-body">
                        <div class="form-group">
                            <label for="name">Nama Produk</label>
                            <input type="text" name="name" class="form-control"
                                value="{{ old('name') }}" required>
                        </div>
                        <div class="form-group">
                            <label for="description">Deskripsi</label>

                            <!-- TAMBAHKAN ID YANG NNTINYA DIGUNAKAN UTK MENGHUBUNGKAN DENGAN CKEDITOR -->
                            <textarea name="description" id="description"
                                class="form-control">{{ old('description') }}</textarea>
                            <p class="text-danger">{{ $errors->first('description') }}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="ibox-content">
                    <div class="card-body">
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select name="status" class="form-control" required>
                                <option value="1"
                                    {{ old('status') == '1' ? 'selected':'' }}>
                                    Publish</option>
                                <option value="0"
                                    {{ old('status') == '0' ? 'selected':'' }}>
                                    Draft</option>
                            </select>
                            <p class="text-danger">{{ $errors->first('status') }}</p>
                        </div>
                        <div class="form-group">
                            <label for="category_id">Kategori</label>

                            <!-- DATA KATEGORI DIGUNAKAN DISINI, SEHINGGA SETIAP PRODUK USER BISA MEMILIH KATEGORINYA -->
                            <select name="category_id" class="form-control">
                                <option value="">Pilih</option>
                                @foreach($category as $row)
                                    <option value="{{ $row->id }}"
                                        {{ old('category_id') == $row->id ? 'selected':'' }}>
                                        {{ $row->name }}</option>
                                @endforeach
                            </select>
                            <p class="text-danger">{{ $errors->first('category_id') }}</p>
                        </div>
                        <div class="form-group">
                            <label for="price">Harga</label>
                            <input type="number" name="price" class="form-control"
                                value="{{ old('price') }}" required>
                            <p class="text-danger">{{ $errors->first('price') }}</p>
                        </div>
                        <div class="form-group">
                            <label for="weight">Berat (Gram)</label>
                            <input type="number" name="weight" class="form-control"
                                value="{{ old('weight') }}" required>
                            <p class="text-danger">{{ $errors->first('weight') }}</p>
                        </div>
                        <div class="form-group">
                            <label for="stock">Stok</label>
                            <input type="number" name="stock" class="form-control"
                                value="{{ old('stock') }}" required>
                            <p class="text-danger">{{ $errors->first('stock') }}</p>
                        </div>
                        <div class="form-group">
                            <label for="min">Min. Order</label>
                            <input type="number" name="min" class="form-control"
                                value="{{ old('min') }}" required>
                            <p class="text-danger">{{ $errors->first('min') }}</p>
                        </div>
                        <div class="form-group">
                            <label for="image">Foto Produk</label>
                            <input type="file" name="image" class="form-control" value="{{ old('image') }}">
                            <p class="text-danger">{{ $errors->first('image') }}</p>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary btn-sm">Tambah</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
@endsection

@section('js')
<!-- SUMMERNOTE -->

<script src="{{ asset('js/jquery.min.js') }}"></script>
<script src="{{ asset('js/bootstrap.min.js') }}"></script>
<script src="{{ asset('js/plugins/summernote/summernote.min.js') }}"></script>

<!-- 
<script>
    $('#description').summernote({
        height: 125,   //set editable area's height
        codemirror: { // codemirror options
            theme: 'monokai'
        }
    });
</script>
-->
<script type="text/javascript">
    $(document).ready(function () {
        $('#description').summernote({
            height: "150px",
            styleWithSpan: false
        });
    });
</script>

@endsection
