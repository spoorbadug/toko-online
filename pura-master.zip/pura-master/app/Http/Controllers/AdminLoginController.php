<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Auth;


class AdminLoginController extends Controller
{
    use AuthenticatesUsers;

    public function loginForm()
    {
        return view('login');
    }

    public function login(Request $request)
    {

        if(Auth::attempt(['email' => $request->email, 'password' => $request->password, 'role' => 'Admin' ])){
            toast('Sukses Masuk','success');
            return redirect(route('admin.index'));
        } elseif (Auth::attempt(['email' => $request->email, 'password' => $request->password, 'role' => 'Unit' ])){
            toast('Sukses Masuk','success');
            return redirect(route('unit.index'));
        } elseif (Auth::attempt(['email' => $request->email, 'password' => $request->password, 'role' => 'Keuangan' ])){
            toast('Sukses Masuk','success');
            return redirect(route('keuangan.index'));
        } else {
            return redirect()->back()->with(['error' => 'Email atau Password anda salah']);
        }
        
    }

    public function logout(Request $request) {
        Auth::logout();
        return redirect('/xdmin');
    }
}
