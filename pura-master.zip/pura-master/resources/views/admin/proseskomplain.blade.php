@extends('layouts.admin')

@section('title')
<title>Tambah Produk</title>

<link href="{{ asset('css/plugins/summernote/summernote.css') }}" rel="stylesheet">
<link href="{{ asset('css/plugins/summernote/summernote-bs3.css') }}" rel="stylesheet">
@endsection

@section('menuside')
<li>
    <a href="{{ route('admin.index') }}"><i class="fa fa-th-large"></i>
        <span class="nav-label">Dashboard</span></a>
</li>
<li>
    <a href="#"><i class="fa fa-user"></i><span class="fa arrow"></span>
        <span class="nav-label">Kelola User</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('admin.user') }}">Customer</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('admin.admin') }}">Admin</a></li>
    </ul>
</li>
<li>
    <a href="#"><i class="fa fa-archive"></i><span class="fa arrow"></span>
        <span class="nav-label">Product</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('product.index') }}">List Produk</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('product.create') }}">Tambah Produk</a></li>
    </ul>
</li>
<li>
    <a href="{{ route('category.index') }}"><i class="fa fa-industry"></i> <span
            class="nav-label">Category</span></a>
</li>
<li class="active">
    <a href=""><i class="fa fa-cart-plus"></i><span class="fa arrow"></span>
        <span class="nav-label">Order</span></a>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.order') }}">List Order</a></li>
        </ul>
        <ul class="nav nav-second-level collapse">
            <li class="active"><a href="{{ route('admin.komplain') }}">Komplain</a></li>
        </ul>
</li>
<li>
    <a href="{{ route('admin.indexbank') }}"><i class="fa fa-credit-card"></i> <span
            class="nav-label">Rekening Bank</span></a>
</li>
<li>
    <a href="{{ route('admin.edit') }}"><i class="fa fa-address-card"></i>
        <span class="nav-label">Profile</span></a>
</li>
<li>
    <a href=""><i class="fa fa-navicon"></i><span class="fa arrow"></span>
        <span class="nav-label">Syarat & Ketentuan</span></a>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.sk') }}">List SK</a></li>
        </ul>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.formsk') }}">Tambah SK</a></li>
        </ul>
</li>
<li>
    <a href=""><i class="fa fa-question-circle"></i><span class="fa arrow"></span>
        <span class="nav-label">FAQ</span></a>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.listfaq') }}">List Faq</a></li>
        </ul>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.formfaq') }}">Tambah Faq</a></li>
        </ul>
</li>
@endsection


@section('content')
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Tambah Produk</h2>
        <ol class="breadcrumb">
            <li>Home
            </li>
            <li>Produk
            </li>
            <li class="active">
                <strong>Tambah Produk</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">

    <!-- TAMBAHKAN ENCTYPE="" KETIKA MENGIRIMKAN FILE PADA FORM -->
    <form action="{{ route('product.store') }}" method="post" enctype="multipart/form-data">

        @csrf
        <div class="row">
            
            <div class="col-md-12">
                <div class="ibox-content">
                    <div class="card-body">
                        <div class="form-group">
                            <label for="category_id">Invoice</label>
                            <input type="text" name="price" class="form-control"
                            value="{{ $komplain->order->invoice }}" disabled>
                        </div>
                        <div class="form-group">
                            <label for="category_id">Produk</label>
                            <input type="text" name="price" class="form-control"
                            value="{{ $komplain->product->name}}" disabled>
                        </div>
                        <div class="form-group">
                            <label for="price">Jumlah</label>
                            <input type="number" name="price" class="form-control"
                                value="{{ $komplain->jumlah }}" disabled>
                        </div>
                        <div class="form-group">
                            <label for="weight">Nama penerima</label>
                            <input type="text" name="weight" class="form-control"
                                value="{{ $komplain->order->profile->name }}" disabled>
                        </div>
                        <div class="form-group">
                            <label for="province" class="control-label">Provinsi</label>
                            <select class="form-control provinsi-tujuan" id="province" name="province">
                                <option value="">{{ $komplain->order->profile->province->province_id }}</option>
                                {{-- @foreach ($provinces as $row)
                                <option value="{{ $row->id }}" {{ $user->province == $row->id ? 'selected':'' }}>{{ $row->name }}</option>
                                @endforeach --}}
                                @foreach ($provinces as $province => $value)
                                <option value="{{ $province  }}" {{ $komplain->order->profile->province->province_id == $province ? 'selected':'' }}>{{ $value->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="image">Foto Produk</label>
                            <input type="file" name="image" class="form-control" value="{{ old('image') }}">
                            <p class="text-danger">{{ $errors->first('image') }}</p>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary btn-sm">Tambah</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
@endsection

@section('js')
<!-- SUMMERNOTE -->

<script src="{{ asset('js/jquery.min.js') }}"></script>
<script src="{{ asset('js/bootstrap.min.js') }}"></script>
<script src="{{ asset('js/plugins/summernote/summernote.min.js') }}"></script>

<!-- 
<script>
    $('#description').summernote({
        height: 125,   //set editable area's height
        codemirror: { // codemirror options
            theme: 'monokai'
        }
    });
</script>
-->
<script type="text/javascript">
    $(document).ready(function () {
        $('#description').summernote({
            height: "150px",
            styleWithSpan: false
        });
    });
</script>

@endsection
