@extends('layouts.admin')

@section('title')
<title>Komplain</title>
@endsection

@section('menuside')
<li>
    <a href="{{ route('admin.index') }}"><i class="fa fa-th-large"></i>
        <span class="nav-label">Dashboard</span></a>
</li>
<li>
    <a href="#"><i class="fa fa-user"></i><span class="fa arrow"></span>
        <span class="nav-label">Kelola User</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('admin.user') }}">Customer</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('admin.admin') }}">Admin</a></li>
    </ul>
</li>
<li>
    <a href="#"><i class="fa fa-archive"></i><span class="fa arrow"></span>
        <span class="nav-label">Product</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('product.index') }}">List Produk</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('product.create') }}">Tambah Produk</a></li>
    </ul>
</li>
<li>
    <a href="{{ route('category.index') }}"><i class="fa fa-industry"></i> <span
            class="nav-label">Category</span></a>
</li>
<li class="active">
    <a href=""><i class="fa fa-cart-plus"></i><span class="fa arrow"></span>
        <span class="nav-label">Order</span></a>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.order') }}">List Order</a></li>
        </ul>
        <ul class="nav nav-second-level collapse">
            <li class="active"><a href="{{ route('admin.komplain') }}">Komplain</a></li>
        </ul>
</li>
<li>
    <a href="{{ route('admin.indexbank') }}"><i class="fa fa-credit-card"></i> <span
            class="nav-label">Rekening Bank</span></a>
</li>
<li>
    <a href="{{ route('admin.edit') }}"><i class="fa fa-address-card"></i>
        <span class="nav-label">Profile</span></a>
</li>
<li>
    <a href=""><i class="fa fa-navicon"></i><span class="fa arrow"></span>
        <span class="nav-label">Syarat & Ketentuan</span></a>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.sk') }}">List SK</a></li>
        </ul>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.formsk') }}">Tambah SK</a></li>
        </ul>
</li>
<li>
    <a href=""><i class="fa fa-question-circle"></i><span class="fa arrow"></span>
        <span class="nav-label">FAQ</span></a>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.listfaq') }}">List Faq</a></li>
        </ul>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.formfaq') }}">Tambah Faq</a></li>
        </ul>
</li>
@endsection

@section('content')
<main class="main">
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>Daftar Komplain</h2>
            <ol class="breadcrumb">
                <li>Home
                </li>
                <li class="active">
                    <strong>Order</strong>
                </li>
            </ol>
        </div>
        <div class="col-lg-2"></div>
    </div>
    <div class="container-fluid">
        <div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox">
                        <div class="ibox-content">
                            <h4 class="title">Informasi Komplain</h4>
                            <table class="table table-hover table-bordered">
                                <thead>
                                    <tr>
                                        <td colspan="2" class="text-left"><b>Detail Pesanan</b></td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td style="width: 50%;" class="text-left"> <b>ID Pesanan :</b> {{ $komplain->order->invoice }}
                                            <br>
                                            <b>Tanggal Pesanan :</b> {{ $komplain->created_at->format('d-m-Y') }}
                                    </tr>
                                </tbody>
                            </table>
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        
                                        <td style="vertical-align: top;" class="text-left"><b>Alamat</b></td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <?php
                                            $cities = \App\City::where('city_id', $komplain->order->profile->city_id)->first();
                                            $provinces = \App\Province::where('province_id', $komplain->order->profile->province_id)->first();
                                        ?>
                                        <td class="text-left">{{ $komplain->order->profile->name }}
                                            <br>{{ $komplain->order->profile->address }}, {{ $cities->name }}, {{ $provinces->name }}
                                            <br>Indonesia
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <td colspan="5" class="text-left"><b>Detail Barang</b></td>
                                    </tr>
                                </thead>
                                <tbody>
                                    {{-- @forelse ($komplain as $row) --}}
                                    <tr>
                                        <td>{{ $komplain->product->name }}</td>
                                        <td>{{ $komplain->jumlah }} Item</td>
                                        <td>{{ $komplain->status->name }}</td>
                                        <td class="text-center"><img src="{{ asset('storage/komplain/'.$komplain->image) }}" width="200px" height="200px" alt="{{ $komplain->image }}"></td>
                                        
                                    </tr>
                                    {{-- @empty
                                    <tr>
                                        <td colspan="5" class="text-center">Tidak ada data</td>
                                    </tr>
                                    @endforelse --}}
                                </tbody>
                            </table>
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <td colspan="5" class="text-left"><b>Catatan Komplain</b></td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>{{ $komplain->catatan }}</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="text-right">
                                <a href="{{ route('admin.proseskomplain', $komplain->id) }}" class="btn btn-primary">Proses Komplain</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

@endsection
