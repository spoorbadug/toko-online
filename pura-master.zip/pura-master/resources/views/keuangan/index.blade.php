@extends('layouts.admin')

@section('title')
<title>Dashboard Keuangan</title>
@endsection

@section('menuside')
<li class="active">
    <a href="{{ route('keuangan.index') }}"><i class="fa fa-th-large"></i>
        <span class="nav-label">Dashboard</span></a>
</li>
<li>
    <a href="{{ route('keuangan.order') }}"><i class="fa fa-cart-plus"></i> <span
            class="nav-label">Order</span></a>
</li>
<li>
    <a href="{{ route('pay.bank') }}"><i class="fa fa-university"></i> <span
            class="nav-label">Rekening Bank</span></a>
</li>
<li>
    <a href="{{ route('keuangan.edit') }}"><i class="fa fa-address-card"></i>
        <span class="nav-label">Profile</span></a>
</li>
@endsection

@section('content')
<main class="main">
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>Dashboard Keuangan</h2>
            <ol class="breadcrumb">
                <li>
                    <a href="index.html">Home</a>
                </li>
                <li class="active">
                    <strong>Dashboard</strong>
                </li>
            </ol>
        </div>
        <div class="col-lg-2">

        </div>
    </div>
    <div class="wrapper wrapper-content">
        <div class="row">
            <div class="col-lg-3">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Akun Customer</h5>
                    </div>
                    <div class="ibox-content">
                        <h1 class="no-margins">{{ $totalCustomer }}</h1>
                        <small>Terdaftar</small>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Akun Admin</h5>
                    </div>
                    <div class="ibox-content">
                        <h1 class="no-margins">{{ $totalAdmin }}</h1>
                        <small>Terdaftar</small>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Orders</h5>
                    </div>
                    <div class="ibox-content">
                        <h1 class="no-margins">{{ $totalorder }}</h1>
                        <small>Pesanan Baru</small>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Total Penjualan</h5>
                    </div>
                    <div class="ibox-content">
                        <h1 class="no-margins">Rp {{ number_format($totalgross) }}</h1>
                        <small>Total</small>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="ibox">
                    <div class="ibox-content">
                        <table class="footable table table-stripped toggle-arrow-tiny" data-page-size="15">
                            <thead>
                                <tr>
                                    <th>InvoiceID</th>
                                    <th>Pelanggan</th>
                                    <th>Tanggal</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($orders as $row)
                                    <tr>
                                        <td>{{ $row->invoice }}</td>
                                        <td>{{ $row->profile->name }}</td>
                                        <td>{{ $row->created_at->format('d-m-Y') }}</td>
                                        <td>{!! $row->status->name !!}</td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="6" class="text-center">Tidak ada data</td>
                                    </tr>
                                @endforelse

                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="7">
                                        <ul class="pagination pull-right"></ul>
                                        {!! $orders->links() !!}
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                        {{-- {!! $pesanan->links() !!} --}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection