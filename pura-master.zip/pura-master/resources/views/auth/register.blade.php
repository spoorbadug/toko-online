<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Pura Store | Register</title>

    <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('font-awesome/css/font-awesome.css') }}" rel="stylesheet">
    <link href="{{ asset('css/plugins/iCheck/custom.css') }}" rel="stylesheet">
    <link href="{{ asset('css/animate.css') }}" rel="stylesheet">
    <link href="{{ asset('css/style.css') }}" rel="stylesheet">

</head>

<body class="gray-bg">

    <div class="text-center loginscreen animated fadeInDown">
        <div>
            <div>
                <img src="{{ asset('image\pura\logo.png') }}">

            </div>
            <br>
            <br>

            <div class="ibox-content middle-box" style="width: 350px">
                <form method="POST" action="{{ route('register') }}" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="role" value="Customer">
                    <h2 class="title"><b>Daftar Akun</b></h2>
                    @if(session('success'))
                        <!-- MAKA TAMPILKAN ALERT SUCCESS -->
                        <div class="alert alert-success">{{ session('success') }}</div>
                    @endif

                    <!-- KETIKA ADA SESSION ERROR  -->
                    @if(session('error'))
                        <!-- MAKA TAMPILKAN ALERT DANGER -->
                        <div class="alert alert-danger">{{ session('error') }}</div>
                    @endif
                    <div class="form-group">
                        <input id="name" type="text" class="form-control @error('name') is-invalid @enderror"
                            name="name" value="{{ old('name') }}" required autocomplete="name"
                            placeholder="Nama Lengkap">
                        @error('name')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    <div class="form-group">
                        <input id="email" type="email" class="form-control @error('email') is-invalid @enderror"
                            name="email" value="{{ old('email') }}" required autocomplete="email"
                            placeholder="Email">

                        @error('email')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    <div class="form-group">
                        <input id="password" type="password"
                            class="form-control @error('password') is-invalid @enderror" name="password" required
                            autocomplete="new-password" placeholder="Password">

                        @error('password')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    <div class="form-group">
                        <input id="password-confirm" type="password" class="form-control" name="password_confirmation"
                            required autocomplete="new-password" placeholder="Konfirmasi Password">
                    </div>
                    <div class="form-group {{ $errors->has('g-recaptcha-response') ? ' has-error' : '' }}">
                        <label class="control-label">Captcha</label>
                        <div class="pull-center">
                            {!! app('captcha')->display() !!}

                            @if($errors->has('g-recaptcha-response'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('g-recaptcha-response') }}</strong>
                                </span>
                            @endif
                        </div>
                    </div>
                    <br>
                    <button type="submit" id="tombol" class="btn btn-primary block full-width m-b">Register</button>


                </form>
                <p class="text-muted text-center"><small>Sudah punya akun?</small></p>
                <a class="btn btn-sm btn-white btn-block" href="{{ route('login') }}">Login</a>
            </div>

            <p class="m-t"> <small><strong>Copyright</strong> Pura Group &copy; 2020</small> </p>
        </div>
    </div>

    <!-- Mainly scripts -->
    <script src="{{ asset('js/jquery-3.1.1.min.js') }}"></script>
    <script src="{{ asset('js/bootstrap.min.js') }}"></script>
    <!-- iCheck -->
    <script src="{{ asset('js/plugins/iCheck/icheck.min.js') }}"></script>
    <script>
        // $(document).ready(function () {
        //     $('#tombol').click(function(){

        //         var name = $(".name").val();
        //             var email = $(".email").val();
        //             var password = $(".password").val();
        //             var role = $(".role").val();

        //             alert(name);
        //         if($('#checkbox').is(':checked')){


        //             //alert(name);
        //         }
        //     });
        // });

    </script>
    <script src='https://www.google.com/recaptcha/api.js'></script>
</body>

</html>
