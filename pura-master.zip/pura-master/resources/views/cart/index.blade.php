@extends('layouts.app')

@section('title')
<title>Keranjang Belanja</title>
@endsection

@section('content')
<body class="res layout-1">
    <div id="wrapper" class="wrapper-fluid banners-effect-5">
        <!-- Main Container  -->
        <div class="main-container container">
            <ul class="breadcrumb">
                <li><a href="#"><i class="fa fa-home"></i></a></li>
                <li><a href="#">Keranjang Belanja</a></li>
            </ul>
            {{-- @if(Session::has('cart') && $totalQuantity >0) --}}
            <div class="row">
                <!--Middle Part Start-->
                <div id="content" class="col-sm-12">
                    <h2 class="title">Keranjang Belanja</h2>
                    @if(session('error'))
                        <div class="alert alert-danger">{{ session('error') }}</div>
                    @endif
                    <form action="{{ route('front.update_cart') }}" method="post">
                        @csrf
                        <div class="table-responsive form-group">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <td class="text-center">Gambar</td>
                                        <td class="text-left">Nama Produk</td>
                                        <td class="text-left">Jumlah</td>
                                        <td class="text-right">Harga Barang</td>
                                        <td class="text-right">Sub-Total</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($carts as $row)
                                        <tr>
                                            <td class="text-center">
                                                    <img width="70px"
                                                        src="{{ asset('/storage/products/' . $row['product_image']) }}"
                                                        alt="{{ $row['product_name'] }}"
                                                        title="{{ $row['product_name'] }}"
                                                        class="img-thumbnail" /></td>
                                            <td class="text-left">{{ $row['product_name'] }}<br />
                                            </td>
                                            <td class="text-left" width="200px">
                                                <div class="input-group btn-block quantity">
                                                    <input type="text" name="qty[]"
                                                        id="sst{{ $row['product_id'] }}"
                                                        maxlength="12" value="{{ $row['qty'] }}"
                                                        title="Quantity:" class="form-control qty">
                                                    <input type="hidden" name="product_id[]"
                                                        value="{{ $row['product_id'] }}"
                                                        class="form-control">
                                                    <span class="input-group-btn">
                                                        <button type="submit" data-toggle="tooltip" title="Update"
                                                            class="btn btn-primary"><i class="fa fa-clone"></i></button>
                                                    </span>
                                                </div>
                                            </td>
                                            <td class="text-right">Rp
                                                {{ number_format($row['product_price']) }}</td>
                                            <td class="text-right">Rp
                                                {{ number_format($row['product_price'] * $row['qty']) }}
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="5">Tidak ada belanjaan</td>
                                        </tr>
                                    @endforelse
                                    <tr>
                                        <td class="text-right" colspan="4">
                                            <strong>Total:</strong>
                                        </td>
                                        <td class="text-right">Rp {{ number_format($subtotal) }}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </form>
                    <div class="buttons">
                        <div class="pull-left"><a href="{{ route('product.list') }}"
                                class="btn btn-primary">Kembali Belanja</a></div>
                        <div class="pull-right"><a href="{{ route('checkout.index') }}"
                                class="btn btn-primary">Checkout</a></div>
                    </div>
                </div>
                <!--Middle Part End -->
            </div>
        </div>
        <!-- //Main Container -->
</body>
</html>
@endsection
