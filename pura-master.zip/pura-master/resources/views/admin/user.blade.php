@extends('layouts.admin')

@section('title')
<title>Kelola User</title>
@endsection

@section('menuside')
<li>
    <a href="{{ route('admin.index') }}"><i class="fa fa-th-large"></i>
        <span class="nav-label">Dashboard</span></a>
</li>
<li class="active">
    <a href="#"><i class="fa fa-user"></i><span class="fa arrow"></span>
        <span class="nav-label">Kelola User</span></a>
    <ul class="nav nav-second-level collapse">
        <li class="active"><a href="{{ route('admin.user') }}">Customer</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('admin.admin') }}">Admin</a></li>
    </ul>
</li>
<li>
    <a href="#"><i class="fa fa-archive"></i><span class="fa arrow"></span>
        <span class="nav-label">Product</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('product.index') }}">List Produk</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('product.create') }}">Tambah Produk</a></li>
    </ul>
</li>
<li>
    <a href="{{ route('category.index') }}"><i class="fa fa-industry"></i> <span
            class="nav-label">Category</span></a>
</li>
<li>
    <a href="{{ route('admin.order') }}"><i class="fa fa-cart-plus"></i> <span
            class="nav-label">Order</span></a>
</li>
<li>
    <a href="{{ route('admin.indexbank') }}"><i class="fa fa-credit-card"></i> <span
            class="nav-label">Rekening Bank</span></a>
</li>
<li>
    <a href="{{ route('admin.edit') }}"><i class="fa fa-address-card"></i>
        <span class="nav-label">Profile</span></a>
</li>
<li>
    <a href=""><i class="fa fa-navicon"></i><span class="fa arrow"></span>
        <span class="nav-label">Syarat & Ketentuan</span></a>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.sk') }}">List SK</a></li>
        </ul>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.formsk') }}">Tambah SK</a></li>
        </ul>
</li>
@endsection

@section('content')
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>List Customer</h2>
        <ol class="breadcrumb">
            <li>Home
            </li>
            <li>Kelola User
            </li>
            <li class="active">
                <strong>List Customer</strong>
            </li>
        </ol>
    </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <div class="col-md-12">
            <div class="ibox-content">
                <div class="card-header">
                    <h4 class="card-title">List Customer</h4>
                </div>
                <form action="{{ route('admin.user') }}" method="get">
                    <div class="input-group">
                        <!-- KEMUDIAN NAME-NYA ADALAH Q YANG AKAN MENAMPUNG DATA PENCARIAN -->
                        <input type="text" class="form-control" placeholder="Cari..." value="{{ request()->q }}">
                        <span class="input-group-btn"> <input type="submit" value="Cari" class="btn btn-default">
                        </span>
                    </div>
                </form>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Nama</th>
                                <th scope="col">Email</th>
                                <th scope="col">Tgl. Regristrasi</th>
                                <th scope="col">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($customers as $no => $user)
                                
                                <tr>
                                    <th scope="row">{{ ++$no }}</th>
                                    <td>{{ $user->name }}</td>
                                    <td>{{ $user->email }}</td>
                                    <td>{{ $user->created_at }}</td>
                                    @if($user->email_verified_at == null)
                                    <td><span class="label label-warning">Belum Diverifikasi</span></td>
                                    @else
                                    <td><span class="label label-primary">Terverifikasi</span></td>
                                    @endif
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


@endsection
