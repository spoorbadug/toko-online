@extends('layouts.app')

@section('title')
<title>Checkout</title>
@endsection

@section('content')

<!-- Main Container  -->
<div class="main-container container">
    <ul class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i></a></li>
        <li><a href="#">Checkout</a></li>

    </ul>

    <div class="row">
        <!--Middle Part Start-->
        <div id="content" class="col-sm-12">
            <h2 class="title">Checkout</h2>
            @if(session('error'))
                <div class="alert alert-danger">{{ session('error') }}</div>
            @endif
            <div class="so-onepagecheckout row">
                <div class="col-left col-sm-10">
                    <form class="row contact_form" action="{{ route('checkout') }}" method="post"
                        novalidate="novalidate">
                        @csrf
                        <div class="panel panel-default">

                            <div class="panel-heading">
                                <h4 class="panel-title"><i class="fa fa-book"></i> Your Address</h4>
                            </div>

                            <div class="panel-body">
                                <fieldset id="address" class="required">
                                    <label for="name" class="">{{ __('Name') }}</label>
                                    <div class="form-group">
                                        <div>
                                            <input id="name" type="text"
                                                class="form-control @error('name') is-invalid @enderror" name="name"
                                                value="{{ old('name') ?? $user->name ??'' }}"
                                                required autocomplete="name" autofocus>
                                            @error('name')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <label for="phonenumber"
                                        class="">{{ __('Phone Number') }}</label>
                                    <div class="form-group">
                                        <div>
                                            <input id="phonenumber" type="text"
                                                class="form-control @error('phonenumber') is-invalid @enderror"
                                                name="phonenumber"
                                                value="{{ old('phonenumber') ?? $user->profile->phonenumber ??'' }}"
                                                required autocomplete="phonenumber" autofocus>
                                            @error('phonenumber')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <label for="country" class="">{{ __('Country') }}</label>
                                    <div class="form-group">
                                        <div>
                                            <input id="country" type="text"
                                                class="form-control @error('country') is-invalid @enderror"
                                                name="country"
                                                value="{{ old('country') ?? $user->profile->country ??'' }}"
                                                required autocomplete="country" autofocus>
                                            @error('country')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <label for="city" class="">{{ __('City') }}</label>
                                    <div class="form-group">
                                        <div>
                                            <input id="city" type="text"
                                                class="form-control @error('city') is-invalid @enderror" name="city"
                                                value="{{ old('city') ?? $user->profile->city ??'' }}"
                                                required autocomplete="city" autofocus>
                                            @error('city')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <label for="address" class="">{{ __('Address') }}</label>
                                    <div class="form-group">
                                        <div>
                                            <input id="address" type="text"
                                                class="form-control @error('address') is-invalid @enderror"
                                                name="address"
                                                value="{{ old('address') ?? $user->profile->address ??'' }}"
                                                required autocomplete="address" autofocus>
                                            @error('address')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <label for="zipcode" class="">{{ __('Zipcode') }}</label>
                                    <div class="form-group">
                                        <div>
                                            <input id="zipcode" type="text"
                                                class="form-control @error('zipcode') is-invalid @enderror"
                                                name="zipcode"
                                                value="{{ old('zipcode') ?? $user->profile->zipcode ??'' }}"
                                                required autocomplete="zipcode" autofocus>
                                            @error('zipcode')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </fieldset>
                            </div>
                            <div class="pull-right">
                                <button type="submit" class="main_btn">BUY NOW</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-right col-sm-2">
                    <h2 class="subtitle">Account</h2>
                    <div class="list-group">
                        <ul class="list-item">
                            <li><a href="login.html">Login</a>
                            </li>
                            <li><a href="register.html">Register</a>
                            </li>
                            <li><a href="#">Forgotten Password</a>
                            </li>
                            <li><a href="#">My Account</a>
                            </li>
                            <li><a href="#">Address Books</a>
                            </li>
                            <li><a href="wishlist.html">Wish List</a>
                            </li>
                            <li><a href="#">Order History</a>
                            </li>
                            <li><a href="#">Downloads</a>
                            </li>
                            <li><a href="#">Reward Points</a>
                            </li>
                            <li><a href="#">Returns</a>
                            </li>
                            <li><a href="#">Transactions</a>
                            
                        </ul>
                    </div>

                </div>


            </div>
        </div>
        <!--Middle Part End -->
    </div>
    <!-- //Main Container -->
</div>

@endsection
