@extends('layouts.app')

@section('title')
<title>{{ $showproduct->name }}</title>
@endsection

@section('content')
<!-- Main Container  -->
<div class="main-container container">
    <ul class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i></a></li>
        <li><a href="#">{{ $showproduct->category->name }}</a></li>
        <li><a href="#">{{ $showproduct->name }}</a></li>
    </ul>

    <div class="row">

        <!--Middle Part Start-->
        <div id="content" class="col-md-9 col-sm-8">

            <div class="product-view">
                <div class="left-content-product">
                    <div class="row">
                        <div class="content-product-left col-md-6 col-sm-12 col-xs-12">
                            <div id="thumb-slider-vertical" class="thumb-vertical-outer">
                                <!-- <span class="btn-more prev-thumb nt"><i class="fa fa-angle-up"></i></span>
                                <span class="btn-more next-thumb nt"><i class="fa fa-angle-down"></i></span> -->

                            </div>
                            <div class="large-image  vertical">
                                <img itemprop="image" class="product-image-zoom"
                                    src="{{ asset('/storage/products/'.$showproduct->image) }}"
                                    alt="{{ $showproduct->name }}">

                            </div>
                        </div>

                        <div class="content-product-right col-md-6 col-sm-12 col-xs-12">
                            <div class="title-product">
                                <h1>{{ $showproduct->name }}</h1>
                            </div>

                            <div class="product-label form-group">
                                <div class="product_page_price price" itemprop="offerDetails" itemscope="" itemtype="http://data-vocabulary.org/Offer">
                                    <span class="price-new" itemprop="price">Rp
                                        {{ number_format($showproduct->price) }}</span>
                                </div>
                                @if ($showproduct->stok == 0)
                                <div class="stock"><span>Stok :</span> <span class="status-stock">Habis</span></div>
                                @else
                                <div class="stock"><span>Stok :</span> <span class="status-stock">{{ $showproduct->stok }}</span></div>
                                @endif
                                
                            </div>

                            <div class="product-box-desc">
                                <div class="inner-box-desc">
                                    <div class="brand"><span>Unit : </span><a href="#">{{ $unit->user->name }}</a></div>
                                    <div class="brand"><span>No. Telepon : </span><a href="#">{{ $profiles->phonenumber }}</a></div>
                                    <div class="weight"><span>Berat : </span><span class="status-order">{{ $showproduct->weight }} Gram</span></div>
                                    <div class="order"><span>Minimal Order : </span><span class="status-order">{{ $showproduct->min_order }}</span></div>
                                    
                                </div>
                            </div>

                            <div id="product">
                                <form
                                    action="{{ route('front.cart',['product'=>$showproduct->id]) }}"
                                    method="POST">
                                    @csrf
                                    <div class="form-group">
                                        <div class="option quantity">
                                            <div class="input-group quantity-control" unselectable="on"
                                                style="-webkit-user-select: none;">
                                                <label>Qty</label>
                                                <input type="text" name="qty" id="sst" value="{{ $showproduct->min_order }}"
                                                    title="Quantity:" class="input-text qty">
                                                <!-- BUAT INPUTAN HIDDEN YANG BERISI ID PRODUK -->
                                                <input type="hidden" name="product_id" value="{{ $showproduct->id }}"
                                                    class="form-control">
                                                <button
                                                    onclick="var result = document.getElementById('sst'); var sst = result.value; if( !isNaN( sst ) &amp;&amp; sst > 0 ) result.value--;return false;"
                                                    class="reduced items-count" type="button"
                                                    class="input-group-addon product_quantity_down">-
                                                    <i class="lnr lnr-chevron-down"></i>
                                                </button>
                                                <button
                                                    onclick="var result = document.getElementById('sst'); var sst = result.value; if( !isNaN( sst )) result.value++;return false;"
                                                    class="increase items-count" type="button"
                                                    class="input-group-addon product_quantity_up">+
                                                    <i class="lnr lnr-chevron-up"></i>
                                                </button>
                                                
                                            </div>
                                        </div>
                                        {{-- <button data-toggle="tooltip" title="" value="Add to Cart"
                                            data-loading-text="Loading..." id="button-cart"
                                            class="main_btn btn-mega btn-lg"
                                            onclick="cart.add({{ $showproduct->id }}, '{{ $showproduct->id }}');"
                                            data-original-title="Add to Cart">Add to Cart</button> --}}
                                    </div>
                                    <div class="form-group">
                                        <div class="cart">
                                            <button data-toggle="tooltip" title="" value="Add to Cart"
                                                data-loading-text="Loading..." id="button-cart"
                                                class="main_btn btn-mega btn-lg first"
                                                
                                                data-original-title="Add to Cart">Add to Cart</button>
                                        </div>
                                        {{-- <div class="add-to-links wish_comp">
                                        <ul class="blank list-inline">
                                            <li class="wishlist">
                                                <a class="icon" data-toggle="tooltip" title=""
                                                    onclick="wishlist.add('50');"
                                                    data-original-title="Add to Wish List"><i class="fa fa-heart"></i>
                                                </a>
                                            </li>
                                            <li class="compare">
                                                <a class="icon" data-toggle="tooltip" title=""
                                                    onclick="compare.add('50');"
                                                    data-original-title="Compare this Product"><i
                                                        class="fa fa-exchange"></i>
                                                </a>
                                            </li>
                                        </ul>
                                    </div> --}}

                                    </div>
                                </form>
                            </div>
                            <!-- end box info product -->

                        </div>
                    </div>
                </div>


            </div>

            <!-- Product Tabs -->
            <div class="producttab ">
                <div class="tabsslider horizontal-tabs  col-xs-12">
                    <ul class="nav nav-tabs">
                        <li class="active"><a data-toggle="tab" href="#tab-1">Description</a></li>
                        <li class="item_nonactive"><a data-toggle="tab" href="#tab-review">Reviews (1)</a></li>
                    </ul>
                    <div class="tab-content col-xs-12">
                        <div id="tab-1" class="tab-pane fade active in">
                            <p>{!! $showproduct->description !!}</p>
                        </div>
                        <div id="tab-review" class="tab-pane fade">
                            <form>
                                <div id="review">
                                    <table class="table table-striped table-bordered">
                                        <tbody>
                                            <tr>
                                                <td style="width: 50%;"><strong>Super Administrator</strong></td>
                                                <td class="text-right">29/07/2015</td>
                                            </tr>
                                            <tr>
                                                <td colspan="2">
                                                    <p>Best this product opencart</p>
                                                    <div class="ratings">
                                                        <div class="rating-box">
                                                            <span class="fa fa-stack"><i
                                                                    class="fa fa-star fa-stack-1x"></i><i
                                                                    class="fa fa-star-o fa-stack-1x"></i></span>
                                                            <span class="fa fa-stack"><i
                                                                    class="fa fa-star fa-stack-1x"></i><i
                                                                    class="fa fa-star-o fa-stack-1x"></i></span>
                                                            <span class="fa fa-stack"><i
                                                                    class="fa fa-star fa-stack-1x"></i><i
                                                                    class="fa fa-star-o fa-stack-1x"></i></span>
                                                            <span class="fa fa-stack"><i
                                                                    class="fa fa-star fa-stack-1x"></i><i
                                                                    class="fa fa-star-o fa-stack-1x"></i></span>
                                                            <span class="fa fa-stack"><i
                                                                    class="fa fa-star-o fa-stack-1x"></i></span>
                                                        </div>
                                                        <form action="">
                                                            <input class="star star-5" id="star-5" type="radio" name="star"/>
                                                            <label class="star star-5" for="star-5"></label>
                                                            <input class="star star-4" id="star-4" type="radio" name="star"/>
                                                            <label class="star star-4" for="star-4"></label>
                                                            <input class="star star-3" id="star-3" type="radio" name="star"/>
                                                            <label class="star star-3" for="star-3"></label>
                                                            <input class="star star-2" id="star-2" type="radio" name="star"/>
                                                            <label class="star star-2" for="star-2"></label>
                                                            <input class="star star-1" id="star-1" type="radio" name="star"/>
                                                            <label class="star star-1" for="star-1"></label>
                                                          </form>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <div class="text-right"></div>
                                </div>
                                <h2 id="review-title">Write a review</h2>
                                <div class="contacts-form">
                                    <div class="form-group"> <span class="icon icon-user"></span>
                                        <input type="text" name="name" class="form-control" value="Your Name"
                                            onblur="if (this.value == '') {this.value = 'Your Name';}"
                                            onfocus="if(this.value == 'Your Name') {this.value = '';}">
                                    </div>
                                    <div class="form-group"> <span class="icon icon-bubbles-2"></span>
                                        <textarea class="form-control" name="text"
                                            onblur="if (this.value == '') {this.value = 'Your Review';}"
                                            onfocus="if(this.value == 'Your Review') {this.value = '';}">Your Review</textarea>
                                    </div>

                                    <div class="form-group">
                                        <b>Rating</b> <span>Bad</span>&nbsp;
                                        <input type="radio" name="rating" value="1"> &nbsp;
                                        <input type="radio" name="rating" value="2"> &nbsp;
                                        <input type="radio" name="rating" value="3"> &nbsp;
                                        <input type="radio" name="rating" value="4"> &nbsp;
                                        <input type="radio" name="rating" value="5"> &nbsp;<span>Good</span>

                                    </div>
                                    <div class="buttons clearfix"><a id="button-review"
                                            class="btn buttonGray">Continue</a></div>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
            <!-- //Product Tabs -->





        </div>
        <!--Middle Part End-->
        <!--Left Part Start -->
        <aside class="col-sm-4 col-md-3 content-aside" id="column-left">
            <div class="module category-style">
                <h3 class="modtitle">Kategori</h3>
                <div class="modcontent">
                    <div class="box-category">
                        <ul id="cat_accordion" class="list-group">
                            @foreach($categories as $category)
                                <li>
                                    <a
                                        href="{{ url('/kategori/' . $category->slug) }}">{{ $category->name }}</a>
                                    {{-- @foreach($category->child as $child)
                                        <ul class="list" style="display: block">
                                            <li>
                                                <a href="{{ url('/kategori/' . $child->slug) }}"
                                    class="custom-parent">{{ $child->name }}</a><span class="dcjq-icon"></span>
                                </li>
                        </ul>
                        @endforeach--}}
                        </li>
                        @endforeach
                        </ul>
                    </div>


                </div>
            </div>
            <div class="module product-simple">
                <h3 class="modtitle">
                    <span>Product Terbaru</span>
                </h3>
                <div class="modcontent">
                    <div class="so-extraslider">
                        <!-- Begin extraslider-inner -->
                        <div class=" extraslider-inner">
                            <div class="item ">
                                @forelse($newproducts as $row)
                                    <div class="product-layout item-inner style1 ">

                                        <div class="item-image">
                                            <div class="item-img-info">
                                                <a href="{{ url('/produk/'.$row->slug) }}"
                                                    target="_self" title="{{ $row->name }}">
                                                    <img src="{{ asset('storage/products/'.$row->image) }}"
                                                        class="img-1 img-responsive" alt="{{ $row->name }}">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="item-info">
                                            <div class="item-title">
                                                <a href="{{ url('/produk/'.$row->slug) }}"
                                                    target="_self" title="{{ $row->name }}">{{ $row->name }}</a>
                                            </div>
                                            <div class="content_price price">
                                                <span class="price-new product-price">Rp
                                                    {{ number_format($row->price) }}</span>&nbsp;&nbsp;
                                            </div>
                                        </div>
                                        <!-- End item-info -->
                                        <!-- End item-wrap-inner -->
                                    </div>
                                @empty
                                @endforelse
                                <!-- End item-wrap -->

                            </div>
                        </div>
                        <!--End extraslider-inner -->
                    </div>
                </div>
            </div>

        </aside>
        <!--Left Part End -->
    </div>

</div>
<!-- //Main Container -->
@endsection
