@extends('layouts.admin')

@section('title')
<title>Dashboard Unit</title>
@endsection

@section('menuside')
<li class="active">
    <a href="{{ route('unit.index') }}"><i class="fa fa-th-large"></i>
        <span class="nav-label">Dashboard</span></a>
</li>
<li>
    <a href="{{ route('categoryunit.index') }}"><i class="fa fa-industry"></i>
        <span class="nav-label">Category</span></a>
</li>
<li>
    <a href="#"><i class="fa fa-archive"></i><span class="fa arrow"></span>
        <span class="nav-label">Product</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('productunit.index') }}">List Produk</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('productunit.create') }}">Tambah Produk</a></li>
    </ul>
</li>
<li>
    <a href=""><i class="fa fa-cart-plus"></i><span class="fa arrow"></span>
        <span class="nav-label">Order</span></a>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('unit.order') }}">List Order</a></li>
        </ul>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('unit.komplain') }}">Komplain</a></li>
        </ul>
</li>
<li>
    <a href="{{ route('unit.edit') }}"><i class="fa fa-address-card"></i>
        <span class="nav-label">Profile</span></a>
</li>
@endsection

@section('content')
<main class="main">
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>Dashboard Admin</h2>
            <ol class="breadcrumb">
                <li>
                    <a href="index.html">Home</a>
                </li>
                <li class="active">
                    <strong>Dashboard</strong>
                </li>
            </ol>
        </div>
        <div class="col-lg-2">

        </div>
    </div>
    <div class="wrapper wrapper-content">
        <div class="row">
            <div class="col-lg-3">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Akun Customer</h5>
                    </div>
                    <div class="ibox-content">
                        <h1 class="no-margins">{{ $totalCustomer }}</h1>
                        <small>Terdaftar</small>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Komplain</h5>
                    </div>
                    <div class="ibox-content">
                        <h1 class="no-margins">{{ $komplain }}</h1>
                        <small>Pesanan</small>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Orders</h5>
                    </div>
                    <div class="ibox-content">
                        <h1 class="no-margins">{{ $totalorder }}</h1>
                        <small>New orders</small>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Total Penjualan</h5>
                    </div>
                    <div class="ibox-content">
                        <h1 class="no-margins">Rp {{ number_format($totalgross) }}</h1>
                        <small>Total</small>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="ibox">
                    <div class="ibox-content">
                        <table class="footable table table-stripped toggle-arrow-tiny" data-page-size="15">
                            <thead>
                                <tr>
                                    <th>InvoiceID</th>
                                    <th>Pelanggan</th>
                                    <th>Tanggal</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($listorder as $row)
                                    <tr>
                                        <td>{{ $row->invoice }}</td>
                                        <td>{{ $row->profile->name }}</td>
                                        <td>{{ $row->created_at->format('d-m-Y') }}</td>
                                        <td>{!! $row->status->name !!}</td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="6" class="text-center">Tidak ada data</td>
                                    </tr>
                                @endforelse

                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="7">
                                        <ul class="pagination pull-right"></ul>
                                        {!! $listorder->links() !!}
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                        {{-- {!! $pesanan->links() !!} --}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection