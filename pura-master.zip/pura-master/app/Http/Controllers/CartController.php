<?php

namespace App\Http\Controllers;
use App;
use App\Product;
use App\Cart;
use Session;
use Illuminate\Http\Request;
use Alert;

class CartController extends Controller
{

    private function getCarts()
    {
        $carts = json_decode(request()->cookie('pura-carts'), true);
        $carts = $carts != '' ? $carts:[];
        return $carts;
    }

    public function add(Request $request, $id)
    {
        
        // $product = Product::find($id);
        // $oldCart = Session::has('cart') ? Session::get('cart') : null;
        // $cart = new Cart($oldCart);
        // $cart->add($product,$product->id,$request->qty);
        // //dd($cart);
        // $request->session()->put('cart',$cart);
        // return redirect()->route('cart.index');

    }

    public function remove($id)
    {
        $carts = $this->getCarts();

        foreach ($request->product_id as $key => $row) {

            unset($carts[$row]);
            
        }

        $cookie = cookie('pura-carts', json_encode($carts), 2880);

        return redirect()->back()->cookie($cookie);
    }

    public function index()
    {
        // if(!Session::has('cart')){
        //     return view('cart.index',['products'=>null]);
        // }
        // $oldCart= Session::get('cart');
        // $cart= new Cart($oldCart);
        // $products = $cart->items;
        // $totalPrice = $cart->totalPrice;
        // $totalQuantity= $cart->totalQuantity;
        return view('cart.index', compact('products','totalPrice','totalQuantity'));

    }

    public function addToCart(Request $request)
    {
        $this->validate($request, [
            'product_id' => 'required|exists:products,id', //PASTIKAN PRODUCT_IDNYA ADA DI DB
            'qty' => 'required|integer' //PASTIKAN QTY YANG DIKIRIM INTEGER
        ]);

        $carts = $this->getCarts();
        $product = Product::find($request->product_id);

        if ($carts && array_key_exists($request->product_id, $carts)) {
            $carts[$request->product_id]['qty'] += $request->qty;
        } elseif ($product->stok == 0) {
            toast('Stok produk sudah habis','warning');
        } elseif ($request->qty >= $product->min_order) {
            $carts[$request->product_id] = [
                'qty' => $request->qty,
                'product_id' => $product->id,
                'product_name' => $product->name,
                'product_price' => $product->price,
                'product_image' => $product->image,
                'product_weight' => $product->weight
            ];
            toast('Produk telah ditambahkan','success');
        } else {
            toast('Harus lebih dari minimal pesan','info');
        }

        $cookie = cookie('pura-carts', json_encode($carts), 2880);
        
        return redirect()->back()->cookie($cookie);
    }

    public function listCart()
    {
        $carts = $this->getCarts();
        $subtotal = collect($carts)->sum(function($q) {
            return $q['qty'] * $q['product_price'];
        });

        $weight = collect($carts)->sum(function($q) {
            return $q['qty'] * $q['product_weight'];
        });

        return view('cart.index', compact('carts', 'subtotal', 'weight'));
    }

    public function updateCart(Request $request)
    {
        $carts = $this->getCarts();

        foreach ($request->product_id as $key => $row) {

            if ($request->qty[$key] == 0) {
                unset($carts[$row]);
            } else {
                $carts[$row]['qty'] = $request->qty[$key];
            }
        }

        $cookie = cookie('pura-carts', json_encode($carts), 2880);

        return redirect()->back()->cookie($cookie);
    }
}