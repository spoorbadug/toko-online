<?php

namespace App\Http\View;

use Illuminate\View\View;
use App\Category;
use App\User;
use App\Product;

class Composer
{

    private function getCarts()
    {
        $carts = json_decode(request()->cookie('pura-carts'), true);
        $carts = $carts != '' ? $carts:[];
        return $carts;
    }

    public function compose(View $view)
    {
        $categories = Category::where('status', '1')->orderBy('created_at', 'DESC')->get();
        $view->with('categories', $categories);

        $newproducts = Product::with(['category'])->where('status', '1')->orderBy('created_at', 'DESC')->take(4)->get();
        $view->with('newproducts', $newproducts);
        

        $carts = $this->getCarts();

        $ncarts = count($carts);
        $view->with('ncarts', $ncarts);

        $ntotal = collect($carts)->sum(function($q) {
            return $q['qty'] * $q['product_price'];
        });
        $view->with('ntotal', $ntotal);
    }
}