@extends('layouts.app')

@section('title')
<title>Kontak Kami</title>
@endsection

@section('content')
<!-- Main Container  -->
<div class="main-container container">
    <ul class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i></a></li>
        <li><a href="#">Kontak Kami</a></li>
    </ul>

    <div class="row">
        <div id="content" class="col-sm-12">
            <div class="page-title">
                <h2>Lokasi</h2>
            </div>
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1247.779796459421!2d110.82279205964343!3d-6.8360571608466945!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x5e7bef36664f9281!2sPura%20Group%20Head%20Office!5e0!3m2!1sid!2sid!4v1611891336358!5m2!1sid!2sid"
                width="100%" height="350" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false"
                tabindex="0"></iframe>
            <div class="divider"></div>
            <div class="info-contact clearfix">
                <div class="col-lg-4 col-sm-4 col-xs-12 info-store">
                    <div class="row">
                        <div class="name-store">
                            <h2>Kudus</h2>
                        </div>
                        <address>
                            <div class="address clearfix form-group">
                                <div class="icon">
                                    <i class="fa fa-home"></i>
                                </div>
                                <div class="text">Kantor Pusat Pura Group</div>
                            </div>
                            <div class="address form-group">
                                <div class="icon">
                                    <i class="fa fa-map-marker"></i>
                                </div>
                                <div class="text">Jl. AKBP. Agil Kusumadya 203 Kudus 59346, Indonesia</div>
                            </div>
                            <div class="phone form-group">
                                <div class="icon">
                                    <i class="fa fa-phone"></i>
                                </div>
                                <div class="text">+62 291 444361 / 444363 (30 lines)</div>
                            </div>
                            <div class="fax form-group">
                                <div class="icon">
                                    <i class="fa fa-fax"></i>
                                </div>
                                <div class="text">+62 291 444403, +62 291 432586</div>
                            </div>
                            <div class="email form-group">
                                <div class="icon">
                                    <i class="fa fa-envelope"></i>
                                </div>
                                <div class="text">marketing@puragroup.com</div>
                            </div>
                        </address>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-4 col-xs-12 info-store">
                    <div class="row">
                        <div class="name-store">
                            <h2>Jakarta</h2>
                        </div>
                        <address>
                            <div class="address clearfix form-group">
                                <div class="icon">
                                    <i class="fa fa-home"></i>
                                </div>
                                <div class="text">Kantor Pemasaran</div>
                            </div>
                            <div class="address form-group">
                                <div class="icon">
                                    <i class="fa fa-map-marker"></i>
                                </div>
                                <div class="text">Graha Pura
                                    Jl. Pancoran Indah I No. 52
                                    Jakarta Selatan 12780, Indonesia</div>
                            </div>
                            <div class="phone form-group">
                                <div class="icon">
                                    <i class="fa fa-phone"></i>
                                </div>
                                <div class="text">+62 21 79193585, 79193686 (30 lines)</div>
                            </div>
                            <div class="fax form-group">
                                <div class="icon">
                                    <i class="fa fa-fax"></i>
                                </div>
                                <div class="text">+62 21 79193586-87, 79193774-75</div>
                            </div>
                        </address>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-4 col-xs-12 info-store">
                    <div class="row">
                        <div class="name-store">
                            <h2>Surabaya</h2>
                        </div>
                        <address>
                            <div class="address clearfix form-group">
                                <div class="icon">
                                    <i class="fa fa-home"></i>
                                </div>
                                <div class="text">Kantor Pemasaran</div>
                            </div>
                            <div class="address form-group">
                                <div class="icon">
                                    <i class="fa fa-map-marker"></i>
                                </div>
                                <div class="text">Komplek Pertokoan Delta Permai
                                    Jl. Raya Panjang Jiwo Permai I, B19-20
                                    Surabaya 60299, Indonesia</div>
                            </div>
                            <div class="phone form-group">
                                <div class="icon">
                                    <i class="fa fa-phone"></i>
                                </div>
                                <div class="text">+62 31 8421325, 8421326 (6 lines)</div>
                            </div>
                            <div class="fax form-group">
                                <div class="icon">
                                    <i class="fa fa-fax"></i>
                                </div>
                                <div class="text">+62 31 8421324</div>
                            </div>
                        </address>
                    </div>
                </div>

            </div>
            <div class="divider"></div>
            <div class="info-contact clearfix">
                <div class="col-lg-6 col-sm-6 col-xs-12 info-store">
                    <div class="row">
                        <div class="name-store">
                            <h2>Semarang</h2>
                        </div>
                        <address>
                            <div class="address clearfix form-group">
                                <div class="icon">
                                    <i class="fa fa-home"></i>
                                </div>
                                <div class="text">Kantor Pemasaran</div>
                            </div>
                            <div class="address form-group">
                                <div class="icon">
                                    <i class="fa fa-map-marker"></i>
                                </div>
                                <div class="text">Thamrin Square Block C1
                                    Jl. MH. Thamrin No. 5
                                    Semarang 50134, Indonesia</div>
                            </div>
                            <div class="phone form-group">
                                <div class="icon">
                                    <i class="fa fa-phone"></i>
                                </div>
                                <div class="text">+62 24 76588200, 76588201 (15 lines)</div>
                            </div>
                            <div class="fax form-group">
                                <div class="icon">
                                    <i class="fa fa-fax"></i>
                                </div>
                                <div class="text">+62 24 76588203, 76588207</div>
                            </div>
                        </address>
                    </div>
                </div>
                <div class="col-lg-6 col-sm-6 col-xs-12 info-store">
                    <div class="row">
                        <div class="name-store">
                            <h2>Bandung</h2>
                        </div>
                        <address>
                            <div class="address clearfix form-group">
                                <div class="icon">
                                    <i class="fa fa-home"></i>
                                </div>
                                <div class="text">Kantor Pemasaran</div>
                            </div>
                            <div class="address form-group">
                                <div class="icon">
                                    <i class="fa fa-map-marker"></i>
                                </div>
                                <div class="text">Jl. Kopo No. 618
                                    Komplek Kopo Mas Regency Blok N1 I D
                                    Bandung. Indonesia</div>
                            </div>
                            <div class="phone form-group">
                                <div class="icon">
                                    <i class="fa fa-phone"></i>
                                </div>
                                <div class="text">+62 22 5430673</div>
                            </div>
                            <div class="fax form-group">
                                <div class="icon">
                                    <i class="fa fa-fax"></i>
                                </div>
                                <div class="text">+62 22 5430661</div>
                            </div>
                        </address>
                    </div>
                </div>
            </div>
            <div class="divider"></div>
            
        </div>
    </div>
</div>
<!-- //Main Container -->
@endsection
