@extends('layouts.app')

@section('title')
    <title>List Pesanan</title>
@endsection

@section('content')
 <!-- Main Container  -->
 <div class="main-container container">
    <ul class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i></a></li>
        <li><a href="#">Akun</a></li>
        <li><a href="#">List Pesanan</a></li>
    </ul>
    
    <div class="row">
        <!--Middle Part Start-->
        <div id="content" class="col-sm-12">
            <h2 class="title">List Pesanan</h2>
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Invoice</th>
                            <th>Penerima</th>
                            <th>No Telp</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Tanggal</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($orders as $row) 
                        <tr>
                            <td><strong>{{ $row->invoice }}</strong></td>
                            <td>{{ $row->user->profile->name }}</td>
                            <td>{{ $row->user->profile->phonenumber }}</td>
                            <td>Rp. {{ number_format($row->total) }}</td>
                            <td>{!! $row->status->name !!}</td>
                            <td>{{ $row->created_at->format('d-m-Y') }}</td>
                            <td>
                                <div class="text-center">
                                <a href="{{ route('order.detail', $row->invoice) }}" class="btn btn-primary btn-sm">Detail</a>
                                <a href="{{ route('order.cancel', $row->invoice) }}" class="btn btn-danger btn-sm">Batalkan</a>
                                </div>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="7" class="text-center">Tidak ada pesanan</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

        </div>
        <!--Middle Part End-->
        
    </div>
</div>
<!-- //Main Container -->
@endsection