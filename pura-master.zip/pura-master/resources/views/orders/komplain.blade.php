@extends('layouts.app')

@section('title')
<title>Komplain Pesanan</title>
@endsection

@section('content')
<!-- Main Container  -->
<div class="main-container container">
    <ul class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i></a></li>
        <li><a href="#">Return</a></li>
    </ul>
    <div id="content" class="col-sm-12">
        <h2 class="title">Informasi Pesanan</h2>
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <td colspan="2" class="text-left">Detail Pesanan</td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <?php
                        $city = \App\City::where('city_id', $order->profile->city_id)->first();
                        $province = \App\Province::where('province_id', $order->profile->province_id)->first();
                    ?>
                    <td style="width: 50%;" class="text-left"> <b>ID Pesanan :</b> {{ $order->invoice }}
                        <br><b>Tanggal Pesanan :</b> {{ $order->created_at->format('d-m-Y') }}
                        <br><b>Nama Pemesan :</b> {{ $order->profile->name }}
                        <br><b>Alamat :</b>{{ $order->profile->address }}, {{ $city->name }},
                        {{ $province->name }}
                </tr>
            </tbody>
        </table>

        <form action="{{ route('order.storekomplain', $order->id) }}" method="post" enctype="multipart/form-data">
            @csrf
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <td colspan="2" class="text-left">Detail Barang</td>
                    </tr>
                </thead>
                <tbody>

                    <tr>
                        <input type="hidden" name="order_id" value="{{ $order->id }}" class="form-control">
                        <input type="hidden" name="user_id" value="{{ $order->user_id }}" class="form-control">
                        <td class="text-left">Nama Produk</td>
                        <td><select name="product_id" class="form-control">
                                <option value="">--- Pilih Produk ---</option>
                                @foreach($listproduct as $row)
                                    <option value="{{ $row->product->id }}">{{ $row->product->name }}</option>
                                @endforeach
                            </select>
                            <p class="text-danger">{{ $errors->first('nama_produk') }}
                        </td>
                    </tr>
                    <tr>
                        <td class="text-left">Jumlah</td>
                        <td><input type="text" class="form-control" id="input-quantity"
                                value="{{ old('jumlah') }}" name="jumlah"></td>
                        <p class="text-danger">{{ $errors->first('jumlah') }}
                    </tr>
                    <tr>
                        <td class="text-left">Alasan Komplain</td>
                        <td>
                            <select name="komplainstatus_id" class="form-control">
                                <option value="">--- Pilih Alasan ---</option>
                                @foreach($listkomplain as $row)
                                <option value="{{ $row->id }}">{{ $row->name }}</option>
                                @endforeach
                            </select>
                            <p class="text-danger">{{ $errors->first('komplainstatus_id') }}
                        </td>
                    </tr>
                    <tr>
                        <td class="text-left">Gambar</td>
                        <td><input type="file" name="image" value="{{ old('image') }}">
                            <p class="text-danger">{{ $errors->first('image') }}
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <td class="text-left">Catatan</td>
                        <td><textarea class="form-control" id="input-comment"
                                value="{{ old('catatan') }}" rows="10" name="catatan"></textarea></td>
                        <p class="text-danger">{{ $errors->first('catatan') }}
                    </tr>

                </tbody>
            </table>
            <div class="buttons">
                <div class="pull-right">
                    <button class="btn btn-primary">Komplain</button>
                </div>
            </div>

        </form>
    </div>
</div>
@endsection
