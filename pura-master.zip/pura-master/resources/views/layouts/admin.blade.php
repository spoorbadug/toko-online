<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    @yield('title')

    <link href="{{ secure_asset('css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ secure_asset('font-awesome/css/font-awesome.css') }}" rel="stylesheet">

    <link href="{{ secure_asset('css/animate.css') }}" rel="stylesheet">
    <link href="{{ secure_asset('css/style.css') }}" rel="stylesheet">

    <link rel="shortcut icon" type="image/png" href="{{ secure_asset('image/logo-16px.png') }}" />

    
</head>

<body>
    @include('sweetalert::alert')

    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav metismenu" id="side-menu">
                    <li class="nav-header">
                        <div class="dropdown profile-element"> <span>
                                <img alt="image" class="img-circle" src="/image/logo.png" height="70" width="70" />
                            </span>
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <span class="clear"> <span class="block m-t-xs"> <strong
                                            class="font-bold">{{ Auth::user()->name }}</strong>
                                    </span> <span class="text-muted text-xs block">Pura Group</span> </span> </a>
                    
                        </div>
                        <div class="logo-element">
                            <img alt="image" class="img-circle" src="/image/logo.png" height="50" width="50" />
                        </div>
                    </li>
                    
                    @yield('menuside')

            </div>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <div class="navbar-header">
                        <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i
                                class="fa fa-bars"></i> </a>

                    </div>
                    <ul class="nav navbar-top-links navbar-right">
                        <li>
                            <a href="{{ route('xdmin.logout') }}" onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                                <i class="fa fa-lock"></i> Logout
                            </a>

                            <form id="logout-form" action="{{ route('xdmin.logout') }}" method="POST"
                                style="display: none;">
                                @csrf
                            </form>
                        </li>
                    </ul>
                </nav>
            </div>

            @yield('content')

            <div class="footer">
                <div class="pull-right">
                    Design by <strong>INSPINIA+</strong>
                </div>
                <div>
                    <strong>Copyright</strong> Pura Group &copy; <?php echo date("Y")?>
                </div>
            </div>
        </div>
    </div>

    <!-- Mainly scripts -->
    <script src="{{ secure_asset('js/jquery-3.1.1.min.js') }}"></script>
    <script src="{{ secure_asset('js/plugins/metisMenu/jquery.metisMenu.js') }}"></script>
    <script src="{{ secure_asset('js/plugins/slimscroll/jquery.slimscroll.min.js') }}"></script>

    <!-- Flot -->
    <script src="{{ secure_asset('js/plugins/flot/jquery.flot.js') }}"></script>
    <script src="{{ secure_asset('js/plugins/flot/jquery.flot.tooltip.min.js') }}"></script>
    <script src="{{ secure_asset('js/plugins/flot/jquery.flot.spline.js') }}"></script>
    <script src="{{ secure_asset('js/plugins/flot/jquery.flot.resize.js') }}"></script>
    <script src="{{ secure_asset('js/plugins/flot/jquery.flot.pie.js') }}"></script>
    <script src="{{ secure_asset('js/plugins/flot/jquery.flot.symbol.js') }}"></script>
    <script src="{{ secure_asset('js/plugins/flot/jquery.flot.time.js') }}"></script>

    <!-- Peity -->
    <script src="{{ secure_asset('js/plugins/peity/jquery.peity.min.js') }}"></script>
    <script src="{{ secure_asset('js/demo/peity-demo.js') }}"></script>

    <!-- Custom and plugin javascript -->
    <script src="{{ secure_asset('js/inspinia.js') }}"></script>
    <script src="{{ secure_asset('js/plugins/pace/pace.min.js') }}"></script>

    <!-- jQuery UI -->
    <script src="{{ secure_asset('js/plugins/jquery-ui/jquery-ui.min.js') }}"></script>

    <!-- Jvectormap -->
    <script src="{{ secure_asset('js/plugins/jvectormap/jquery-jvectormap-2.0.2.min.js') }}"></script>
    <script src="{{ secure_asset('js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js') }}">
    </script>

    <!-- EayPIE -->
    <script src="{{ secure_asset('js/plugins/easypiechart/jquery.easypiechart.js') }}"></script>

    <!-- SUMMERNOTE -->
    @yield('js')

    <!-- Sparkline -->
    <script src="{{ secure_asset('js/plugins/sparkline/jquery.sparkline.min.js') }}"></script>

    <!-- Sparkline demo data  -->
    <script src="{{ secure_asset('js/demo/sparkline-demo.js') }}"></script>




</body>

</html>
