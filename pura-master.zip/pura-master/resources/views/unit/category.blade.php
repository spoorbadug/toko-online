@extends('layouts.admin')

@section('title')
<title>List Kategori</title>
@endsection

@section('menuside')
<li>
    <a href="{{ route('unit.index') }}"><i class="fa fa-th-large"></i>
        <span class="nav-label">Dashboard</span></a>
</li>
<li class="active">
    <a href="{{ route('categoryunit.index') }}"><i class="fa fa-industry"></i>
        <span class="nav-label">Category</span></a>
</li>
<li>
    <a href="#"><i class="fa fa-archive"></i><span class="fa arrow"></span>
        <span class="nav-label">Product</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('productunit.index') }}">List Produk</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('productunit.create') }}">Tambah Produk</a></li>
    </ul>
</li>
<li>
    <a href="{{ route('unit.order') }}"><i class="fa fa-cart-plus"></i>
        <span class="nav-label">Order</span></a>
</li>
<li>
    <a href="{{ route('unit.edit') }}"><i class="fa fa-address-card"></i>
        <span class="nav-label">Profile</span></a>
</li>
@endsection

@section('content')
<main class="main">
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>Kategori</h2>
            <ol class="breadcrumb">
                <li>Home
                </li>
                <li class="active">
                    <strong>Kategori</strong>
                </li>
            </ol>
        </div>
        <div class="col-lg-2">

        </div>
    </div>
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">

            <!-- BAGIAN INI AKAN MENG-HANDLE FORM INPUT NEW CATEGORY  -->
            
            <!-- BAGIAN INI AKAN MENG-HANDLE FORM INPUT NEW CATEGORY  -->

            <!-- BAGIAN INI AKAN MENG-HANDLE TABLE LIST CATEGORY  -->
            
            <div class="col-md-8">
                <div class="ibox-content">
                    <div class="card-body">
                      
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Kategori</th>
                                        <th>Unit</th>
                                        <th>Status</th>
                                        <th>Created At</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- LOOPING DATA KATEGORI SESUAI JUMLAH DATA YANG ADA DI VARIABLE $CATEGORY -->
                                    @forelse ($category as $val)
                                    <tr>
                                        <td></td>
                                        <td>{{ $val->name }}</td>

                                        <!-- MENGGUNAKAN TERNARY OPERATOR, UNTUK MENGECEK, JIKA $val->parent ADA MAKA TAMPILKAN NAMA PARENTNYA, SELAIN ITU MAKA TANMPILKAN STRING - -->
                                        <td>{{ $val->user_id ? $val->user->name:'-' }}</td>
                                        <td>{!! $val->status_label !!}</td>
                                        <!-- FORMAT TANGGAL KETIKA KATEGORI DIINPUT SESUAI FORMAT INDONESIA -->
                                        <td>{{ $val->created_at->format('d-m-Y') }}</td>
                                        <td>

                                            <!-- FORM ACTION UNTUK METHOD DELETE -->
                                            <form action="{{ route('category.destroy', $val->id) }}" method="post">
                                                <!-- KONVERSI DARI @ CSRF & @ METHOD AKAN DIJELASKAN DIBAWAH -->
                                                @csrf
                                                @method('DELETE')
                                                <a href="{{ route('category.edit', $val->id) }}" class="btn btn-warning btn-sm">Edit</a>
                                                <button class="btn btn-danger btn-sm">Hapus</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <!-- JIKA DATA CATEGORY KOSONG, MAKA AKAN DIRENDER KOLOM DIBAWAH INI  -->
                                    @empty
                                    <tr>
                                        <td colspan="5" class="text-center">Tidak ada data</td>
                                    </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                        <!-- FUNGSI INI AKAN SECARA OTOMATIS MEN-GENERATE TOMBOL PAGINATION  -->
                        {!! $category->links() !!}
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="ibox-content">
                    <div class="card-header">
                        <h4 class="card-title">Tambah Unit dan Kategori</h4>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('categoryunit.add') }}" method="post">
                            @csrf
                            <div class="form-group">
                                <label for="status">Status</label>
                                <select name="status" class="form-control" required>
                                    <option value="1"
                                        {{ old('status') == '1' ? 'selected':'' }}>
                                        Publish</option>
                                    <option value="0"
                                        {{ old('status') == '0' ? 'selected':'' }}>
                                        Draft</option>
                                </select>
                                <p class="text-danger">{{ $errors->first('status') }}</p>
                            </div>
                            <div class="form-group">
                                <label for="name">Kategori</label>
                                <input type="text" name="name" class="form-control" required>
                                <p class="text-danger">{{ $errors->first('name') }}</p>
                            </div>
                            <div class="form-group">
                                <label for="parent_id">Unit</label>
                                  <!-- VARIABLE $PARENT PADA METHOD INDEX KITA GUNAKAN DISINI -->
                                <!-- UNTUK MENAMPILKAN DATA CATEGORY YANG PARENT_ID NYA NULL -->
                                <!-- UNTUK DIPILIH SEBAGAI PARENT TAPI SIFATNYA OPTIONAL -->
                                <select name="user_id" class="form-control">
                                    @foreach ($unit as $row)
                                    <option value="{{ $row->id }}">{{ $row->name }}</option>
                                    @endforeach
                                </select>
                                <p class="text-danger">{{ $errors->first('user_id') }}</p>
                            </div>
                            <div class="form-group">
                                <button class="btn btn-primary btn-sm">Tambah</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
        </div>


        <div class="row">


        </div>
    </div>
</main>
@endsection