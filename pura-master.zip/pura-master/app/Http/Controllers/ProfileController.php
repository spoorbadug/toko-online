<?php

namespace App\Http\Controllers;
use App\User;
use App\City;
use App\Province;
use App\Profile;
use App\Http\Requests\UpdateProfileRequest;
use Illuminate\Http\Request;
use Kavist\RajaOngkir\Facades\RajaOngkir;
use Illuminate\Support\Facades\Auth;
use Alert;
use App\SyaratKetentuan;

class ProfileController extends Controller
{

    public function __construct()
    {
        $this->middleware(['auth','verified']);
    }
    // public function edit($user){

    //     $provinces = Province::orderBy('name', 'DESC')->get();
    //     $cities = City::orderBy('name', 'DESC')->get();
    //     // $this->authorize('update',$user->profile);
    //     $user = User::find($user);

    //     return view('profiles.edit', compact('user', 'provinces', 'cities'));
    // }

    public function edit(Request $request)
    {
        // $provinces = Province::orderBy('name', 'DESC')->get();
        $provinces = Province::orderBy('name', 'ASC')->get();
        $cities = City::orderBy('name', 'ASC')->get();
        $profiles = Profile::where('user_id', $request->user()->id)->get();
        $skcustomer = SyaratKetentuan::where('role', 'Customer')->get();
        //$user = User::with(['profile'])->where('id', $request->user()->id)->get();
        //dd($profiles);
        //dd($request->user());
        
        return view('profiles.edit', [
            'user' => $request->user(),
            'profiles'=> $profiles,
            'provinces' => $provinces,
            'cities' => $cities,
            'skcustomer' => $skcustomer
        ]);
    }

    

    public function getCities($id)
    {
        $city = City::where('province_id', $id)->pluck('name', 'city_id');
        return response()->json($city);
    }

    public function update(Request $id)
    {
        
    }
        
    public function store(Request $request)
    {
        

        $profil=Profile::where('user_id', $request->user()->id);
        $profil->create([
            'user_id' => $request->user()->id,
            'name_address' => $request->name_address,
            'name' => $request->name,
            'phonenumber' => $request->phonenumber,
            'city_id' => $request->city_id,
            'province_id' => $request->province_id,
            'address' => $request->address,
            'postal_code' => $request->postal_code,
        ]);

        Alert::success('Berhasil', 'Profil berhasil ditambah');
        return redirect()->route('profile.edit');
    }
    

}