@extends('layouts.admin')

@section('title')
<title>Komplain</title>
@endsection

@section('menuside')
<li>
    <a href="{{ route('unit.index') }}"><i class="fa fa-th-large"></i>
        <span class="nav-label">Dashboard</span></a>
</li>
<li>
    <a href="{{ route('categoryunit.index') }}"><i class="fa fa-industry"></i>
        <span class="nav-label">Category</span></a>
</li>
<li>
    <a href="#"><i class="fa fa-archive"></i><span class="fa arrow"></span>
        <span class="nav-label">Product</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('productunit.index') }}">List Produk</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('productunit.create') }}">Tambah Produk</a></li>
    </ul>
</li>
<li class="active">
    <a href="{{ route('unit.order') }}"><i class="fa fa-cart-plus"></i>
        <span class="nav-label">Order</span></a>
</li>
<li>
    <a href="{{ route('unit.edit') }}"><i class="fa fa-address-card"></i>
        <span class="nav-label">Profile</span></a>
</li>
@endsection

@section('content')
<main class="main">
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>Daftar Komplain</h2>
            <ol class="breadcrumb">
                <li>Home
                </li>
                <li class="active">
                    <strong>Order</strong>
                </li>
            </ol>
        </div>
        <div class="col-lg-2"></div>
    </div>
    <div class="container-fluid">
        <div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox">
                        <div class="ibox-content">
                            <form action="{{ route('unit.order') }}" method="get">
                                <div class="input-group mb-10 col-md-12 float-right">
                                    <input type="text" class="form-control" placeholder="Cari..."
                                        value="{{ request()->q }}">
                                    <span class="input-group-btn"> <button  class="btn btn-default">Cari
                                        </button></span>
                                </div>
                            </form>
                            <table class="table table-hover table-bordered">
                                <thead>
                                    <tr>
                                        <th>InvoiceID</th>
                                        <th>Produk</th>
                                        <th>Jumlah</th>
                                        <th>Tanggal</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($komplains as $row)
                                        <tr>
                                            <td>{{ $row->order->invoice }}</td>
                                            <td>{{ $row->product->name }}</td>
                                            <td>{{ $row->jumlah }}</td>
                                            <td>{{ $row->created_at->format('d-m-Y') }}</td>
                                            <td class="text-left">
                                                <div class="btn-group">
                                                    <form
                                                        action="{{ route('unit.destroyorder', $row->id) }}"
                                                        method="post">
                                                        @csrf
                                                        @method('DELETE')
                                                        <a href="{{ route('unit.showorder', $row->id) }}"
                                                            class="btn btn-info btn-sm">Lihat</a>
                                                        <a href="{{ route('unit.editorder', $row->id) }}"
                                                            class="btn btn-warning btn-sm">Edit</a>
                                                        <button class="btn btn-danger btn-sm">Hapus</button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="6" class="text-center">Tidak ada data</td>
                                        </tr>
                                    @endforelse

                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="7">
                                            <ul class="pagination pull-right"></ul>
                                            {!! $komplains->links() !!}
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

@endsection
