@extends('layouts.app')

@section('title')
<title>Profil</title>
@endsection

@section('content')
<!-- Main Container  -->
<div class="main-container container">
    <ul class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i></a></li>
        <li><a href="#">Akun</a></li>
        <li><a href="#">Edit Profil</a></li>
    </ul>

    <div class="row">
        <!--Middle Part Start-->
        <div class="col-sm-12" id="content">

            <div class="row">
                <div class="col-sm-12">
                    <!--Tabs Part Start-->

                    <h2 class="title">Akun</h2>
                    <p class="lead">Hello, <strong>{{ $user->name }}</strong> - To update your account
                        information.</p>
                    <ul class="nav nav-tabs">
                        <li class="active"><a data-toggle="tab" href="#tab-1">Informasi Akun</a>
                        </li>
                        <li><a data-toggle="tab" href="#tab-2">Daftar Alamat</a>
                        </li>
                        <li><a data-toggle="tab" href="#tab-3">Syarat & Ketentuan</a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="tab-1">
                            <form method="POST" action="" enctype="multipart/form-data">
                                @csrf
                                @method('PATCH')
                                <fieldset id="personal-details">
                                    <legend>Informasi Akun</legend>
                                    <div class="form-group required">
                                        <label for="name" class="control-label">Nama Lengkap</label>
                                        <input type="text" class="form-control" id="name" placeholder="Name"
                                            value="{{ old('name') ?? $user->name }}"
                                            name="name">
                                    </div>
                                    <div class="form-group required">
                                        <label for="email" class="control-label">Email</label>
                                        <input type="email" class="form-control" id="email" placeholder="E-Mail"
                                            value="{{ $user->email }}" name="email">
                                    </div>

                                    <div class="buttons clearfix">
                                        <div class="pull-right">
                                            <button type="submit" class="btn button-primary w-100">Simpan</button>
                                        </div>
                                    </div>
                                </fieldset>
                            </form>
                        </div>

                        <div class="tab-pane" id="tab-2">
                            <fieldset>
                                <form method="POST" action="{{ route('profile.store') }}"
                                    enctype="multipart/form-data">
                                    @csrf
                                    <div class="col-sm-6">
                                        <legend>Daftar Alamat</legend>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="pull-right">
                                            <button type="button" id="tombol" class="btn btn-primary">Tambah
                                                Alamat</button>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 box" style="display:none">
                                        <div class="col-sm-4">
                                            <div class="form-group required">
                                                <label for="name_address">Nama Alamat</label>
                                                <input type="text" class="form-control" id="name_address"
                                                    name="name_address"
                                                    value="{{ old('name_address') }}" required>
                                            </div>
                                            <div class="form-group required">
                                                <label for="name">Nama Penerima</label>
                                                <input type="text" class="form-control" id="name" name="name"
                                                    value="{{ old('name') }}" required>
                                            </div>


                                        </div>
                                        <div class="col-sm-4">
                                            <div class="form-group required">
                                                <label for="province">Provinsi</label>
                                                <select class="form-control" id="province_id" name="province_id">
                                                    <option value="">--- Plih Provinsi ---</option>
                                                    @foreach($provinces as $row)
                                                        <option value="{{ $row->province_id }}">{{ $row->name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="form-group required">
                                                <label for="city">Kota / Kabupaten</label>
                                                <select class="form-control kota-tujuan" id="city_id" name="city_id">
                                                    <option value="">--- Pilih Kota ---</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="form-group required">
                                                <label for="postal_code">Kode Pos</label>
                                                <input type="text" class="form-control" id="postal_code"
                                                    name="postal_code"
                                                    value="{{ old('postal_code') }}" required>
                                            </div>
                                            <div class="form-group required">
                                                <label for="phonenumber">No. Telepon</label>
                                                <input type="tel" class="form-control" id="phonenumber"
                                                    placeholder="+62" value="{{ old('phonenumber') }}"
                                                    name="phonenumber" placeholder="+62">
                                            </div>
                                        </div>
                                        <div class="col-sm-12">
                                            <div class="form-group required">
                                                <label for="address">Alamat Lengkap</label>
                                                <input type="text" class="form-control" id="address" name="address"
                                                    value="{{ old('address') }}" required>
                                            </div>
                                        </div>
                                        <div class="buttons clearfix">
                                            <div class="pull-right">
                                                <button type="submit" class="btn btn-success w-100">Tambah</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>

                                <div class="divider"></div>

                                <div class="col-sm-12">
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Nama Alamat</th>
                                                    <th>Nama Penerima</th>
                                                    <th>No. Telp</th>
                                                    <th>Alamat</th>
                                                    <th>Kota</th>
                                                    <th>Provinsi</th>
                                                    <th>Kode Pos</th>
                                                    <th>Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @forelse($profiles as $no => $item)
                                                <?php
                                                            $city = \App\City::where('city_id', $item->city_id)->first();
                                                            $province = \App\Province::where('province_id', $item->province_id)->first();
                                                            ?>
                                                    <tr>
                                                        <th scope="row">{{ ++$no }}</th>
                                                        <td>{{ $item->name_address }}</td>
                                                        <td>{{ $item->name }}</td>
                                                        <td>{{ $item->phonenumber }}</td>
                                                        <td>{{ $item->address }}</td>
                                                        <td>{{ $city['name'] }}</td>
                                                        <td>{{ $province['name'] }}</td>
                                                        <td>{{ $item->postal_code }}</td>
                                                        <td>
                                                            {{-- <form action="{{ route('product.destroy', $row->id) }}"
                                                            method="post">
                                                            @csrf
                                                            @method('DELETE')
                                                            <a href="{{ route('product.edit', $row->id) }}"
                                                                class="btn btn-warning btn-sm">Edit</a>
                                                            <button class="btn btn-danger btn-sm">Hapus</button>
                                                            </form> --}}
                                                        </td>
                                                    </tr>
                                                @empty
                                                    <tr>
                                                        <td colspan="9" class="text-center">Tidak ada alamat</td>
                                                    </tr>
                                                @endforelse

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </fieldset>
                        </div>
                        <div class="tab-pane" id="tab-3">
                            @forelse ($skcustomer as $item)
                            {!! $item->s_k !!}
                        @empty
                        <p class="text-center">Syarat & Ketentuan belum dibuat.</p>
                        @endforelse
                        </div>
                    </div>
                </div>
                

            </div>

        </div>
        <!--Tabs Part End-->

        {{-- <div class="col-sm-6">
                        <fieldset>
                            <legend>Change Password</legend>
                            <div class="form-group required">
                                <label for="input-password" class="control-label">Old Password</label>
                                <input type="password" class="form-control"  placeholder="Old Password" value="" name="old-password">
                            </div>
                            <div class="form-group required">
                                <label for="input-password" class="control-label">New Password</label>
                                <input type="password" class="form-control"  placeholder="New Password" value="" name="new-password">
                            </div>
                            <div class="form-group required">
                                <label for="input-confirm" class="control-label">New Password Confirm</label>
                                <input type="password" class="form-control" id="input-confirm" placeholder="New Password Confirm" value="" name="new-confirm">
                            </div>
                        </fieldset>
                    </div> --}}
    </div>
</div>
</div>
<!--Middle Part End-->
</div>
<!-- //Main Container -->
@endsection

@section('js')
<script>
    $(document).ready(function () {
        //ajax select kota asal
        $('select[id="province_id"]').on('change', function () {
            let provindeId = $(this).val();
            if (provindeId) {
                jQuery.ajax({
                    url: '/cities/' + provindeId,
                    type: "GET",
                    dataType: "json",
                    success: function (response) {
                        $('select[id="city_id"]').empty();
                        $('select[id="city_id"]').append(
                            '<option value="">-- Pilih Kota --</option>');
                        $.each(response, function (key, value) {
                            $('select[id="city_id"]').append('<option value="' +
                                key +
                                '">' + value + '</option>');
                        });
                    },
                });
            } else {
                $('select[id="city_id"]').append('<option value="">-- Pilih Kota --</option>');
            }
        });

    });

</script>
<script>
    $(document).ready(function () {
        $('#tombol').click(function () {
            $('.box').slideToggle();
        });
    });

</script>
@endsection
