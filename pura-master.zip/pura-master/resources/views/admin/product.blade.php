@extends('layouts.admin')

@section('title')
<title>Product</title>
@endsection

@section('menuside')
<li>
    <a href="{{ route('admin.index') }}"><i class="fa fa-th-large"></i>
        <span class="nav-label">Dashboard</span></a>
</li>
<li>
    <a href="#"><i class="fa fa-user"></i><span class="fa arrow"></span>
        <span class="nav-label">Kelola User</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('admin.user') }}">Customer</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('admin.admin') }}">Admin</a></li>
    </ul>
</li>
<li class="active">
    <a href="#"><i class="fa fa-archive"></i><span class="fa arrow"></span>
        <span class="nav-label">Product</span></a>
    <ul class="nav nav-second-level collapse">
        <li class="active"><a href="{{ route('product.index') }}">List Produk</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('product.create') }}">Tambah Produk</a></li>
    </ul>
</li>
<li>
    <a href="{{ route('category.index') }}"><i class="fa fa-industry"></i> <span
            class="nav-label">Category</span></a>
</li>
<li>
    <a href="{{ route('admin.order') }}"><i class="fa fa-cart-plus"></i> <span
            class="nav-label">Order</span></a>
</li>
<li>
    <a href="{{ route('admin.indexbank') }}"><i class="fa fa-credit-card"></i> <span
            class="nav-label">Rekening Bank</span></a>
</li>
<li>
    <a href="{{ route('admin.edit') }}"><i class="fa fa-address-card"></i>
        <span class="nav-label">Profile</span></a>
</li>
<li>
    <a href=""><i class="fa fa-navicon"></i><span class="fa arrow"></span>
        <span class="nav-label">Syarat & Ketentuan</span></a>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.sk') }}">List SK</a></li>
        </ul>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.formsk') }}">Tambah SK</a></li>
        </ul>
</li>
@endsection

@section('content')
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Produk</h2>
        <ol class="breadcrumb">
            <li>
                Home
            </li>
            <li>Produk
            </li>
            <li class="active">
                <strong>List Produk</strong>
            </li>
        </ol>
    </div>
</div>
<div class="container-fluid">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-md-12">
                <div class="ibox-content">

                    <!-- BUAT FORM UNTUK PENCARIAN, METHODNYA ADALAH GET -->
                    <form action="{{ route('product.index') }}" method="get">
                        <div class="input-group">
                            <!-- KEMUDIAN NAME-NYA ADALAH Q YANG AKAN MENAMPUNG DATA PENCARIAN -->
                            <input type="text" class="form-control" placeholder="Cari..." value="{{ request()->q }}">
                            <span class="input-group-btn"> <button type="button" class="btn btn-default">Cari
                                </button></span>
                        </div>
                    </form>

                    <div class="card-body">
                        <!-- TABLE UNTUK MENAMPILKAN DATA PRODUK -->
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Produk</th>
                                        <th>Harga</th>
                                        <th>Created At</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($products as $row)
                                        <tr>
                                            <td>
                                                {{-- <div class="ibox-content">
                                                    <div class="carousel slide" id="carousel1">
                                                        <div class="carousel-inner">
@foreach(explode('|', $row->image) as $img)
                                                            <div class="item active">
                                                                <img src="{{ asset('/products/'.$img) }}"
                                                width="100px" height="100px" alt="{{ $img }}">
                        </div>
                        @endforeach

                    </div>
                    <a data-slide="prev" href="#carousel1" class="left carousel-control">
                        <span class="icon-prev"></span>
                    </a>
                    <a data-slide="next" href="#carousel1" class="right carousel-control">
                        <span class="icon-next"></span>
                    </a>
                </div>
            </div> --}}


            {{-- @foreach(explode('|', $row->image) as $img)
                <img src="{{ asset('/products/'.$img) }}" width="100px" height="100px"
                    alt="{{ $row->image }}">
            @endforeach --}}

            <img src="{{ asset('storage/products/'.$row->image) }}" width="100px" height="100px" alt="{{ $row->image }}">
            </td>
            <td>
                <strong>{{ $row->name }}</strong><br>
                <!-- ADAPUN NAMA KATEGORINYA DIAMBIL DARI HASIL RELASI PRODUK DAN KATEGORI -->
                <label>Kategori: <span class="badge badge-info">{{ $row->category->name }}</span></label><br>
                <label>Berat: <span class="badge badge-info">{{ $row->weight }} gr</span></label><br>
                <label>Stok: <span class="badge badge-info">{{ $row->stok }}</span></label>
            </td>
            <td>Rp {{ number_format($row->price) }}</td>
            <td>{{ $row->created_at->format('d-m-Y') }}</td>

            <!-- KARENA BERISI HTML MAKA KITA GUNAKAN { !! UNTUK MENCETAK DATA -->
            <td>{!! $row->status_label !!}</td>
            <td>
                <!-- FORM UNTUK MENGHAPUS DATA PRODUK -->
                <form action="{{ route('product.destroy', $row->id) }}" method="post">
                    @csrf
                    @method('DELETE')
                    <a href="{{ route('product.edit', $row->id) }}"
                        class="btn btn-warning">Edit</a>
                    <button class="btn btn-danger">Hapus</button>
                </form>
            </td>
            </tr>
        @empty
            <tr>
                <td colspan="6" class="text-center">Tidak ada data</td>
            </tr>
            @endforelse
            </tbody>
            </table>
        </div>
        <!-- MEMBUAT LINK PAGINASI JIKA ADA -->
        {!! $products->links() !!}
    </div>
</div>
</div>
</div>
</div>
</div>
@endsection
