<?php

namespace App\Http\Controllers;

use App\Faq;
use App\SyaratKetentuan;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    // public function __construct()
    // {
    //     $this->middleware(['auth','verified']);
    // }

    public function index()
    {
        //$products = Product::where('status', '1')->take(4)->get();
        return view('home.index');
    }
    public function aboutus()
    {
        return view('home.company');
    }
    public function contactus()
    {
        return view('home.contact');
    }
    public function faq()
    {
        $faq = Faq::orderBy('created_at', 'DESC')->get();

        return view('home.faq', compact('faq'));
    }
    public function sk()
    {
        $sk = SyaratKetentuan::where('role', 'Customer')->orderBy('created_at', 'DESC')->get();

        return view('home.sk', compact('sk'));
    }
}