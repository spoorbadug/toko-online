<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateKomplainOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('komplain_orders', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('komplain_id');
            $table->unsignedBigInteger('product_id');
            $table->unsignedBigInteger('status_id');
             //INI SAMA DENGAN CUSTOMER, INFORMASI HARGA SAAT BARANG INI DIPESAN JUGA DIBUAT SALINNANNYA
            $table->bigInteger('qty');
            $table->bigInteger('weight');
            $table->bigInteger('ongkir');
            $table->bigInteger('total');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('komplain_orders');
    }
}
