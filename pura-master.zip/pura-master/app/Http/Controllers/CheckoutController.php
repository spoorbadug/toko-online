<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\City;
use App\Province;
use Kavist\RajaOngkir\Facades\RajaOngkir;
use Illuminate\Support\Str;
use Session;
use Auth;
use App\Cart;
use App\DaftarBank;
use App\Order;
use App\OrderDetail;
use App\Product;
use App\Profile;
use App\User;
use DB;

class CheckoutController extends Controller
{

    public function __construct()
    {
        $this->middleware(['auth','verified']);
    }

    private function getCarts()
    {
        $carts = json_decode(request()->cookie('pura-carts'), true);
        $carts = $carts != '' ? $carts:[];
        return $carts;
    }

    public function listCart()
    {
        $carts = $this->getCarts();
        $subtotal = collect($carts)->sum(function($q) {
            return $q['qty'] * $q['product_price'];
        });

        $provinces = Province::orderBy('created_at', 'DESC')->get();
        $cities = City::orderBy('created_at', 'DESC')->get();

        return view('checkout.checkout', compact('carts', 'subtotal','provinces','cities'));
    }


    public function index()
    {

        $province = Province::where('province_id', Auth::user()->province_id)->first();
        $city = City::where('city_id', Auth::user()->city_id)->first();

        $provinces = Province::orderBy('name', 'ASC')->get();
        $cities = City::orderBy('name', 'ASC')->get();

        $banks = DaftarBank::orderBy('nama_bank', 'ASC')->get();

        $carts = $this->getCarts();
            //dd($carts);

        $subtotal = collect($carts)->sum(function($q) {
            return $q['qty'] * $q['product_price'];
        });

        $weight = collect($carts)->sum(function($q) {
            return $q['qty'] * $q['product_weight'];
        });

        

        $login = Auth::user()->id;
        
        $user = User::where('id', $login)->first();
        $profile = Profile::where('user_id', $user->id)->get();

        $carts = json_decode(request()->cookie('pura-carts'), true);
        
        
            $ongkir = 0;
            $totalBelanja = 0;
            return view('checkout.checkout', compact('weight','banks','carts', 'subtotal', 'user', 'provinces', 'cities', 'province', 'city',  'ongkir', 'totalBelanja', 'profile'));
        


        // return response()->json($cost);

            // $ongkir = $data[0]['costs'][1]['cost'][0]['value'];
            // $ongkir = 0;
            // $totalBelanja = $subtotal + $ongkir;
        

        //$ongkir = array('service' => "Paket Kilat Khusus");
        //dd($ongkir);
       
        
        

        //dd($ongkir);
       // return view('checkout.checkout', compact('weight','banks','carts', 'subtotal', 'user', 'provinces', 'cities', 'province', 'city',  'ongkir', 'totalBelanja'));
    }

    public function profil($id)
    {
        $profile = Profile::where('id', $id)->pluck('city_id');


        return $profile;
    }

    public function cektotal($ongkir)
    {
        $carts = $this->getCarts();
            //HITUNG SUBTOTAL BELANJAAN
        $subtotal = collect($carts)->sum(function($q) {
                return $q['qty'] * $q['product_price'];
        });

        $total = $subtotal + $ongkir;

        return $total;
    }

    public function stok()
    {
        $carts = $this->getCarts();

        foreach ($carts as $row) {
            $product = Product::find($row['product_id']);
            $stok = $product->stok - $row['qty'];
                    
            Product::update([
                'stok' => $stok
            ]);
        }
                    
        return $stok;
    }


    public function cekongkir(Request $request)
    {
        
        $carts = $this->getCarts();
            //HITUNG SUBTOTAL BELANJAAN
        $subtotal = collect($carts)->sum(function($q) {
                return $q['qty'] * $q['product_price'];
        });

        $weight = collect($carts)->sum(function($q) {
            return $q['qty'] * $q['product_weight'];
        });
    
        //dd($request);
        
        if($request->kurir == 'jne') {
            $cek = RajaOngkir::ongkosKirim([
                'origin' 		=> 209, // id kota asal
                'destination' 	=> $request->alamat, // id kota tujuan
                'weight' 		=> $weight, // berat satuan gram
                'courier' 		=> 'jne', // kode kurir pengantar ( jne / tiki / pos )
            ])->get();

            $ongkir = $cek[0]['costs'][1]['cost'][0]['value'];
            return response()->json($ongkir);

        } elseif ($request->kurir == 'pos') {
            $cek = RajaOngkir::ongkosKirim([
                'origin' 		=> 209, // id kota asal
                'destination' 	=> $request->alamat, // id kota tujuan
                'weight' 		=> $weight, // berat satuan gram
                'courier' 		=> 'pos', // kode kurir pengantar ( jne / tiki / pos )
            ])->get();

            $ongkir = $cek[0]['costs'][0]['cost'][0]['value'];
            return response()->json($ongkir);

        } elseif ($request->kurir == 'tiki') {
            $cek = RajaOngkir::ongkosKirim([
                'origin' 		=> 209, // id kota asal
                'destination' 	=> $request->alamat, // id kota tujuan
                'weight' 		=> $weight, // berat satuan gram
                'courier' 		=> 'pos', // kode kurir pengantar ( jne / tiki / pos )
            ])->get();

            $ongkir = $cek[0]['costs'][1]['cost'][0]['value'];
            return response()->json($ongkir);
        }

        
    }

    public function processCheckout(Request $request)
    {

        
        //VALIDASI DATANYA
        // $this->validate($request, [
        //     'name' => 'required|string|max:100',
        //     'phonenumber' => 'required',
        //     'email' => 'required|email',
        //     'address' => 'required|string',
        //     'province_id' => 'required|exists:provinces,province_id',
        //     'city_id' => 'required|exists:cities,city_id'
        // ]);

       
    
        $login = Auth::user()->id;
        $user = User::where('id', $login)->first();
        $profile = Profile::where('city_id', $request->alamat)->first();
        
        //INISIASI DATABASE TRANSACTION
        //DATABASE TRANSACTION BERFUNGSI UNTUK MEMASTIKAN SEMUA PROSES SUKSES UNTUK KEMUDIAN DI COMMIT AGAR DATA BENAR BENAR DISIMPAN, JIKA TERJADI ERROR MAKA KITA ROLLBACK AGAR DATANYA SELARAS
        DB::beginTransaction();
        try {
            
            //AMBIL DATA KERANJANG
            $carts = $this->getCarts();
            //HITUNG SUBTOTAL BELANJAAN
            $subtotal = collect($carts)->sum(function($q) {
                return $q['qty'] * $q['product_price'];
            });

            $weight = collect($carts)->sum(function($q) {
                return $q['qty'] * $q['product_weight'];
            });
    
            if($request->kurir == 'jne') {
                $data = RajaOngkir::ongkosKirim([
                    'origin' 		=> 209, // id kota asal
                    'destination' 	=> $request->alamat, // id kota tujuan
                    'weight' 		=> $weight, // berat satuan gram
                    'courier' 		=> 'jne', // kode kurir pengantar ( jne / tiki / pos )
                ])->get();
    
                $ongkir = $data[0]['costs'][1]['cost'][0]['value'];
            } elseif ($request->kurir == 'pos') {
                $data = RajaOngkir::ongkosKirim([
                    'origin' 		=> 209, // id kota asal
                    'destination' 	=> $request->alamat, // id kota tujuan
                    'weight' 		=> $weight, // berat satuan gram
                    'courier' 		=> 'pos', // kode kurir pengantar ( jne / tiki / pos )
                ])->get();
    
                $ongkir = $data[0]['costs'][0]['cost'][0]['value'];
            } elseif ($kurir == 'tiki') {
                $data = RajaOngkir::ongkosKirim([
                    'origin' 		=> 209, // id kota asal
                    'destination' 	=> $request->alamat, // id kota tujuan
                    'weight' 		=> $weight, // berat satuan gram
                    'courier' 		=> 'tiki', // kode kurir pengantar ( jne / tiki / pos )
                ])->get();
    
                $ongkir = $data[0]['costs'][1]['cost'][0]['value'];
            }
            
            $total = $subtotal + $ongkir;
            
            $status=1;
            //dd($request);
            //SIMPAN DATA ORDER
            //dd($request->catatan);
            $order = Order::create([
                'invoice' => Str::random(4) . '-' . time(), //INVOICENYA KITA BUAT DARI STRING RANDOM DAN WAKTU
                'user_id' => $user->id,
                'profile_id' => $profile->id,
                'status_id' => $status,
                'bank_id' => $request->bank_id,
                'kurir' => $request->kurir,
                'total' => $total,
                'catatan' => $request->catatan
            ]);
                
            
            // LOOPING DATA DI CARTS
            foreach ($carts as $row) {
                //AMBIL DATA PRODUK BERDASARKAN PRODUCT_ID
                $product = Product::find($row['product_id']);
                //dd($product);
                //$stok = $product->stok - $row['qty'];
                Product::where('id', $product->id)->decrement('stok', $row['qty']);
                //SIMPAN DETAIL ORDER
                OrderDetail::create([
                    'order_id' => $order->id,
                    'product_id' => $row['product_id'],
                    'category_id' => $product->category_id,
                    'qty' => $row['qty'],
                    'price' => $row['product_price'] * $row['qty'],
                    'weight' => $row['product_weight'] * $row['qty'],
                    'subtotal' => $subtotal,
                    'ongkir' => $ongkir
                ]);
            }
            
            //TIDAK TERJADI ERROR, MAKA COMMIT DATANYA UNTUK MENINFORMASIKAN BAHWA DATA SUDAH FIX UNTUK DISIMPAN
            DB::commit();

            $carts = [];
            //KOSONGKAN DATA KERANJANG DI COOKIE
            $cookie = cookie('pura-carts', json_encode($carts), 2880);
            //REDIRECT KE HALAMAN FINISH TRANSAKSI
            return redirect(route('finish_checkout', $order->invoice))->cookie($cookie);
        } catch (\Exception $e) {
            //JIKA TERJADI ERROR, MAKA ROLLBACK DATANYA
            DB::rollback();
            //DAN KEMBALI KE FORM TRANSAKSI SERTA MENAMPILKAN ERROR
            return redirect()->back()->with(['error' => $e->getMessage()]);
        }
    }

    public function checkoutFinish($invoice)
    {
        //AMBIL DATA PESANAN BERDASARKAN INVOICE
        //$cities = City::orderBy('name', 'DESC')->first();
        $order = Order::with(['profile', 'bank'])->where('invoice', $invoice)->first();
        //LOAD VIEW checkout_finish.blade.php DAN PASSING DATA ORDER
        return view('checkout.checkout_finish', compact('order'));
    }
}