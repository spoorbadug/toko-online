<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    protected $fillable = [
        'order_id', 'nama', 'bank_id', 'bukti_bayar',
    ];

    public function order()
    {
        return $this->belongsTo(Order::class);
    }
    
}
