<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProfilesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('profiles', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->text('name_address')->nullable();
            $table->text('name')->nullable();
            $table->bigInteger('phonenumber')->nullable();
            $table->unsignedBigInteger('city_id')->nullable(); //FIELD INI AKAN MERUJUK KE TABLE districts
            $table->unsignedBigInteger('province_id')->nullable();
            $table->text('address')->nullable();
            $table->bigInteger('postal_code')->nullable();
            $table->timestamps();

            $table->index('user_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('profiles');
    }
}