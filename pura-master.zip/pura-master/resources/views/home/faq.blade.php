@extends('layouts.app')

@section('title')
<title>FAQ</title>
@endsection

@section('content')
    <!-- Main Container  -->
	<div class="main-container container">
		<ul class="breadcrumb">
			<li><a href="#"><i class="fa fa-home"></i></a></li>
			<li><a href="#">FAQ</a></li>
		</ul>
		
		<div class="row">
			<div id="content" class="col-sm-12">
				<h3>Punya Pertanyaan? Kami Punya Jawaban!</h3>
				<p>Pertanyaan anda tidak tersedia? Hubungi kami melalui formulir di bawah</a></p>
				<p>
					<br>
				</p>
				<div class="row">
					<div class="col-sm-12">
						<ul class="yt-accordion">
							@forelse ($faq as $row)
							<li class="accordion-group">
								<h3 class="accordion-heading"><i class="fa fa-plus-square"></i><span>{{ $row->pertanyaan }}</span></h3>
								<div class="accordion-inner">
									<p>{!! $row->jawaban !!}</p>
									
								</div>
							</li>
							@empty
								
							@endforelse
							
						</ul>
					</div>
				</div>
			
				
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12 contact-form">
				<form action="" method="post" enctype="multipart/form-data" class="form-horizontal">
					<fieldset>
						<h2>Formulir Pertanyaan</h2>
						<div class="form-group required">
							<div class="col-sm-12">
								<label class="control-label" for="input-enquiry">Pertanyaan</label>
								<textarea name="enquiry" rows="5" id="input-enquiry"
									class="form-control"></textarea>
							</div>
						</div>
					</fieldset>
					<div class="buttons">
						<div class="pull-right">
							<button class="btn btn-default buttonGray" type="submit">
								<span>Submit</span>
							</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- //Main Container -->
@endsection