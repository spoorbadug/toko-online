@extends('layouts.app')

@section('title')
<title>Produk Pura</title>
@endsection

@section('content')
<body class="res layout-1 listing-page">
    <div id="wrapper" class="wrapper-fluid banners-effect-5">
        <!-- Main Container  -->
        <div class="main-container container">
            <ul class="breadcrumb">
                <li><a href="#"><i class="fa fa-home"></i></a></li>
                <li><a href="#">Produk</a></li>
            </ul>
            <div class="row">
                <!--Left Part Start -->
                <aside class="col-sm-4 col-md-3 content-aside" id="column-left">
                    <div class="module category-style">
                        <h3 class="modtitle">Kategori</h3>
                        <div class="modcontent">
                            <div class="box-category">
                                <ul id="cat_accordion" class="list-group">
                                    
                                    {{-- <li class="hadchild"><a href="category.html" class="cutom-parent">Smartphone & Tablets</a>   <span class="button-view  fa fa-plus-square-o"></span>
                                        <ul style="display: block;">
                                            <li><a href="category.html">Men's Watches</a></li>
                                            <li><a href="category.html">Women's Watches</a></li>
                                            <li><a href="category.html">Kids' Watches</a></li>
                                            <li><a href="category.html">Accessories</a></li>
                                        </ul>
                                    </li> --}}
                             
                                    @foreach($categories as $row)
                                        <li><a href="{{ url('/unit/' . $row->user->slug) }}" class="custom-parent">{{ $row->user->name }}</a>   <span class="button-view  fa fa-plus-square-o"></span>
                                            <ul>
                                                <li><a href="{{ url('/kategori/' . $row->slug) }}">{{ $row->name }}</a></li>
                                            </ul>
                                        </li>
                                    @endforeach
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="module product-simple">
                        <h3 class="modtitle">
                            <span>Product Terbaru</span>
                        </h3>
                        <div class="modcontent">
                            <div class="so-extraslider">
                                <!-- Begin extraslider-inner -->
                                <div class=" extraslider-inner">
                                    <div class="item ">
                                        @forelse($newproducts as $row)
                                            <div class="product-layout item-inner style1 ">
        
                                                <div class="item-image">
                                                    <div class="item-img-info">
                                                        <a href="{{ url('/produk/'.$row->slug) }}"
                                                            target="_self" title="{{ $row->name }}">
                                                            <img src="{{ asset('storage/products/'.$row->image) }}"
                                                                class="img-1 img-responsive" alt="{{ $row->name }}">
                                                        </a>
                                                    </div>
                                                </div>
                                                <div class="item-info">
                                                    <div class="item-title">
                                                        <a href="{{ url('/produk/'.$row->slug) }}"
                                                            target="_self" title="{{ $row->name }}">{{ $row->name }}</a>
                                                    </div>
                                                    <div class="content_price price">
                                                        <span class="price-new product-price">Rp
                                                            {{ number_format($row->price) }}</span>&nbsp;&nbsp;
                                                    </div>
                                                </div>
                                                <!-- End item-info -->
                                                <!-- End item-wrap-inner -->
                                            </div>
                                        @empty
                                        @endforelse
                                        <!-- End item-wrap -->
        
                                    </div>
                                </div>
                                <!--End extraslider-inner -->
                            </div>
                        </div>
                    </div>
                </aside>
                <!--Left Part End -->
                <!--Middle Part Start-->
                <div id="content" class="col-md-9 col-sm-8">
                    <div class="products-category">
                        <!-- Filters -->
                        <div class="product-filter product-filter-top filters-panel">
                            <div class="row">
                                <div class="col-md-5 col-sm-3 col-xs-12 view-mode">
                                    <div class="list-view">
                                        <button class="btn btn-default grid active" data-view="grid"
                                            data-toggle="tooltip" data-original-title="Grid"><i
                                                class="fa fa-th"></i></button>
                                        <button class="btn btn-default list" data-view="list" data-toggle="tooltip"
                                            data-original-title="List"><i class="fa fa-th-list"></i></button>
                                    </div>
                                </div>
                                <div class="short-by-show form-inline text-right col-md-7 col-sm-9 col-xs-12">
                                    <div class="form-group short-by">
                                        <label class="control-label" for="input-sort">Sort By:</label>
                                        <select id="input-sort" class="form-control" onchange="location = this.value;">
                                            <option value="" selected="selected">Default</option>
                                            <option value="">Name (A - Z)</option>
                                            <option value="">Name (Z - A)</option>
                                            <option value="">Price (Low &gt; High)</option>
                                            <option value="">Price (High &gt; Low)</option>
                                            <option value="">Rating (Highest)</option>
                                            <option value="">Rating (Lowest)</option>
                                            <option value="">Model (A - Z)</option>
                                            <option value="">Model (Z - A)</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label" for="input-limit">Show:</label>
                                        <select id="input-limit" class="form-control" onchange="location = this.value;">
                                            <option value="" selected="selected">15</option>
                                            <option value="">25</option>
                                            <option value="">50</option>
                                            <option value="">75</option>
                                            <option value="">100</option>
                                        </select>
                                    </div>
                                </div>
                                <!-- <div class="box-pagination col-md-3 col-sm-4 col-xs-12 text-right">
                                <ul class="pagination">
                                    <li class="active"><span>1</span></li>
                                    <li><a href="">2</a></li><li><a href="">&gt;</a></li>
                                    <li><a href="">&gt;|</a></li>
                                </ul>
                            </div> -->
                            </div>
                        </div>
                        <!-- //end Filters -->
                        <!--changed listings-->
                        <div class="products-list row nopadding-xs so-filter-gird">
                            @forelse($products as $row)
                                <div class="product-layout col-lg-3 col-md-4 col-sm-6 col-xs-12">
                                    <div class="product-item-container item--static">
                                        <div class="left-block">
                                            <div class="product-image-container second_img">
                                                <a href="{{ url('/produk/' . $row->slug) }}"
                                                    target="_self" title="{{ $row->name }}">
                                                    
                                                        <img src="{{ asset('storage/products/'.$row->image) }}"
                                                            class="img-1 img-responsive" alt="{{ $row->name }}" style="height: 200px">
                                                    
                                                </a>
                                            </div>
                                        </div>
                                        <div class="right-block">
                                            <div class="button-group cartinfo--static">
                                                <form action="{{ route('front.cart') }}" method="POST">
                                                    @csrf
                                                    <input type="hidden" name="qty" id="sst" maxlength="12" value="{{ $row->min_order }}"
                                                    title="Quantity:" class="input-text qty">
                                                    <input type="hidden" name="product_id" value="{{ $row->id }}" class="form-control">
                                                    
                                                    <button type="submit" class="main_btn" title="Add to cart">
                                                        <span>Add to cart </span>
                                                    </button>
                                                </form>
                                            </div>
                                            <h4><a href="{{ url('/produk/'.$row->slug) }}"
                                                    title="Volup tatem accu" target="_self">{{ $row->name }}</a></h4>
                                            
                                            <div class="price">
                                                <span class="price">Rp {{ number_format($row->price) }}</span>
                                            </div>
                                            <div class="description item-desc">
                                                <div class="inner-box-desc">
                                                    <div class="brand"><span>Unit : </span><a href="#">{{ $row->category->user->name }}</a></div>
                                                    <div class="brand"><span>No. Telepon : </span><a href="#">{{ $row->category->user->phonenumber }}</a></div>
                                                    <div class="weight"><span>Berat : </span><span class="status-order">{{ $row->weight }} Gram</span></div>
                                                    <div class="order"><span>Minimal Order : </span><span class="status-order">{{ $row->min_order }}</span></div>
                                                    
                                                </div>
                                            </div>
                                            <div class="list-block">
                                                <form action="{{ route('front.cart') }}" method="POST">
                                                    @csrf
                                                    <input type="hidden" name="qty" id="sst" maxlength="12" value="{{ $row->min_order }}"
                                                    title="Quantity:" class="input-text qty">
                                                    <input type="hidden" name="product_id" value="{{ $row->id }}" class="form-control">
                                                    
                                                    <button type="submit" class="main_btn" title="Add to cart">
                                                        <span>Add to cart </span>
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            @empty
                                <h3 class="text-center">Tidak ada produk</h3>
                            
                            @endforelse
                        </div>
                        <!--// End Changed listings-->
                        <!-- Filters -->
                        <div class="product-filter product-filter-bottom filters-panel">
                            <div class="row">
                                <div class="col-sm-6 text-left"></div>
                                <div class="col-sm-6 text-right">{!! $products->links() !!}</div>
                            </div>
                        </div>
                        <!-- //end Filters -->
                    </div>
                </div>
                <!--Middle Part End-->
            </div>
        </div>
        <!-- //Main Container -->
    </div>
</body>
@endsection
