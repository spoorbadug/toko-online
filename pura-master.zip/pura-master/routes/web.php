<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'HomeController@index')->name('home.index');
Route::get('/tentang-kami', 'HomeController@aboutus')->name('home.aboutus');
Route::get('/kontak-kami', 'HomeController@contactus')->name('home.contactus');
Route::get('/faq', 'HomeController@faq')->name('home.faq');
Route::get('/syarat-ketentuan', 'HomeController@sk')->name('home.sk');

// Route::get('/dashboard', 'AdminController@index')->name('admin.index')->middleware(['auth','admin']);
// Route::patch('/dashboard', 'AdminController@updatereminder')->name('admin.reminder')->middleware(['auth','admin']);



Route::prefix('admin')->middleware(['admin'])->group(function () {
    Route::get('/dashboard', 'AdminController@index')->name('admin.index');
    

    // Route::get('/order', 'OrderController@show')->name('admin.order');
    Route::get('/order', 'AdminController@order')->name('admin.order');
    Route::delete('/order/{id}/delete', 'AdminController@delete_order')->name('admin.destroyorder');
    Route::get('/order/{id}', 'AdminController@show_order')->name('admin.showorder');
    Route::get('/order/{id}/edit', 'AdminController@edit_order')->name('admin.editorder');
    Route::put('/order/{id}/update', 'AdminController@update_order')->name('admin.updateorder');

    Route::resource('category', 'CategoryController')->except(['create', 'show']);

    // Route::get('/admin-stock', 'StockController@index')->name('admin.stock');
    // Route::get('/admin-stock/show', 'StockController@show')->name('admin.stockshow');
    // Route::get('/admin-stock/remove/{id}', 'StockController@remove')->name('admin.removestock');
    // Route::get('/admin-stock/edit/{id}', 'StockController@editform')->name('admin.editform');
    // Route::patch('/admin-stock/edit/{id}', 'StockController@editstock')->name('admin.editstock');

    //faq
    Route::get('/tambah-faq', 'AdminController@formfaq')->name('admin.formfaq');
    Route::post('/tambah-faq/create', 'AdminController@tambahfaq')->name('admin.tambahfaq');
    Route::get('/daftar-faq', 'AdminController@listfaq')->name('admin.listfaq');
    Route::delete('/daftar-faq/{id}/delete', 'AdminController@hapusfaq')->name('admin.hapusfaq');

    //admin
    Route::post('/addadmin', 'AdminController@xdmin')->name('admin.add');
    Route::get('/list-user', 'AdminController@listUser')->name('admin.user');
    Route::get('/list-admin', 'AdminController@listAdmin')->name('admin.admin');
    Route::delete('/list-admin{id}', 'AdminController@hapusxdmin')->name('admin.hapus');
    Route::get('/profile','AdminController@editxdmin')->name('admin.edit');
    Route::patch('/profile','AdminController@updatexdmin')->name('admin.update');

    //product
    Route::get('/list-produk', 'ProductController@index')->name('product.index');
    Route::get('/tambah-produk', 'ProductController@create')->name('product.create');
    Route::post('/store-produk', 'ProductController@store')->name('product.store');
    Route::delete('/list-produk/{product_id}', 'ProductController@destroy')->name('product.destroy');
    Route::get('/list-produk/{product_id}/edit', 'ProductController@edit')->name('product.edit');
    Route::put('/list-produk/{product_id}', 'ProductController@update')->name('product.update');

    //bank
    Route::get('/rekening-bank', 'AdminController@indexbank')->name('admin.indexbank');
    Route::post('/rekening-bank/add', 'AdminController@storebank')->name('admin.storebank');
    Route::get('/rekening-bank/{id}/edit', 'AdminController@editbank')->name('admin.editbank');
    Route::delete('/rekening-bank/hapus/{id}', 'AdminController@destroybank')->name('admin.destroybank');

    //sk
    Route::get('/sk-user', 'AdminController@sk')->name('admin.sk');
    Route::get('/sk-user/tambah/', 'AdminController@formsk')->name('admin.formsk');
    Route::post('/sk-user/add', 'AdminController@tambahsk')->name('admin.addsk');
    Route::get('/sk-user/{id}/edit', 'AdminController@editsk')->name('admin.editsk');

    //komplain
    Route::get('/komplain','KomplainController@komplain_admin')->name('admin.komplain');
    Route::get('/komplain/{id}', 'KomplainController@show_komplain_admin')->name('admin.showkomplain');
    Route::get('/komplain/proses/{id}', 'KomplainController@proses_komplain_admin')->name('admin.proseskomplain');

});

Route::prefix('unit')->middleware(['unit'])->group(function () {
    Route::get('/dashboard', 'UsersController@dashboard')->name('unit.index');

    //product
    Route::get('/list-produk', 'UsersController@index')->name('productunit.index');
    Route::get('/tambah-produk', 'UsersController@create')->name('productunit.create');
    Route::post('/store-produk', 'UsersController@store')->name('productunit.store');
    Route::delete('/list-produk/{product_id}', 'UsersController@destroy')->name('productunit.destroy');
    Route::get('/list-produk/{product_id}/edit', 'UsersController@edit')->name('productunit.edit');
    Route::put('/list-produk/{product_id}', 'UsersController@update')->name('productunit.update');

    Route::get('/list-kategori', 'UsersController@category')->name('categoryunit.index');
    Route::post('/list-kategori-add', 'UsersController@addcategory')->name('categoryunit.add');
    Route::delete('/list-kategori/{id}', 'UsersController@delcategory')->name('categoryunit.delete');

    Route::get('/profile','UsersController@editunit')->name('unit.edit');
    Route::patch('/profile','UsersController@updateunit')->name('unit.update');

    Route::get('/order','UsersController@order')->name('unit.order');
    Route::get('/order/{id}', 'UsersController@show_order')->name('unit.showorder');
    Route::delete('/order/{id}/delete', 'UsersController@delete_order')->name('unit.destroyorder');
    Route::get('/order/{id}/edit', 'UsersController@edit_order')->name('unit.editorder');
    Route::put('/order/{id}/update', 'UsersController@update_order')->name('unit.updateorder');

    Route::get('/komplain','UsersController@komplain')->name('unit.komplain');
});

Route::prefix('keuangan')->middleware(['keuangan'])->group(function () {
    Route::get('/dashboard', 'KeuanganController@index')->name('keuangan.index');

    Route::get('/rekening-bank', 'KeuanganController@bank')->name('pay.bank');
    Route::post('/rekening-bank/add', 'KeuanganController@store')->name('pay.add');
    Route::get('/rekening-bank/{id}/edit', 'KeuanganController@edit')->name('pay.edit');

    Route::get('/order', 'KeuanganController@order')->name('keuangan.order');
    Route::delete('/order/{id}/delete', 'KeuanganController@delete_order')->name('keuangan.destroyorder');
    Route::get('/order/{id}', 'KeuanganController@show_order')->name('keuangan.showorder');
    Route::get('/order/{id}/edit', 'KeuanganController@edit_order')->name('keuangan.editorder');
    Route::put('/order/{id}/update', 'KeuanganController@update_order')->name('keuangan.updateorder');

    Route::get('/profile','KeuanganController@editprofile')->name('keuangan.edit');
    Route::patch('/profile','KeuanganController@updateprofile')->name('keuangan.update');
});

//Route::resource('product', 'ProductController')->middleware(['web']);

Route::get('/produk','ProductController@list')->name('product.list');
Route::get('/produk/filter','ProductController@filter')->name('product.filter');

Route::get('/kategori/{slug}', 'CategoryController@show')->name('category.show');
Route::get('/unit/{slug}', 'CategoryController@showunit')->name('category.showunit');
Route::get('/produk/{slug}','ProductController@show')->name('product.show');

Route::get('/cart','CartController@index')->name('cart.index');
Route::post('/cart/add/{product}','CartController@add')->name('cart.add');
Route::post('cart', 'CartController@addToCart')->name('front.cart');
Route::get('/cart', 'CartController@listCart')->name('front.list_cart');
Route::post('/cart/update', 'CartController@updateCart')->name('front.update_cart');
Route::get('/cart/remove/{id}','CartController@remove')->name('cart.remove');



Route::get('/ongkir', 'CheckOngkirController@index');
Route::post('/ongkir', 'CheckOngkirController@check_ongkir');
Route::get('/cities/{province_id}', 'CheckOngkirController@getCities');


Route::prefix('user')->middleware(['auth'])->group(function () {
    Route::post('/checkout-ongkir','CheckoutController@cekongkir')->name('checkout.ongkir');
    Route::get('/checkout-total/{ongkir}','CheckoutController@cektotal')->name('checkout.total');
    Route::get('/checkout','CheckoutController@index')->name('checkout.index');
    Route::post('/checkout-proses','CheckoutController@processCheckout')->name('checkout');
    Route::get('/checkout/{invoice}', 'CheckoutController@checkoutFinish')->name('finish_checkout');
    Route::get('/checkout-profil/{id}', 'CheckoutController@profil');

    Route::get('/order','OrderController@index')->name('order.index');
    Route::get('/order/{invoice}','OrderController@view')->name('order.detail');
    Route::get('/order/bayar/{invoice}', 'PaymentController@index')->name('order.pay');
    Route::get('/order/{invoice}/selesai', 'OrderController@ordersukses')->name('order.sukses');
    Route::post('/order/bayar/{id}/upload', 'PaymentController@buktibayar')->name('order.bayar');
    Route::get('/order/batal/{invoice}','OrderController@orderbatal')->name('order.cancel');


    Route::get('/order/{invoice}/return','KomplainController@returnorder')->name('order.return');
    Route::post('/order/return/{id}','KomplainController@store')->name('order.storekomplain');
    Route::get('/komplain/','KomplainController@listkomplain')->name('komplain.index');
    Route::get('/komplain/{id}', 'KomplainController@show_komplain')->name('komplain.show');
    Route::delete('/komplain/hapus/{id}', 'KomplainController@destroy_komplain')->name('komplain.destroy');

    Route::get('/profile','ProfileController@edit')->name('profile.edit');
    Route::patch('/profile/update','ProfileController@update')->name('profile.update');
    Route::post('/profile/create','ProfileController@store')->name('profile.store');    

});

//auth
Auth::routes(['verify' => true]);

Route::post('xdmin-login', 'AdminLoginController@login')->name('xdmin.postlogin');
Route::get('/xdmin', 'AdminLoginController@loginForm');
Route::post('xdmin-logout', 'AdminLoginController@logout')->name('xdmin.logout');