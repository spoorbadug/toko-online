<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Order;
use App\OrderStatus;
use App\User;
use App\City;
use App\Province;
use App\Profile;
use App\Payment;
use App\SyaratKetentuan;
use App\Faq;
use App\Komplain;
use App\DaftarBank;
use Alert;

class AdminController extends Controller
{
    public function index()
    {
        $totalgross = 0;

        $customer = User::with(['profile'])->where('role','Customer')->get();
        $totalCustomer = count($customer);

        $admin = User::where('role','Admin')->orwhere('role','Unit')->get();
        $totalAdmin = count($admin);

        $orders = Order::where('status_id', 3)->orderBy('created_at', 'DESC')->paginate(10);
        $totalorder = count($orders);

        $prices = Order::where('status_id', 7)->pluck('total');
        $totalPrice = count($prices);
        
        foreach($prices as $x) {
            $totalgross += $x;
        }
        
        $listorder=Order::orderBy('created_at','DESC')->paginate(10);
        
        return view('admin.index',compact('listorder','totalCustomer','totalAdmin','totalorder','totalgross','orders'));
    }

    public function order()
    {
        $orders = Order::orderBy('created_at', 'DESC');

        if (request()->q != '') {
            $orders = $orders->where(function($q) {
                $q->where('customer_name', 'LIKE', '%' . request()->q . '%')
                ->orWhere('invoice', 'LIKE', '%' . request()->q . '%')
                ->orWhere('customer_address', 'LIKE', '%' . request()->q . '%');
            });
        }

        $orders = $orders->paginate(10);
        return view('admin.order', compact('orders', 'provinces', 'cities'));
    }

    public function delete_order($id)
    {
        $order = Order::find($id);
        $order->delete();
        $detail = OrderDetail::where('order_id', $id)->first();
        $detail->delete();
        return redirect(route('admin.order'));
    }

    public function show_order($id)
    {
        $order = Order::with(['user', 'details'])->where('id', $id)->first();
        return view('admin.showorder', compact('order'));
    }

    public function edit_order($id)
    {
        $order = Order::find($id);
        $status = OrderStatus::orderBy('id', 'ASC')->get();

        return view('admin.editorder', compact('order','pay', 'status'));
    }

    public function update_order(Request $request, $id) 
    {
        $order=Order::find($id);
        $order->update([
            'status_id' => $request->status
        ]);

        return redirect(route('admin.order'))->with(['success'=> 'Data Diperbaharui']);
    }

    public function editxdmin(Request $request)
    {
        $provinces = Province::pluck('name', 'province_id');
        $cities = City::pluck('name', 'city_id');
        $skadmin = SyaratKetentuan::where('role', 'Admin')->get();
        $profiles = Profile::where('user_id', $request->user()->id)->first();
        
        return view('profiles.xdmin', [
            'user' => $request->user(),
            'provinces' => $provinces,
            'profiles'=> $profiles,
            'cities' => $cities,
            'skadmin' => $skadmin
        ]);
    }

    public function updatexdmin(Request $request)
    {
        $profil=Profile::where('user_id', $request->user()->id);
        $profil->update([
            'user_id' => $request->user()->id,
            'name_address' => $request->name_address,
            'name' => $request->name,
            'phonenumber' => $request->phonenumber,
            'city_id' => $request->city_id,
            'province_id' => $request->province_id,
            'address' => $request->address,
            'postal_code' => $request->postal_code,
        ]);
        
        alert()->success('Berhasil','Berhasil mengubah profil Admin');
        return redirect()->route('admin.edit');
    }

    public function xdmin(Request $data) 
    {
        $data->request->add(['slug' => $data->name]);
        User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'role'=> $data['role'],
            'password' => Hash::make($data['password']),
            'slug'=> $data['slug'],
        ]);

        alert()->success('Berhasil Tambah','Berhasil menambahkan Admin/Unit');
        return redirect(route('admin.admin'));
    }

    public function listAdmin()
    {
        $xdmin=DB::table('users')->where('role', 'Admin')->orwhere('role', 'Unit')->orwhere('role', 'Keuangan')->get();
        return view('admin.admin',compact('xdmin'));
    }

    public function listUser()
    {
        $customers=DB::table('users')->where('role', 'Customer')->get();
        return view('admin.user',compact('customers'));
    }

    public function hapusxdmin($id) 
    {
        $users=User::withCount(['categories'])->find($id); 

        if ($users->categories_count == 0) {
            $users->delete();
            Alert::success('Berhasil Hapus', 'Akun Telah Berhasil Dihapus');
            return redirect(route('admin.admin'));
        }

        Alert::error('Gagal Hapus', 'Akun Memiliki Kategori');
        return redirect(route('admin.admin'));
    }

    public function sk()
    {
        $skadmin = SyaratKetentuan::where('role', 'Admin')->get();
        $skunit = SyaratKetentuan::where('role', 'Unit')->get();
        $skkeuangan = SyaratKetentuan::where('role', 'Keuangan')->get();
        $skcustomer = SyaratKetentuan::where('role', 'Customer')->get();

        return view('profiles.listsk', compact('skadmin', 'skunit', 'skkeuangan', 'skcustomer'));
    }

    public function formsk()
    {
        $roles = User::orderBy('name', 'ASC')->get();

        return view('profiles.addsk', compact('roles'));
    }

    public function tambahsk(Request $request)
    {

        $this->validate($request, [
            'role' => 'required'
        ]);

        SyaratKetentuan::create($request->except('_token'));
        Alert::success('Berhasil', 'Berhasil menambahkan Syarat & Ketentuan');
        
        return redirect(route('admin.sk'));
    }

    public function editsk($id)
    {
        $sk = SyaratKetentuan::find($id);

        return view('profiles.editsk', compact('sk'));
    }

    public function formfaq()
    {

        return view('admin.addfaq');
    }
    public function listfaq()
    {
        $faq = Faq::orderBy('created_at', 'DESC')->paginate(10);

        return view('admin.listfaq', compact('faq'));
    }

    public function tambahfaq(Request $request)
    {

        $this->validate($request, [
            'pertanyaan' => 'required',
            'jawaban' => 'required'
        ]);

        Faq::create($request->except('_token'));
        Alert::success('Berhasil', 'Berhasil menambahkan FAQ');
        
        return redirect(route('admin.listfaq'));
    }

    public function hapusfaq($id)
    {
        $faq = Faq::find($id);
        $faq->delete();
        Alert::success('Berhasil', 'Berhasil menghapus FAQ');
        return redirect(route('admin.listfaq'));
    }

    public function indexbank(Request $request)
    {
        $banks = DaftarBank::orderBy('created_at', 'DESC')->paginate(10);
        
        return view('admin.bank', compact('banks'));
    }

    public function editbank($id)
    {
        $bank = DaftarBank::find($id);
        
        return view('admin.editbank');
    }

    public function destroybank($id)
    {
        $bank = DaftarBank::find($id);
        $bank->delete();
        
        Alert::success('Berhasil', 'Berhasil Menghapus Rekening Bank');
        return redirect(route('admin.indexbank'));
    }

    public function storebank(Request $request)
    {
        $this->validate(request(),[
            'nama_pemilik'=>'required|string',
            'nama_bank'=> 'required',
            'no_rek'=>'required|integer|unique:daftar_banks'
        ]);

        DaftarBank::create([
            'nama_pemilik' => $request->nama_pemilik,
            'nama_bank' => $request->nama_bank,
            'no_rek' => $request->no_rek
        ]);

        return redirect(route('admin.indexbank'))->with(['success' => 'Rekening Baru Ditambahkan']);
    }

    
}