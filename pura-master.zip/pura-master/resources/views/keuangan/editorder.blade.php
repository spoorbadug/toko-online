@extends('layouts.admin')

@section('title')
<title>Order</title>
@endsection

@section('menuside')
<li>
    <a href="{{ route('keuangan.index') }}"><i class="fa fa-th-large"></i>
        <span class="nav-label">Dashboard</span></a>
</li>
<li class="active">
    <a href="{{ route('keuangan.order') }}"><i class="fa fa-cart-plus"></i> <span
            class="nav-label">Order</span></a>
</li>
<li>
    <a href="{{ route('pay.bank') }}"><i class="fa fa-university"></i> <span
            class="nav-label">Rekening Bank</span></a>
</li>
<li>
    <a href="{{ route('keuangan.edit') }}"><i class="fa fa-address-card"></i>
        <span class="nav-label">Profile</span></a>
</li>
@endsection

@section('content')
<main class="main">
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>Daftar Pesanan</h2>
            <ol class="breadcrumb">
                <li>
                    Home
                </li>
                <li>
                    Order
                </li>
                <li class="active">
                    <strong>Edit Pesanan</strong>
                </li>
            </ol>
        </div>
        <div class="col-lg-2"></div>
    </div>

    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <form action="{{ route('keuangan.updateorder', $order->id) }}" method="post" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <div class="col-md-8">
                    <div class="ibox-content">
                        <div class="card-header">
                            <h4 class="card-title">Kelola Pesanan</h4>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="" class="control-label">InvoiceID</label>
                                <input type="text" class="form-control" name="invoice" value="{{ $order->invoice }}"
                                    disabled="">
                            </div>
                            <div class="form-group">
                                <label for="" class="control-label">Pelanggan</label>
                                <input type="text" class="form-control" name="name"
                                    value="{{ $order->profile->name }}" disabled="">
                            </div>
                            <div class="form-group">
                                <label for="" class="control-label">Total</label>
                                <input type="text" class="form-control" name="total"
                                    value="Rp {{ number_format($order->total) }}" disabled="">
                            </div>
                            <div class="form-group">
                                <label for="" class="control-label">Transfer ke rekening</label>
                                <input type="text" class="form-control" name="bank_id"
                                    value="{{ $order->bank->nama_bank }}" disabled="">
                            </div>
                            <div class="form-group">
                                <label for="" class="control-label">Nama pemilik rekening</label>
                                <input type="text" class="form-control" name="nama"
                                    value="{{ $order->payment->nama }}" disabled="">
                            </div>
                            <div class="form-group">
                                <label for="status">Status</label>
                                @if($order->status_id == '1' OR $order->status_id == '2')
                                <select name="status" class="form-control">
                                    <option value="{{ $order->status_id }}">{{ $order->status->name }}</option>
                                    @foreach($pay as $item)
                                        <option value="{{ $item->id }}"
                                            {{ $order->status_id == $item->id ? 'selected':'' }}>
                                            {{ $item->name }}</option>
                                    @endforeach
                                    {{-- <option value="1">Belum Bayar</option>
                                    <option value="2">Menunggu Pembayaran Diverifikasi</option>
                                    <option value="3">Pembayaran Terverifikasi</option>
                                    <option value="4">Pembayaran Ditolak</option> --}}
                                </select>
                                @else
                                <select name="status" class="form-control" disabled>
                                <option value="{{ $order->status_id }}">{{ $order->status->name }}</option>
                                </select>
                                @endif
                                <p class="text-danger">{{ $errors->first('status') }}</p>
                            </div>
                            <div class="form-group text-right">
                                <button class="btn btn-primary" id="button-confirm"
                                    value="Confirm Order">Konfirmasi</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <div class="col-md-4">
                <div class="ibox-content">
                    <div class="card-header">
                        <h4 class="card-title">Bukti Pembayaran</h4>
                    </div>
                    <div class="card-body">
                        <br>
                        <img src="{{ asset('/storage/payments/' .$order->payment['bukti_bayar']) }}"
                            width="250px" height="250px"
                            alt="{{ $order->payment->nama ?? '' }}">
                    </div>
                </div>
            </div>
        </div>


    </div>
</main>

@endsection
