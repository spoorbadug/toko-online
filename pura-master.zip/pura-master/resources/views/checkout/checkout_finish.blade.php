@extends('layouts.app')

@section('title')
    <title>Informasi Pesanan</title>
@endsection

@section('content')
<!-- Main Container  -->
<div class="main-container container">
    <ul class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i></a></li>
        <li><a href="#">Informasi Pesanan</a></li>
    </ul>
    
    <div class="row">
        <!--Middle Part Start-->
        <div id="content" class="col-sm-12">
            <h2 class="title">Informasi Pesanan</h2>
            <div class="alert alert-success"><i class="fa fa-check-circle"></i>
                Terima kasih, pesanan anda telah kami terima.</div>
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <td colspan="2" class="text-left">Detail Pesanan</td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td style="width: 50%;" class="text-left"> <b>ID Pesanan :</b> {{ $order->invoice }}
                            <br>
                            <b>Tanggal Pesanan :</b> {{ $order->created_at->format('d-m-Y') }}</td>
                        <td style="width: 50%;" class="text-left"> <b>Pembayaran :</b>Transfer Rekening {{ $order->bank->nama_bank }}
                            <br>
                            <b>Kurir :</b> {{ strtoupper($order->kurir) }} </td>
                    </tr>
                </tbody>
            </table>
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <td style="width: 50%; vertical-align: top;" class="text-left">Alamat Pengiriman</td>
						<td style="width: 50%; vertical-align: top;" class="text-left">Total</td>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $city = \App\City::where('city_id', $order->profile->city_id)->first();
                        $province = \App\Province::where('province_id', $order->profile->province_id)->first();
                    ?>
                    <tr>
                        <td class="text-left"><b>{{ $order->profile->name_address }}</b>
                            <br>{{ $order->profile->name }}
                            <br>{{ $order->profile->phonenumber }}
                            <br>{{ $order->profile->address }}, {{ $city->name }}, {{ $province->name }}
                            <br>Indonesia
                        </td>
                        <td class="text-left">
                            Rp {{ number_format($order->total) }}
                        </td>
                    </tr>
                </tbody>
            </table>
            
        </div>
        <!--Middle Part End-->
    </div>
</div>
<!-- //Main Container -->
@endsection