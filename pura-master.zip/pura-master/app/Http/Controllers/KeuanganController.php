<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Order;
use App\City;
use App\Province;
use App\Profile;
use App\DaftarBank;
use App\OrderStatus;
use App\SyaratKetentuan;

class KeuanganController extends Controller
{
    public function index()
    {
        $totalgross = 0;

        $customer = User::where('role','Customer')->get();
        $totalCustomer = count($customer);

        $admin = User::where('role','Admin')->orwhere('role','Unit')->get();
        $totalAdmin = count($admin);

        $orders = Order::orderBy('created_at', 'DESC')->paginate(10);
        $totalorder = count($orders);

        $prices = Order::where('status_id', 7)->pluck('total');
        $totalPrice = count($prices);
        
        foreach($prices as $x) {
            $totalgross += $x;
        }
        
        


        $latest=Order::orderBy('created_at','DESC')->take(5)->get();
        
        return view('keuangan.index',compact('latest','totalCustomer','totalAdmin','totalorder','totalgross','orders'));
    }

    public function bank(Request $request)
    {
        $banks = DaftarBank::orderBy('created_at', 'DESC')->paginate(10);
        
        return view('keuangan.bank', compact('banks'));
    }

    public function edit($id)
    {
        $bank = DaftarBank::find($id);
        
        return view('keuangan.editbank');
    }

    public function order()
    {
        //QUERY UNTUK MENGAMBIL SEMUA PESANAN DAN LOAD DATA YANG BERELASI MENGGUNAKAN EAGER LOADING
        //DAN URUTANKAN BERDASARKAN CREATED_AT
        $orders = Order::orderBy('created_at', 'DESC');
        //$orderstag = Order::pluck('province_id');
        //dd($orders);
        //$cities = City::where('city_id', $orders->city_id)->get();
        //$provinces = Province::where('province_id', $orders->province_id)->get();
        //$provinces = Province::where('province_id', $orders->province_id);
        
        //JIKA Q UNTUK PENCARIAN TIDAK KOSONG
        if (request()->q != '') {
            //MAKA DIBUAT QUERY UNTUK MENCARI DATA BERDASARKAN NAMA, INVOICE DAN ALAMAT
            $orders = $orders->where(function($q) {
                $q->where('customer_name', 'LIKE', '%' . request()->q . '%')
                ->orWhere('invoice', 'LIKE', '%' . request()->q . '%')
                ->orWhere('customer_address', 'LIKE', '%' . request()->q . '%');
            });
        }

        $orders = $orders->paginate(10); //LOAD DATA PER 10 DATA
        return view('keuangan.order', compact('orders', 'provinces', 'cities')); //LOAD VIEW INDEX DAN PASSING DATA TERSEBUT
    }

    public function show_order($id)
    {
        $order = Order::with(['user', 'details'])->where('id', $id)->first();
        // $province = Province::where('province_id', $order->province_id)->first();
        // $city = City::where('city_id', $order->city_id)->first();
        return view('keuangan.showorder', compact('order'));
    }

    public function edit_order($id)
    {
        $order = Order::find($id);
        $status = OrderStatus::orderBy('id', 'ASC')->get();
        $pay = OrderStatus::find([1, 2, 3, 4]);

    
        return view('keuangan.editorder', compact('order','pay', 'status'));
    }

    public function update_order(Request $request, $id) {

        //KEMUDIAN UPDATE PRODUK TERSEBUT
        $order=Order::find($id);
        $order->update([
            'status_id' => $request->status
        ]);
        return redirect(route('keuangan.order'))->with(['success'=> 'Data Diperbaharui']);
    }

    public function store(Request $request)
    {
        $this->validate(request(),[
            'nama_pemilik'=>'required|string',
            'nama_bank'=> 'required',
            'no_rek'=>'required|integer|unique:daftar_banks'
        ]);
            //SETELAH FILE TERSEBUT DISIMPAN, KITA SIMPAN INFORMASI PRODUKNYA KEDALAM DATABASE
        DaftarBank::create([
            'nama_pemilik' => $request->nama_pemilik,
            'nama_bank' => $request->nama_bank,
            'no_rek' => $request->no_rek
        ]);
            //JIKA SUDAH MAKA REDIRECT KE LIST PRODUK
        return redirect(route('keuangan.bank'))->with(['success' => 'Rekening Baru Ditambahkan']);
    }

    public function editprofile(Request $request)
    {
        // $provinces = Province::orderBy('name', 'DESC')->get();
        $provinces = Province::pluck('name', 'province_id');
        $cities = City::pluck('name', 'city_id');
        $skkeuangan = SyaratKetentuan::where('role', 'Keuangan')->get();
        $profiles = Profile::where('user_id', $request->user()->id)->first();

        return view('profiles.keuangan', [
            'user' => $request->user(),
            'provinces' => $provinces,
            'profiles'=> $profiles,
            'cities' => $cities,
            'skkeuangan' => $skkeuangan
        ]);
    }

    public function updateprofile(Request $request)
    {
        $profil=Profile::where('user_id', $request->user()->id);
        $profil->update([
            'user_id' => $request->user()->id,
            'name_address' => $request->name_address,
            'name' => $request->name,
            'phonenumber' => $request->phonenumber,
            'city_id' => $request->city_id,
            'province_id' => $request->province_id,
            'address' => $request->address,
            'postal_code' => $request->postal_code,
        ]);
        
        alert()->success('Berhasil','Berhasil mengubah profil Admin');
        return redirect()->route('keuangan.update');
    }
}
