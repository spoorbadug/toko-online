
<div class="form-group required">
    <label for="province" class="control-label">Provinsi</label>
    <select class="form-control provinsi-tujuan" id="province" name="provinceu">
        <option value="">{{ $user->province_id }}</option>
        {{-- @foreach ($provinces as $row)
    <option value="{{ $row->id }}"
        {{ $user->province == $row->id ? 'selected':'' }}>{{ $row->name }}
        </option>
        @endforeach--}}
        @foreach($provinces as $province => $value)
            <option value="{{ $province }}"
                {{ $user->province_id == $province ? 'selected':'' }}>
                {{ $value }}</option>
        @endforeach
    </select>
</div>
<div class="form-group required">
    <label for="city" class="control-label">Kota / Kabupaten</label>
    <select class="form-control kota-tujuan" id="city" name="cityu">
        <option value="">{{ $user->city_id }}</option>
        {{-- @foreach ($cities as $row)
    <option value="{{ $row->id }}"
        {{ $user->city == $row->id ? 'selected':'' }}>{{ $row->name }}
        </option>
        @endforeach--}}
        @foreach($cities as $city => $value)
            <option value="{{ $city }}"
                {{ $user->city_id == $city ? 'selected':'' }}>
                {{ $value }}</option>
        @endforeach
    </select>
</div>
<div class="form-group required">
    <label for="address" class="control-label">Alamat Lengkap</label>
    <input type="text" class="form-control" id="address" name="addressu"
        value="{{ $user->address }}" required>
    <p class="text-danger">
        {{ $errors->first('address') }}</p>
</div>
<div class="buttons clearfix">
    <div class="pull-right">
        <button type="submit" class="btn button-primary w-100">Simpan</button>
    </div>
</div>
