@extends('layouts.app')

@section('title')
<title>Syarat & Ketentuan</title>
@endsection

@section('content')
    <!-- Main Container  -->
	<div class="main-container container">
		<ul class="breadcrumb">
			<li><a href="#"><i class="fa fa-home"></i></a></li>
			<li><a href="#">Syarat & Ketentuan</a></li>
		</ul>
		
		<div class="row">
			<div id="content" class="col-sm-12">
				<h3>Syarat dan Ketentuan</h3>
				<p>
					<br>
				</p>
				<div class="row">
					<div class="col-sm-12">
						@forelse ($sk as $row)
							{!! $row->s_k !!}
						@empty
							
						@endforelse
						
					</div>
				</div>
			
				
			</div>
		</div>
	</div>
	<!-- //Main Container -->
@endsection