@extends('layouts.admin')

@section('title')
<title>Daftar FAQ</title>

<link href="{{ asset('css/plugins/summernote/summernote.css') }}" rel="stylesheet">
<link href="{{ asset('css/plugins/summernote/summernote-bs3.css') }}" rel="stylesheet">

    <!-- FooTable -->
    <link href="{{ asset('css/plugins/footable/footable.core.css') }}" rel="stylesheet">

    <link href="{{ ('css/animate.css') }}" rel="stylesheet">
    <link href="{{ ('css/style.css') }}" rel="stylesheet">
@endsection

@section('menuside')
<li>
    <a href="{{ route('admin.index') }}"><i class="fa fa-th-large"></i>
        <span class="nav-label">Dashboard</span></a>
</li>
<li>
    <a href="#"><i class="fa fa-user"></i><span class="fa arrow"></span>
        <span class="nav-label">Kelola User</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('admin.user') }}">Customer</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('admin.admin') }}">Admin</a></li>
    </ul>
</li>
<li>
    <a href="#"><i class="fa fa-archive"></i><span class="fa arrow"></span>
        <span class="nav-label">Product</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('product.index') }}">List Produk</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('product.create') }}">Tambah Produk</a></li>
    </ul>
</li>
<li>
    <a href="{{ route('category.index') }}"><i class="fa fa-industry"></i> <span
            class="nav-label">Category</span></a>
</li>
<li>
    <a href="{{ route('admin.order') }}"><i class="fa fa-cart-plus"></i> <span
            class="nav-label">Order</span></a>
</li>
<li>
    <a href="{{ route('admin.indexbank') }}"><i class="fa fa-university"></i> <span
            class="nav-label">Rekening Bank</span></a>
</li>
<li>
    <a href="{{ route('admin.edit') }}"><i class="fa fa-address-card"></i>
        <span class="nav-label">Profile</span></a>
</li>
<li>
    <a href=""><i class="fa fa-address-card"></i><span class="fa arrow"></span>
        <span class="nav-label">Syarat & Ketentuan</span></a>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.sk') }}">List SK</a></li>
        </ul>
        <ul class="nav nav-second-level collapse">
            <li class="active"><a href="{{ route('admin.formsk') }}">Tambah SK</a></li>
        </ul>
</li>
<li class="active">
    <a href=""><i class="fa fa-question-circle"></i><span class="fa arrow"></span>
        <span class="nav-label">FAQ</span></a>
        <ul class="nav nav-second-level collapse">
            <li class="active"><a href="{{ route('admin.listfaq') }}">List Faq</a></li>
        </ul>
        <ul class="nav nav-second-level collapse">
            <li><a href="{{ route('admin.formfaq') }}">Tambah Faq</a></li>
        </ul>
</li>
@endsection


@section('content')
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Daftar FAQ</h2>
        <ol class="breadcrumb">
            <li>Home
            </li>
            <li>FAQ
            </li>
            <li class="active">
                <strong>List</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="ibox-content">
        <div class="row">
            <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    
                    <div class="ibox-content">

                        <table class="footable table table-stripped toggle-arrow-tiny">
                            <thead>
                            <tr>
                                <th data-toggle="true">List Pertanyaan</th>
                                <th data-hide="all">Jawaban</th>
                                <th>Aksi</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                @forelse ($faq as $row)
                                    <td>{{ $row->pertanyaan }}</td>
                                    <td>{!! $row->jawaban !!}</td>
                                    <td><form action="{{ route('admin.hapusfaq', $row->id) }}" method="post">
                                        @csrf
                                        @method('DELETE')
                                        <a href="{{ route('product.edit', $row->id) }}"
                                            class="btn btn-warning">Edit</a>
                                        <button class="btn btn-danger">Hapus</button>
                                    </form></td>
                                @empty
                                    <td colspan="3">Tidak ada data</td>
                                @endforelse
                                
                            </tr>
                            </tbody>
                            <tfoot>
                            <tr>
                                <td colspan="2">
                                    {!! $faq->links() !!}
                                </td>
                            </tr>
                            </tfoot>
                        </table>

                    </div>
                </div>
            </div>
        </div>


    </div>
</div>
@endsection

@section('js')
<!-- SUMMERNOTE -->

<script src="{{ asset('js/jquery.min.js') }}"></script>
<script src="{{ asset('js/bootstrap.min.js') }}"></script>

<script src="{{ asset('js/plugins/summernote/summernote.min.js') }}"></script>
<!-- FooTable -->
<script src="{{ asset('js/plugins/footable/footable.all.min.js') }}"></script>
<script>
    $(document).ready(function() {

        $('.footable').footable();
        $('.footable2').footable();

    });

</script>
<script type="text/javascript">
    $(document).ready(function () {
        $('#jawaban').summernote({
            height: "150px",
            styleWithSpan: false
        });
    });

</script>
@endsection
