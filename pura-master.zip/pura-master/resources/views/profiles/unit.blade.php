@extends('layouts.admin')

@section('title')
<title>Profile</title>
<link href="{{ asset('css/plugins/summernote/summernote.css') }}" rel="stylesheet">
<link href="{{ asset('css/plugins/summernote/summernote-bs3.css') }}" rel="stylesheet">
@endsection

@section('menuside')
<li>
    <a href="{{ route('unit.index') }}"><i class="fa fa-th-large"></i>
        <span class="nav-label">Dashboard</span></a>
</li>
<li>
    <a href="{{ route('categoryunit.index') }}"><i class="fa fa-industry"></i>
        <span class="nav-label">Category</span></a>
</li>
<li>
    <a href="#"><i class="fa fa-archive"></i><span class="fa arrow"></span>
        <span class="nav-label">Product</span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('productunit.index') }}">List Produk</a></li>
    </ul>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ route('productunit.create') }}">Tambah Produk</a></li>
    </ul>
</li>
<li>
    <a href="{{ route('unit.order') }}"><i class="fa fa-cart-plus"></i>
        <span class="nav-label">Order</span></a>
</li>
<li class="active">
    <a href="{{ route('unit.edit') }}"><i class="fa fa-address-card"></i>
        <span class="nav-label">Profile</span></a>
</li>
@endsection

@section ('content')
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Profile</h2>
        <ol class="breadcrumb">
            <li>
                <a href="index.html">Home</a>
            </li>
            <li class="active">
                <strong>Profile</strong>
            </li>
        </ol>
    </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-sm-12">
                <div class="ibox-content">
                    <ul class="nav nav-tabs">
                        <li class="active"><a data-toggle="tab" href="#tab-1">Profile</a>
                        </li>
                        <li><a data-toggle="tab" href="#tab-2">Syarat & Ketentuan</a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="tab-1">
                            <form method="POST" action="{{ route('unit.update')  }}" enctype="multipart/form-data">
                                @csrf
                                @method('PATCH')
                            <fieldset id="personal-details">
                                <div class="form-group required">
                                    <label for="name" class="control-label">Name</label>
                                    <input type="text" class="form-control" id="name" placeholder="Name" value="{{ old('name') ?? $user->name }}" name="name">
                                </div>
                                <div class="form-group required">
                                    <label for="email" class="control-label">E-Mail</label>
                                    <input type="email" class="form-control" id="email" placeholder="E-Mail" value="{{ $user->email }}" name="email">
                                </div>
                                <div class="form-group required">
                                    <label for="phonenumber" class="control-label">Telephone</label>
                                    <input type="tel" class="form-control" id="phonenumber" value="{{ old('phonenumber') ?? $profiles->phonenumber  }}" name="phonenumber" placeholder="+62">
                                </div>
                                <div class="form-group">
                                    <label for="province" class="control-label">Provinsi</label>
                                    <select class="form-control provinsi-tujuan" id="province_id" name="province_id">
                                        <option value="">{{ $profiles['province_id'] }}</option>
                                        {{-- @foreach ($provinces as $row)
                                        <option value="{{ $row->id }}" {{ $user->province == $row->id ? 'selected':'' }}>{{ $row->name }}</option>
                                        @endforeach --}}
                                        @foreach ($provinces as $province => $value)
                                        <option value="{{ $province  }}" {{ $profiles['province_id'] == $province ? 'selected':'' }}>{{ $value }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="city" class="control-label">Kota / Kabupaten</label>
                                    <select class="form-control kota-tujuan" id="city_id" name="city_id">
                                        <option value="">{{ $profiles['city_id'] }}</option>
                                        {{-- @foreach ($cities as $row)
                                        <option value="{{ $row->id }}" {{ $user->city == $row->id ? 'selected':'' }}>{{ $row->name }}</option>
                                        @endforeach --}}
                                        @foreach ($cities as $city => $value)
                                        <option value="{{ $city  }}" {{ $profiles['city_id'] == $city ? 'selected':'' }}>{{ $value }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="address">Alamat Lengkap</label>
                                    <input type="text" class="form-control" id="address" name="address" value="{{ $profiles->address }}">
                                    <p class="text-danger">
                                        {{ $errors->first('address') }}</p>
                                </div>
                                <div class="buttons clearfix">
                                    <div class="pull-right">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            {{ __('Simpan') }}
                                        </button>
                                    </div>
                                </div>
                            </fieldset>
                        </form>
                        </div>
                        <div class="tab-pane" id="tab-2">
                            @forelse ($skunit as $item)
                                {!! $item->s_k !!}
                            @empty
                            <p class="text-center">Syarat & Ketentuan belum dibuat.</p>
                            @endforelse
                        </div>
                        
                    </div>
                
                </div>
            </div>
        </div>
</div>
    
@endsection

@section('js')
<!-- SUMMERNOTE -->

<script src="{{ asset('js/jquery.min.js') }}"></script>
<script src="{{ asset('js/bootstrap.min.js') }}"></script>

<script src="{{ asset('js/plugins/summernote/summernote.min.js') }}"></script>

<!-- 
<script>
    $('#description').summernote({
        height: 125,   //set editable area's height
        codemirror: { // codemirror options
            theme: 'monokai'
        }
    });
</script>
-->
<script type="text/javascript">
  $(document).ready(function() {
    $('#description').summernote({
      height: "150px",
      styleWithSpan: false
  });
}); 
</script>

<script>
    $(document).ready(function () {
        //ajax select kota asal
        $('select[id="province_id"]').on('change', function () {
            let provindeId = $(this).val();
            if (provindeId) {
                jQuery.ajax({
                    url: '/cities/' + provindeId,
                    type: "GET",
                    dataType: "json",
                    success: function (response) {
                        $('select[id="city_id"]').empty();
                        $('select[id="city_id"]').append(
                            '<option value="">-- Pilih Kota --</option>');
                        $.each(response, function (key, value) {
                            $('select[id="city_id"]').append('<option value="' +
                                key +
                                '">' + value + '</option>');
                        });
                    },
                });
            } else {
                $('select[id="city_id"]').append('<option value="">-- Pilih Kota --</option>');
            }
        });

    });

</script>

@endsection