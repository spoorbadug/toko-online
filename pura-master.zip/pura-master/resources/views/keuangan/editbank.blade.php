@extends('layouts.admin')

@section('title')
<title>Rekening Bank</title>
@endsection

@section('menuside')
<li>
    <a href="{{ route('keuangan.index') }}"><i class="fa fa-th-large"></i>
        <span class="nav-label">Dashboard</span></a>
</li>
<li>
    <a href="{{ route('keuangan.order') }}"><i class="fa fa-cart-plus"></i> <span
            class="nav-label">Order</span></a>
</li>
<li class="active">
    <a href="{{ route('pay.bank') }}"><i class="fa fa-university"></i> <span
            class="nav-label">Rekening Bank</span></a>
</li>
<li>
    <a href="{{ route('keuangan.edit') }}"><i class="fa fa-address-card"></i>
        <span class="nav-label">Profile</span></a>
</li>
@endsection

@section('content')
<main class="main">
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>Rekening Bank</h2>
            <ol class="breadcrumb">
                <li>Home
                </li>
                <li>Rekening Bank
                </li>
                <li class="active">
                    <strong>Edit Bank</strong>
                </li>
            </ol>
        </div>
    </div>
    <div class="wrapper wrapper-content animated fadeInRight">
    
        <div class="col-md-4">
            <div class="ibox-content">
                <div class="card-header">
                    <h4 class="card-title">Edit Rekening Bank</h4>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        @csrf
                        <div class="form-group">
                            <label for="nama_pemilik">Nama Pemilik</label>
                            <input type="text" name="nama_pemilik" class="form-control" required>
                            <p class="text-danger">{{ $errors->first('nama_pemilik') }}</p>
                        </div>
                        <div class="form-group">
                            <label for="nama_bank">Nama Bank</label>
                            <select name="nama_bank" class="form-control">
                                <option value="">Pilih</option>
                                <option value="Admin">Admin</option>
                                <option value="Unit">Unit</option>
                                {{-- @foreach ($roles as $r)
                                    <option value="{{ $r->id }}">{{ $r->name }}</option>
                                @endforeach --}}
                            </select>
                            <p class="text-danger">{{ $errors->first('nama_bank') }}</p>
                        </div>
                        <div class="form-group">
                            <label for="no_rek">No. Rekening</label>
                            <input type="text" name="no_rek" class="form-control" required>
                            <p class="text-danger">{{ $errors->first('no_rek') }}</p>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary btn-sm">Tambah</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</main>
@endsection
