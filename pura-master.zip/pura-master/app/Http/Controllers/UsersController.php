<?php 

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use App\City;
use App\Province;
use App\User;
use App\Role;
use App\Category;
use App\Order;
use App\Profile;
use App\OrderStatus;
use App\Product;
use App\OrderDetail;
use App\SyaratKetentuan;
use App\Komplain;
use Auth;
use Alert;

class UsersController extends Controller {

    public function dashboard()
    {
        $totalgross = 0;

        $customer = User::where('role','Customer')->get();
        $totalCustomer = count($customer);

        $totalkomplain = Order::where('status_id', 10)->get();
        $komplain = count($totalkomplain);

        $category = Category::where('user_id', Auth::user()->id)->first();
        $orderdetail = Order::orderBy('created_at','DESC')->paginate(10);
        
        foreach ($orderdetail as $row) {
            $cek = Order::where('id', $row->order_id)->get();
        }

        $total = Order::where('status_id', 7)->first();
        if($total !== null){
            $ord = OrderDetail::where('category_id', $category->id)->where('order_id', $total->id)->pluck('price');
            foreach($ord as $x) {
                $totalgross += $x;
            }
        }
        
        $neworder = Order::where('status_id', 3)->get();
        $totalorder = count($neworder);
        
        $listorder=Order::where('status_id', 3)->orwhere('status_id', 10)->orderBy('created_at','DESC')->paginate(10);
        
        return view('unit.index',compact('orderdetail','listorder','totalCustomer','komplain','totalorder','totalgross','reminder','cek'));
    }

    

    public function category()
    {
        $category = Category::with(['user'])->where('user_id', Auth::user()->id)->orderBy('created_at', 'DESC')->paginate(10);
        $unit = User::where('id', Auth::user()->id)->orderBy('name', 'ASC')->get();
        
        return view('unit.category', compact('category', 'unit'));
    }

    public function addcategory(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|string|max:50|unique:categories'
        ]);

        $request->request->add(['slug' => $request->name]);

        Category::create($request->except('_token'));
        Alert::success('Success Title', 'Success Message');

        return redirect(route('categoryunit.index'))->with(['success' => 'Kategori Baru Ditambahkan!']);
    }

    public function delcategory($id)
    {
        $category = Category::withCount(['product'])->find($id);
        
        if ($category->product_count == 0) {
            $category->delete();
            Alert::success('Berhasil Hapus', 'Kategori Telah Berhasil Dihapus');
            return redirect(route('category.index'));
        }

        Alert::error('Gagal Hapus', 'Kategori Memiliki Produk');
        return redirect(route('categoryunit.index'));
    }

    public function index()
    {
        $slug=Auth::user()->id;

        if($slug == null){
            return view('unit.product', compact('products'));
        } else {
            $products = Category::where('user_id', $slug)->orderBy('created_at', 'DESC')->first()->product();
        }

        $products=$products->paginate(10);
        return view('unit.product', compact('products'));
    }

    public function create()
    {
        $category=Category::where('user_id', Auth::user()->id)->get();
        return view('unit.addproduct', compact('category'));
    }

    public function store(Request $request)
    {
        $this->validate(request(),[
            'name'=>'required|string',
            'description'=> 'required',
            'price'=>'required|integer',
            'weight'=> 'required|integer',
            'stock'=> 'required|integer',
            'min'=> 'required|integer',
            'category_id'=>'required|exists:categories,id'
        ]);

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $filename = time() . Str::slug($request->name) . '.' . $file->getClientOriginalExtension();
            $file->storeAs('public/products', $filename);
    
            $product = Product::create([
                'name' => $request->name,
                'slug' => $request->name,
                'category_id' => $request->category_id,
                'description' => $request->description,
                'image' => $filename,
                'price' => $request->price,
                'weight' => $request->weight,
                'stok' => $request->stock,
                'min_order' => $request->min,
                'status' => $request->status
            ]);

            alert()->success('Berhasil','Berhasil menambahkan produk');
            return redirect(route('productunit.index'));
        }
    }

    public function edit($id) 
    {
        $product=Product::find($id);
        $category=Category::where('slug', Auth::user()->slug)->get();
        return view('unit.editproduct', compact('product','category'));
    }

    public function update(Request $request, $id) {
        $this->validate($request, [ 'name'=> 'required|string|max:100',
            'description'=> 'required',
            'category_id'=> 'required|exists:categories,id',
            'price'=> 'required|integer',
            'weight'=> 'required|integer',
            'image'=> 'nullable|image|mimes:png,jpeg,jpg'
            ]);

        $product=Product::find($id);
        $filename=$product->image;

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $filename = time() . Str::slug($request->name) . '.' . $file->getClientOriginalExtension();
            $file->storeAs('public/products', $filename);
            File::delete(storage_path('app/public/products/' . $product->image));
        }
    
        $product->update([
            'name' => $request->name,
            'description' => $request->description,
            'category_id' => $request->category_id,
            'price' => $request->price,
            'weight' => $request->weight,
            'image' => $filename,
            'status' => $request->status
        ]);

        alert()->success('Berhasil','Berhasil mengubah data produk');
        return redirect(route('productunit.index'));
    }
    
    public function destroy($id)
    {
        Product::where('id',$id)->delete();
        Stock::where('product_id',$id)->delete();

        alert()->success('Berhasil','Berhasil menghapus produk');
        return redirect()->route('productunit.index')->with('success','Successfully removed the product!');
    }

    public function editunit(Request $request)
    {
        $provinces = Province::pluck('name', 'province_id');
        $cities = City::pluck('name', 'city_id');
        $skunit = SyaratKetentuan::where('role', 'Unit')->get();
        $profiles = Profile::where('user_id', $request->user()->id)->first();

        return view('profiles.unit', [
            'user' => $request->user(),
            'provinces' => $provinces,
            'profiles'=> $profiles,
            'cities' => $cities,
            'skunit' => $skunit
        ]);
    }

    public function updateunit(Request $request)
    {
        $profil=Profile::where('user_id', $request->user()->id);
        $profil->update([
            'user_id' => $request->user()->id,
            'name_address' => $request->name_address,
            'name' => $request->name,
            'phonenumber' => $request->phonenumber,
            'city_id' => $request->city_id,
            'province_id' => $request->province_id,
            'address' => $request->address,
            'postal_code' => $request->postal_code,
        ]);

        alert()->success('Berhasil','Berhasil mengubah profil unit');
        return redirect()->route('unit.edit');
    }

    public function order()
    {
        $orders = Order::orderBy('created_at', 'DESC');

        if (request()->q != '') {
            $orders = $orders->where(function($q) {
                $q->Where('invoice', 'LIKE', '%' . request()->q . '%');
            });
        }

        $orders = $orders->paginate(10);
        return view('unit.order', compact('orders'));
    }

    public function show_order($id)
    {
        $order = Order::with(['user', 'details'])->where('id', $id)->first();
        return view('unit.showorder', compact('order'));
    }

    public function edit_order($id)
    {
        $order = Order::find($id);
        $status = OrderStatus::orderBy('id', 'ASC')->get();
        $pay = OrderStatus::find([5, 6, 7, 8, 9]);

        return view('unit.editorder', compact('order','pay', 'status'));
    }

    public function update_order(Request $request, $id) 
    {
        $order=Order::find($id);
        $order->update([
            'status_id' => $request->status
        ]);
        return redirect(route('unit.order'))->with(['success'=> 'Data Diperbaharui']);
    }

    public function delete_order($id)
    {
        $order = Order::find($id);
        $order->delete();
        return redirect(route('unit.order'));
    }

    public function komplain()
    {
        $komplains = Komplain::orderBy('created_at', 'DESC');

        // if (request()->q != '') {
        //     $orders = $orders->where(function($q) {
        //         $q->Where('invoice', 'LIKE', '%' . request()->q . '%');
        //     });
        // }

        $komplains = $komplains->paginate(10);
        return view('unit.komplain', compact('komplains'));
    }
}

